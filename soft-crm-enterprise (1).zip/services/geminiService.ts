import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { Ticket, Lead } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
const MODEL_NAME = 'gemini-2.5-flash';

// --- FALLBACK MOCKS (Used when API fails or Quota exceeded) ---
const MOCK_SUMMARY = "A empresa apresenta um crescimento sólido de 12% no MRR, atingindo R$ 51k. O Churn de 2.1% está dentro da margem aceitável, mas recomenda-se atenção aos clientes do setor de Varejo. O volume de tickets críticos está baixo, indicando estabilidade na plataforma. Sugestão: Focar em upsell para a base atual para maximizar o LTV.";

const MOCK_EMAIL = (name: string) => `Assunto: Oportunidade para potencializar seus resultados

Olá ${name},

Espero que esta mensagem o encontre bem.

Gostaria de agendar uma breve conversa para demonstrar como o Nexus CRM pode otimizar seu processo comercial e aumentar suas conversões. Temos ajudado empresas do seu setor a reduzir o ciclo de vendas em até 30%.

Você teria disponibilidade para um café virtual na próxima terça-feira?

Atenciosamente,
Equipe Nexus`;

const MOCK_TICKET_ANALYSIS = JSON.stringify({
    summary: "O cliente relata lentidão crítica no login afetando múltiplos usuários.",
    sentiment: "Negativo",
    suggestedAction: "Escalar para equipe de Infraestrutura imediatamente e verificar status do servidor de autenticação."
});

const MOCK_AUDIO_NOTE = `[Transcrição IA]
Resumo: Reunião produtiva sobre a expansão das licenças. O cliente demonstrou interesse no plano Enterprise.
Próximos Passos: Enviar proposta atualizada até sexta-feira.
Sentimento: Positivo`;

const MOCK_BI_ANALYSIS = "Com base nos dados apresentados, sua taxa de conversão de leads (20%) está saudável, mas o volume de tickets críticos aumentou na última semana. Recomendo investigar se a última atualização do produto causou instabilidade, pois isso pode impactar o Churn no próximo mês. O segmento de Tecnologia representa 60% da sua receita, sugerindo uma forte aderência neste nicho.";

const MOCK_OBJECTION_SCRIPT = "Entendo perfeitamente sua preocupação com o orçamento. Muitos de nossos clientes atuais, como a [Empresa Parecida], tiveram esse mesmo receio inicial. O que eles descobriram, no entanto, foi que a automação do Nexus reduziu o custo operacional deles em 20% logo nos primeiros 3 meses, pagando o investimento. Se conseguirmos provar um ROI similar para você, faria sentido revisarmos os números?";

export const analyzeTicket = async (ticket: Ticket): Promise<string> => {
  try {
    const prompt = `
      Atue como um agente de suporte técnico sênior.
      Analise o seguinte ticket de suporte e forneça um resumo estruturado em JSON com:
      1. Resumo conciso (max 2 frases)
      2. Sentimento (Positivo, Neutro, Negativo)
      3. Sugestão de ação imediata.
      
      Ticket Info:
      Assunto: ${ticket.subject}
      Descrição: ${ticket.description}
      Prioridade: ${ticket.priority}
    `;

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    return response.text || MOCK_TICKET_ANALYSIS;
  } catch (error) {
    console.warn("Gemini API Fallback (Analyze Ticket):", error);
    return MOCK_TICKET_ANALYSIS;
  }
};

export const generateLeadEmail = async (lead: Lead): Promise<string> => {
  try {
    const prompt = `
      Escreva um e-mail comercial formal, porém amigável, para o lead abaixo.
      O objetivo é agendar uma demonstração do nosso produto "Nexus CRM".
      
      Lead: ${lead.name}
      Empresa: ${lead.company}
      Status: ${lead.status}
      Último contato: ${lead.lastContact}
    `;

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
    });

    return response.text || MOCK_EMAIL(lead.name);
  } catch (error) {
    console.warn("Gemini API Fallback (Generate Email):", error);
    return MOCK_EMAIL(lead.name);
  }
};

export const generateExecutiveSummary = async (metrics: any): Promise<string> => {
    try {
        const prompt = `
          Atue como um consultor financeiro. Analise estas métricas mensais e dê um feedback executivo de 1 parágrafo sobre a saúde da empresa.
          
          Métricas: ${JSON.stringify(metrics)}
        `;
    
        const response: GenerateContentResponse = await ai.models.generateContent({
          model: MODEL_NAME,
          contents: prompt,
        });
    
        return response.text || MOCK_SUMMARY;
      } catch (error) {
        console.warn("Gemini API Fallback (Exec Summary):", error);
        return MOCK_SUMMARY;
      }
}

export const processAudioNote = async (audioBase64: string): Promise<string> => {
  try {
    // Remove header do base64 se existir (data:audio/webm;base64,)
    const cleanBase64 = audioBase64.split(',')[1] || audioBase64;

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "audio/wav", // Gemini suporta wav, mp3, aac, flac
              data: cleanBase64
            }
          },
          {
            text: "Atue como um assistente de vendas. Transcreva este áudio da reunião e, em seguida, extraia: 1. Um resumo curto. 2. Ação sugerida (Next Step). 3. Sentimento do cliente. Formate a saída como texto limpo e estruturado."
          }
        ]
      }
    });

    return response.text || MOCK_AUDIO_NOTE;
  } catch (error) {
    console.error("Gemini Audio Error:", error);
    return MOCK_AUDIO_NOTE;
  }
};

export const analyzeBusinessData = async (dataContext: any, userQuery: string): Promise<string> => {
    try {
        const prompt = `
          Atue como um Chief Data Officer (CDO) e Analista de BI Sênior.
          Você tem acesso aos seguintes dados consolidados da empresa "Nexus CRM":
          ${JSON.stringify(dataContext)}

          O usuário perguntou: "${userQuery}"

          Responda de forma direta, analítica e estratégica. Use números para embasar sua resposta.
          Se a pergunta for sobre "o que fazer", sugira 3 ações práticas.
          Mantenha o tom profissional e encorajador.
        `;

        const response: GenerateContentResponse = await ai.models.generateContent({
            model: MODEL_NAME,
            contents: prompt,
        });

        return response.text || MOCK_BI_ANALYSIS;
    } catch (error) {
        console.error("Gemini BI Error:", error);
        return MOCK_BI_ANALYSIS;
    }
};

export const generateSalesObjectionResponse = async (lead: Lead, objectionType: string): Promise<string> => {
    try {
        const prompt = `
          Atue como um treinador de vendas de elite especialista em B2B e metodologia SPIN Selling.
          
          Cenário:
          Estou tentando vender o "Nexus CRM Enterprise" (Software de gestão de alto valor).
          O Lead é: ${lead.name}, da empresa ${lead.company}.
          O valor estimado da oportunidade é: R$ ${lead.value}.
          A objeção levantada foi: "${objectionType}".

          Tarefa:
          Gere um script curto de resposta (máximo 3 frases) que eu possa falar ou enviar agora.
          A resposta deve:
          1. Validar a preocupação (Empatia).
          2. Reenquadrar o problema ou oferecer uma prova social.
          3. Terminar com uma pergunta de fechamento ou avanço.
          
          Mantenha o tom profissional, confiante e persuasivo.
        `;

        const response: GenerateContentResponse = await ai.models.generateContent({
            model: MODEL_NAME,
            contents: prompt,
        });

        return response.text || MOCK_OBJECTION_SCRIPT;
    } catch (error) {
        console.error("Gemini Objection Error:", error);
        return MOCK_OBJECTION_SCRIPT;
    }
};