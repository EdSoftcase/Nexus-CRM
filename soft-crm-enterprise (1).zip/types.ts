
export type Role = 'admin' | 'executive' | 'sales' | 'support' | 'dev' | 'finance';

export enum LeadStatus {
  NEW = 'Novo',
  QUALIFIED = 'Qualificado',
  PROPOSAL = 'Proposta',
  NEGOTIATION = 'Negociação',
  CLOSED_WON = 'Ganho',
  CLOSED_LOST = 'Perdido'
}

export enum TicketPriority {
  LOW = 'Baixa',
  MEDIUM = 'Média',
  HIGH = 'Alta',
  CRITICAL = 'Crítica'
}

export enum TicketStatus {
  OPEN = 'Aberto',
  IN_PROGRESS = 'Em Andamento',
  RESOLVED = 'Resolvido',
  CLOSED = 'Fechado'
}

export enum InvoiceStatus {
  DRAFT = 'Rascunho',
  PENDING = 'Pendente',
  SENT = 'Enviado',
  PAID = 'Pago',
  OVERDUE = 'Atrasado',
  CANCELLED = 'Cancelado'
}

export type ProposalStatus = 'Draft' | 'Sent' | 'Accepted' | 'Rejected';

export interface Organization {
  id: string;
  name: string;
  slug: string;
  plan: 'Trial' | 'Standard' | 'Enterprise';
  subscription_status?: 'active' | 'trial' | 'past_due' | 'canceled' | 'inactive';
}

export interface User {
  id: string;
  name: string;
  role: Role;
  avatar: string;
  email?: string;
  cpf?: string;
  phone?: string;
  password?: string;
  organizationId?: string; // Link para a empresa
}

export interface Note {
  id: string;
  text: string;
  author: string;
  created_at: string;
}

export interface Product {
    id: string;
    name: string;
    description: string;
    price: number;
    sku: string;
    category: 'Service' | 'Product' | 'Subscription';
    active: boolean;
    organizationId?: string;
}

export interface ClientDocument {
    id: string;
    clientId: string;
    title: string;
    type: 'Contract' | 'Proposal' | 'NDA' | 'Image' | 'Other';
    url: string; // Em um app real, seria a URL do Storage bucket
    uploadedBy: string;
    uploadDate: string;
    size: string;
}

export interface Lead {
  id: string;
  name: string;
  company: string;
  email: string;
  value: number;
  status: LeadStatus;
  source: string;
  probability: number;
  createdAt: string; // ISO Date - Essential for Sales Cycle Forecast
  lastContact: string; // ISO Date
  organizationId?: string;
  
  // New Fields
  phone?: string;
  address?: string;
  website?: string;
  parkingSpots?: number; 
  productInterest?: string; 
}

export interface Client {
  id: string;
  name: string; 
  contactPerson: string;
  document?: string; // CNPJ ou CPF
  email: string;
  phone: string;
  segment: string;
  since: string;
  status: 'Active' | 'Churn Risk' | 'Inactive';
  ltv: number;
  nps?: number;
  healthScore?: number; // 0 to 100
  onboardingStatus?: 'Pending' | 'In Progress' | 'Completed';
  lastContact?: string; // ISO Date - Novo campo para controle de retenção (30 dias)
  organizationId?: string;
  
  // Optional fields for consistency with leads
  address?: string;
  website?: string;
  productInterest?: string;

  // Fields from Excel Import Image (Estacionamento Specific)
  contractId?: string; // "Contrato"
  contractStartDate?: string; // "Início"
  contractEndDate?: string; // "Fim"
  unit?: string; // "Unidade"
  parkingSpots?: number; // "Vagas"
  exemptSpots?: number; // "Isentas"
  vehicleCount?: number; // "Qtd. Veículos"
  credentialCount?: number; // "Qtd. Credenciais"
  pricingTable?: string; // "Tabela"
  tablePrice?: number; // "R$ Tabela"
  totalTablePrice?: number; // "R$ Tabela Total"
  specialDay?: string; // "Dia Espec."
  specialPrice?: number; // "R$ Especial"
  totalSpecialPrice?: number; // "R$ Especial Total"
}

export interface Ticket {
  id: string;
  subject: string;
  customer: string; 
  priority: TicketPriority;
  status: TicketStatus;
  created_at: string;
  description: string;
  channel: 'Email' | 'Chat' | 'Phone';
  organizationId?: string;
}

export interface Issue {
  id: string;
  title: string;
  type: 'Bug' | 'Feature' | 'Task';
  status: 'Backlog' | 'To Do' | 'In Progress' | 'Review' | 'Done';
  points: number;
  assignee: string;
  sprint: string;
  project: string;
  progress: number; // 0 to 100
  notes: Note[];
  organizationId?: string;
}

export interface Invoice {
  id: string;
  customer: string; 
  amount: number;
  dueDate: string;
  status: InvoiceStatus;
  description: string;
  organizationId?: string;
}

export interface Proposal {
  id: string;
  title: string;
  leadId?: string; 
  clientName: string;
  companyName: string;
  createdDate: string;
  validUntil: string;
  status: ProposalStatus;
  introduction: string;
  scope: string[];
  price: number;
  timeline: string;
  terms: string;
  organizationId?: string;
}

export interface Activity {
  id: string;
  title: string;
  type: 'Call' | 'Meeting' | 'Email' | 'Task';
  dueDate: string;
  completed: boolean;
  relatedTo: string; 
  assignee: string;
  organizationId?: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  action: string;
  details: string;
  module: string;
  organizationId?: string;
}

export interface Notification {
    id: string;
    title: string;
    message: string;
    type: 'info' | 'warning' | 'success' | 'alert';
    timestamp: string;
    read: boolean;
    relatedTo?: string; // ID of related entity
}

export interface KPIMetric {
  label: string;
  value: string;
  trend: number; // percentage
  trendLabel: string;
  color: 'blue' | 'green' | 'red' | 'yellow';
}

export interface GeminiAnalysisResult {
  summary: string;
  sentiment: 'Positivo' | 'Neutro' | 'Negativo';
  suggestedAction: string;
}

// Permission Types
export type PermissionAction = 'view' | 'create' | 'edit' | 'delete';

export interface PermissionMatrix {
  [role: string]: {
    [module: string]: {
      view: boolean;
      create: boolean;
      edit: boolean;
      delete: boolean;
    }
  }
}