
import React from 'react';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';
import { InvoiceStatus, Invoice } from '../types';
import { DollarSign, AlertCircle, CheckCircle, FileText, Send, Clock } from 'lucide-react';

export const Finance: React.FC = () => {
    const { invoices, updateInvoiceStatus } = useData();
    const { currentUser } = useAuth();

    // Map columns to statuses
    const columns = [
        { id: InvoiceStatus.DRAFT, label: 'Rascunho', color: 'bg-slate-100 text-slate-700' },
        { id: InvoiceStatus.PENDING, label: 'Pendente', color: 'bg-yellow-100 text-yellow-700' },
        { id: InvoiceStatus.SENT, label: 'Enviado', color: 'bg-blue-100 text-blue-700' },
        { id: InvoiceStatus.PAID, label: 'Pago', color: 'bg-green-100 text-green-700' },
        { id: InvoiceStatus.OVERDUE, label: 'Atrasado', color: 'bg-red-100 text-red-700' },
    ];

    const getIcon = (status: InvoiceStatus) => {
        switch(status) {
            case InvoiceStatus.PAID: return <CheckCircle size={16} className="text-green-600"/>;
            case InvoiceStatus.OVERDUE: return <AlertCircle size={16} className="text-red-600"/>;
            case InvoiceStatus.SENT: return <Send size={16} className="text-blue-600"/>;
            case InvoiceStatus.PENDING: return <Clock size={16} className="text-yellow-600"/>;
            default: return <FileText size={16} className="text-slate-400"/>;
        }
    };

    const handleMove = (id: string, currentStatus: InvoiceStatus, direction: 'next' | 'prev') => {
        const currentIndex = columns.findIndex(c => c.id === currentStatus);
        if (currentIndex === -1) return;

        let newIndex = direction === 'next' ? currentIndex + 1 : currentIndex - 1;
        
        // Boundaries check
        if (newIndex >= 0 && newIndex < columns.length) {
            updateInvoiceStatus(currentUser, id, columns[newIndex].id);
        }
    };

    const totalReceivables = invoices
        .filter(i => i.status !== InvoiceStatus.DRAFT && i.status !== InvoiceStatus.CANCELLED)
        .reduce((acc, curr) => acc + curr.amount, 0);

    const totalOverdue = invoices
        .filter(i => i.status === InvoiceStatus.OVERDUE)
        .reduce((acc, curr) => acc + curr.amount, 0);

    return (
        <div className="p-8 h-screen flex flex-col bg-slate-50">
            {/* Header with Stats */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-slate-900">Financeiro</h1>
                    <p className="text-slate-500">Gestão de faturamento e contas a receber.</p>
                </div>
                <div className="flex gap-4">
                    <div className="bg-white p-3 rounded-lg border border-slate-200 shadow-sm flex items-center gap-3">
                        <div className="bg-blue-100 p-2 rounded-full text-blue-600">
                            <DollarSign size={20}/>
                        </div>
                        <div>
                            <p className="text-xs text-slate-500 font-bold uppercase">Total a Receber</p>
                            <p className="text-lg font-bold text-slate-800">R$ {totalReceivables.toLocaleString()}</p>
                        </div>
                    </div>
                    <div className="bg-white p-3 rounded-lg border border-red-100 shadow-sm flex items-center gap-3">
                        <div className="bg-red-100 p-2 rounded-full text-red-600">
                            <AlertCircle size={20}/>
                        </div>
                        <div>
                            <p className="text-xs text-red-500 font-bold uppercase">Em Atraso</p>
                            <p className="text-lg font-bold text-red-700">R$ {totalOverdue.toLocaleString()}</p>
                        </div>
                    </div>
                </div>
            </div>

            {/* Kanban Board */}
            <div className="flex-1 overflow-x-auto pb-4">
                <div className="flex gap-6 h-full min-w-max">
                    {columns.map((col) => (
                        <div key={col.id} className="w-80 flex flex-col bg-slate-100/50 rounded-xl border border-slate-200/60">
                            {/* Column Header */}
                            <div className={`p-4 rounded-t-xl border-b border-slate-200 flex justify-between items-center ${col.color} bg-opacity-20`}>
                                <span className="font-bold flex items-center gap-2">
                                    {getIcon(col.id)} {col.label}
                                </span>
                                <span className="bg-white/50 px-2 py-0.5 rounded text-xs font-bold">
                                    {invoices.filter(i => i.status === col.id).length}
                                </span>
                            </div>

                            {/* Column Content */}
                            <div className="p-3 flex-1 overflow-y-auto space-y-3 custom-scrollbar">
                                {invoices.filter(i => i.status === col.id).map(invoice => (
                                    <div key={invoice.id} className="bg-white p-4 rounded-lg shadow-sm border border-slate-200 hover:shadow-md transition group relative">
                                        <div className="flex justify-between items-start mb-2">
                                            <span className="font-bold text-slate-800">{invoice.customer}</span>
                                            <span className="text-xs font-mono text-slate-400">{invoice.id}</span>
                                        </div>
                                        <p className="text-sm text-slate-600 mb-2 line-clamp-2">{invoice.description}</p>
                                        <div className="flex justify-between items-end mt-3 border-t pt-2 border-slate-100">
                                            <div>
                                                <p className="text-xs text-slate-400">Vencimento</p>
                                                <p className={`text-sm font-medium ${new Date(invoice.dueDate) < new Date() && invoice.status !== InvoiceStatus.PAID ? 'text-red-600' : 'text-slate-700'}`}>
                                                    {new Date(invoice.dueDate).toLocaleDateString()}
                                                </p>
                                            </div>
                                            <p className="text-lg font-bold text-slate-800">R$ {invoice.amount.toLocaleString()}</p>
                                        </div>

                                        {/* Hover Actions */}
                                        <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1 bg-white shadow-sm rounded border border-slate-100">
                                            {col.id !== InvoiceStatus.DRAFT && (
                                                <button 
                                                    onClick={(e) => { e.stopPropagation(); handleMove(invoice.id, invoice.status, 'prev'); }}
                                                    className="p-1 hover:bg-slate-100 text-slate-500 rounded"
                                                    title="Voltar status"
                                                >
                                                    ←
                                                </button>
                                            )}
                                            {col.id !== InvoiceStatus.OVERDUE && (
                                                <button 
                                                    onClick={(e) => { e.stopPropagation(); handleMove(invoice.id, invoice.status, 'next'); }}
                                                    className="p-1 hover:bg-blue-50 text-blue-600 rounded"
                                                    title="Avançar status"
                                                >
                                                    →
                                                </button>
                                            )}
                                        </div>
                                    </div>
                                ))}
                                {invoices.filter(i => i.status === col.id).length === 0 && (
                                    <div className="h-full flex items-center justify-center text-slate-400 text-xs italic opacity-50 border-2 border-dashed border-slate-200 rounded-lg min-h-[100px]">
                                        Vazio
                                    </div>
                                )}
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};
