
import React, { useEffect, useState, useMemo } from 'react';
import { DollarSign, TrendingUp, Users, AlertCircle, RefreshCw, CheckCircle, Circle, Clock, ArrowRight, X, Bell, Zap, Phone, PartyPopper, Briefcase, Eye, EyeOff } from 'lucide-react';
import { KPICard, SectionTitle } from '../components/Widgets';
import { RevenueChart, PipelineFunnel } from '../components/Charts';
import { generateExecutiveSummary } from '../services/geminiService';
import { InvoiceStatus, Lead, Client, LeadStatus, TicketStatus } from '../types';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';

interface DashboardProps {
    onNavigate: (module: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
  const [summary, setSummary] = useState<string>("Analisando dados reais da sua empresa...");
  const [privacyMode, setPrivacyMode] = useState(true); // Default to protected
  
  // Consumindo DADOS REAIS do Contexto
  const { activities, toggleActivity, leads, clients, tickets, invoices, notifications, markNotificationRead, addSystemNotification } = useData();
  const { currentUser } = useAuth();

  // State for Stagnant Leads Modal (Pipeline)
  const [stagnantLeads, setStagnantLeads] = useState<Lead[]>([]);
  const [showStagnantModal, setShowStagnantModal] = useState(false);

  // State for Inactive Clients Modal (Retention - 30 Days)
  const [inactiveClients, setInactiveClients] = useState<Client[]>([]);
  const [showRetentionModal, setShowRetentionModal] = useState(false);

  // State for Contract Anniversary Modal (Next 3 Days)
  const [anniversaryClients, setAnniversaryClients] = useState<Client[]>([]);
  const [showAnniversaryModal, setShowAnniversaryModal] = useState(false);

  // State for Post-Sales Follow-up (15 Days after Won)
  const [postSalesLeads, setPostSalesLeads] = useState<Lead[]>([]);
  const [showPostSalesModal, setShowPostSalesModal] = useState(false);

  // Helper to mask values
  const maskValue = (value: string | number, type: 'currency' | 'number' | 'percent' = 'number') => {
      if (!privacyMode) {
          if (type === 'currency' && typeof value === 'number') return `R$ ${value.toLocaleString()}`;
          return value.toString();
      }
      
      if (type === 'currency') return 'R$ ••••••';
      if (type === 'percent') return '•••%';
      return '••••';
  };

  // --- CÁLCULOS DE MÉTRICAS REAIS ---
  
  // 1. MRR (Receita Mensal Recorrente) - Soma dos valores de contratos ativos
  const currentMRR = useMemo(() => {
      return clients
          .filter(c => c.status === 'Active')
          .reduce((acc, curr) => acc + (curr.totalTablePrice || curr.tablePrice || curr.ltv || 0), 0);
  }, [clients]);

  // 2. ARR (Receita Anual Recorrente)
  const currentARR = currentMRR * 12;

  // 3. Clientes Ativos
  const activeClientsCount = clients.filter(c => c.status === 'Active').length;

  // 4. Churn Rate (Simplificado: Inativos / Total)
  const churnRate = useMemo(() => {
      const total = clients.length;
      if (total === 0) return 0;
      const inactive = clients.filter(c => c.status === 'Inactive' || c.status === 'Churn Risk').length;
      return ((inactive / total) * 100).toFixed(1);
  }, [clients]);

  // 5. Dados do Funil de Vendas (Pipeline Real)
  const pipelineData = useMemo(() => [
      { name: 'Novo', value: leads.filter(l => l.status === LeadStatus.NEW).length },
      { name: 'Qualificado', value: leads.filter(l => l.status === LeadStatus.QUALIFIED).length },
      { name: 'Proposta', value: leads.filter(l => l.status === LeadStatus.PROPOSAL).length },
      { name: 'Negociação', value: leads.filter(l => l.status === LeadStatus.NEGOTIATION).length },
      { name: 'Fechado', value: leads.filter(l => l.status === LeadStatus.CLOSED_WON).length },
  ], [leads]);

  // 6. Dados do Gráfico de Receita (Baseado em Faturas Pagas nos últimos 6 meses)
  const revenueChartData = useMemo(() => {
      const months = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
      const today = new Date();
      const data = [];
      
      // Gera últimos 6 meses
      for (let i = 5; i >= 0; i--) {
          const d = new Date(today.getFullYear(), today.getMonth() - i, 1);
          const monthLabel = months[d.getMonth()];
          
          // Soma faturas PAGAS ou ENVIADAS deste mês
          const monthRevenue = invoices
              .filter(inv => {
                  const invDate = new Date(inv.dueDate);
                  return invDate.getMonth() === d.getMonth() && 
                         invDate.getFullYear() === d.getFullYear() &&
                         (inv.status === InvoiceStatus.PAID || inv.status === InvoiceStatus.SENT);
              })
              .reduce((acc, curr) => acc + curr.amount, 0);
          
          // Se não houver faturas, usamos o MRR atual como "projeção" para não deixar o gráfico vazio
          const value = monthRevenue > 0 ? monthRevenue : (i === 0 ? currentMRR : 0);

          data.push({ name: monthLabel, value: value });
      }
      return data;
  }, [invoices, currentMRR]);

  // 7. Tickets Críticos Reais
  const criticalTickets = tickets.filter(t => 
      (t.priority === 'Crítica' || t.priority === 'Alta') && 
      (t.status !== TicketStatus.CLOSED && t.status !== TicketStatus.RESOLVED)
  );

  // 8. Faturas Pendentes Reais
  const pendingInvoices = invoices
      .filter(i => i.status === InvoiceStatus.PENDING || i.status === InvoiceStatus.OVERDUE || i.status === InvoiceStatus.SENT)
      .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
      .slice(0, 10); // Aumentado limite para preencher espaço

  useEffect(() => {
    // Generate AI Summary based on REAL metrics
    const fetchSummary = async () => {
        if (currentMRR > 0 || leads.length > 0) {
            const result = await generateExecutiveSummary({
                mrr: currentMRR,
                active_clients: activeClientsCount,
                churn_rate: churnRate,
                open_leads: leads.length,
                critical_tickets: criticalTickets.length
            });
            setSummary(result);
        } else {
            setSummary("Adicione clientes e leads para que a IA possa gerar insights sobre seu negócio.");
        }
    };
    
    // Debounce to prevent too many API calls
    const timer = setTimeout(() => fetchSummary(), 2000);

    // CHECK PERMISSIONS & ALERTS
    const isAdminOrSales = ['admin', 'executive', 'sales'].includes(currentUser.role);

    if (isAdminOrSales) {
        // 1. STAGNANT LEADS CHECK (Pipeline)
        const fiveDaysAgo = new Date();
        fiveDaysAgo.setDate(fiveDaysAgo.getDate() - 5);

        const inactiveLeadsFound = leads.filter(l => {
            const lastContact = new Date(l.lastContact);
            return lastContact < fiveDaysAgo && l.status !== 'Ganho' && l.status !== 'Perdido';
        });

        if (inactiveLeadsFound.length > 0) {
            setStagnantLeads(inactiveLeadsFound);
            if (!sessionStorage.getItem('nexus_stagnant_leads_shown')) {
                setShowStagnantModal(true);
                sessionStorage.setItem('nexus_stagnant_leads_shown', 'true');
            }
        }

        // 2. INACTIVE CLIENTS CHECK (30 Days Retention)
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

        const inactiveClientsFound = clients.filter(c => {
            const lastContact = c.lastContact ? new Date(c.lastContact) : new Date(c.since);
            return lastContact < thirtyDaysAgo && c.status === 'Active';
        });

        if (inactiveClientsFound.length > 0) {
            setInactiveClients(inactiveClientsFound);
            if (!sessionStorage.getItem('nexus_retention_alert_shown')) {
                setShowRetentionModal(true);
                sessionStorage.setItem('nexus_retention_alert_shown', 'true');
                setShowStagnantModal(false); 
            }
        }

        // 3. POST-SALES FOLLOW-UP (15 Days after Won)
        const fifteenDaysAgo = new Date();
        fifteenDaysAgo.setDate(fifteenDaysAgo.getDate() - 15);
        
        const needsOnboardingContact = leads.filter(l => {
            if (l.status !== LeadStatus.CLOSED_WON) return false;
            // Check if last contact (likely the closing date or shortly after) is older than 15 days
            const lastContact = new Date(l.lastContact);
            return lastContact < fifteenDaysAgo;
        });

        if (needsOnboardingContact.length > 0) {
            setPostSalesLeads(needsOnboardingContact);
            if (!sessionStorage.getItem('nexus_postsales_alert_shown')) {
                setShowPostSalesModal(true);
                sessionStorage.setItem('nexus_postsales_alert_shown', 'true');
                setShowStagnantModal(false);
                setShowRetentionModal(false);
            }
        }
        
        // 4. CONTRACT ANNIVERSARY CHECK (Next 3 Days)
        const today = new Date();
        today.setHours(0,0,0,0);
        
        const threeDaysAhead = new Date(today);
        threeDaysAhead.setDate(today.getDate() + 3);

        const upcomingAnniversaries = clients.filter(c => {
            if(c.status !== 'Active') return false;
            
            const startDateStr = c.contractStartDate || c.since;
            if(!startDateStr) return false;
            
            const start = new Date(startDateStr);
            const currentYear = today.getFullYear();
            
            // Check anniversary for this year
            const anniversaryThisYear = new Date(currentYear, start.getMonth(), start.getDate());
            anniversaryThisYear.setHours(0,0,0,0);
            
            // Handle year rollover (if today is Dec 30, check Jan 1 of next year)
            const anniversaryNextYear = new Date(currentYear + 1, start.getMonth(), start.getDate());
            anniversaryNextYear.setHours(0,0,0,0);

            // Is it happening between today and next 3 days?
            const isSoonThisYear = anniversaryThisYear >= today && anniversaryThisYear <= threeDaysAhead;
            const isSoonNextYear = anniversaryNextYear >= today && anniversaryNextYear <= threeDaysAhead;

            return isSoonThisYear || isSoonNextYear;
        });

        if (upcomingAnniversaries.length > 0) {
            setAnniversaryClients(upcomingAnniversaries);
            if (!sessionStorage.getItem('nexus_anniversary_shown')) {
                setShowAnniversaryModal(true);
                sessionStorage.setItem('nexus_anniversary_shown', 'true');
                
                // Add System Notification
                addSystemNotification(
                    'Aniversário de Contrato', 
                    `${upcomingAnniversaries.length} cliente(s) completam ano de contrato nos próximos 3 dias.`, 
                    'info'
                );
            }
        }
    }
    return () => clearTimeout(timer);
  }, [currentMRR, activeClientsCount, churnRate, leads.length, criticalTickets.length, currentUser]);

  const unreadCount = notifications.filter(n => !n.read).length;

  const handleNavigateToLead = () => {
      setShowStagnantModal(false);
      setShowPostSalesModal(false);
      onNavigate('commercial');
  };

  const handleNavigateToClient = () => {
      setShowRetentionModal(false);
      setShowAnniversaryModal(false);
      onNavigate('clients');
  };

  return (
    <div className="p-4 md:p-6 flex flex-col gap-6 h-auto lg:h-full lg:overflow-hidden bg-slate-50">
      {/* Header Section - Shrink 0 */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center shrink-0">
        <div className="flex items-center gap-4">
            <div>
                <h1 className="text-2xl md:text-3xl font-bold text-slate-900 flex items-center gap-3">
                    Visão Executiva 
                    <button 
                        onClick={() => setPrivacyMode(!privacyMode)} 
                        className="text-slate-400 hover:text-blue-600 transition p-1 hover:bg-slate-200 rounded-full"
                        title={privacyMode ? "Mostrar valores" : "Ocultar valores"}
                    >
                        {privacyMode ? <EyeOff size={20} /> : <Eye size={20} />}
                    </button>
                </h1>
                <p className="text-sm md:text-base text-slate-500 mt-1">Bem-vindo de volta, {currentUser.name}.</p>
            </div>
        </div>
        <div className="mt-4 md:mt-0 bg-blue-50 border border-blue-100 p-3 rounded-lg max-w-xl">
            <div className="flex items-start gap-3">
                <div className="mt-1"><RefreshCw className="w-4 h-4 text-blue-600 animate-spin-slow" /></div>
                <div>
                    <h4 className="text-sm font-bold text-blue-900">Nexus AI Insights (Dados Reais)</h4>
                    <p className={`text-xs text-blue-800 mt-1 leading-snug ${privacyMode ? 'blur-[3px]' : ''} transition-all`}>{summary}</p>
                </div>
            </div>
        </div>
      </div>

      {/* KPI Grid - Shrink 0 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 shrink-0">
        <KPICard 
            title="MRR (Mensal)" 
            value={maskValue(currentMRR, 'currency')} 
            trend="Calculado sobre ativos" 
            trendUp={true} 
            icon={DollarSign} 
            color="bg-blue-500"
            tooltip="Receita Mensal Recorrente calculada pela soma dos valores mensais de todos os clientes ativos."
        />
        <KPICard 
            title="ARR (Anual)" 
            value={maskValue(currentARR, 'currency')} 
            trend="Projeção 12m" 
            trendUp={true} 
            icon={TrendingUp} 
            color="bg-emerald-500"
            tooltip="Receita Anual Recorrente (MRR x 12). Projeção financeira anualizada da base atual."
        />
        <KPICard 
            title="Clientes Ativos" 
            value={maskValue(activeClientsCount, 'number')} 
            trend={`${clients.length} Total`} 
            trendUp={true} 
            icon={Users} 
            color="bg-indigo-500"
            tooltip="Contagem total de clientes com status 'Active' no sistema."
        />
        <KPICard 
            title="Taxa de Churn/Inativos" 
            value={maskValue(churnRate, 'percent')} 
            trend={Number(churnRate) > 5 ? "Alto" : "Controlado"} 
            trendUp={Number(churnRate) < 5} 
            icon={AlertCircle} 
            color="bg-red-500"
            tooltip="Percentual de clientes inativos ou perdidos em relação à base total de clientes."
        />
      </div>

      {/* Main Content Grid - Flex 1 to fill height on Desktop, Stack on Mobile */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-6 min-h-0">
        
        {/* Column A & B combined for charts - Takes 2/3 space */}
        <div className="lg:col-span-2 flex flex-col gap-6 h-auto lg:h-full min-h-0">
          {/* Revenue Chart - Expands to fill available space */}
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 flex flex-col flex-1 min-h-[300px]">
            <SectionTitle title="Receita Realizada" subtitle="Baseado em faturas e projeção atual" />
            <div className={`flex-1 w-full min-h-0 mt-4 transition-all duration-300 ${privacyMode ? 'filter blur-sm select-none opacity-50' : ''}`}>
                <RevenueChart data={revenueChartData} />
            </div>
          </div>
          
          {/* Bottom Row: Funnel & Support - Fixed Height on Desktop (h-72), Stacked Auto on Mobile */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 h-auto md:h-72 shrink-0">
             <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 flex flex-col min-h-[250px]">
                <SectionTitle title="Funil de Vendas" subtitle="Leads reais por estágio" />
                <div className={`flex-1 w-full min-h-0 transition-all duration-300 ${privacyMode ? 'filter blur-sm select-none opacity-50' : ''}`}>
                    <PipelineFunnel data={pipelineData} />
                </div>
             </div>
             <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 flex flex-col overflow-hidden min-h-[250px]">
                <SectionTitle title="Tickets Críticos" subtitle="Atenção Imediata" />
                <div className="flex-1 overflow-y-auto custom-scrollbar space-y-3 mt-2">
                    {criticalTickets.length > 0 ? criticalTickets.map(ticket => (
                        <div key={ticket.id} className="flex items-center justify-between p-3 bg-red-50 rounded-lg border border-red-100">
                            <div className="min-w-0">
                                <p className="font-medium text-red-900 truncate">{ticket.subject}</p>
                                <p className="text-xs text-red-700 truncate">{privacyMode ? '••••••' : ticket.customer} • {new Date(ticket.created_at).toLocaleDateString()}</p>
                            </div>
                            <span className="text-[10px] font-bold bg-red-200 text-red-800 px-2 py-1 rounded whitespace-nowrap ml-2">{ticket.priority}</span>
                        </div>
                    )) : (
                        <div className="flex flex-col items-center justify-center h-full text-slate-400">
                             <CheckCircle size={32} className="mb-2 text-green-500 opacity-50"/>
                             <p className="text-sm">Nenhum ticket crítico aberto.</p>
                        </div>
                    )}
                </div>
             </div>
          </div>
        </div>

        {/* Column C: Tables & Alerts - Takes 1/3 space - Stacked Flex */}
        <div className="flex flex-col gap-6 h-auto lg:h-full min-h-0 overflow-hidden">
            
            {/* NOTIFICATIONS - Flex 1 */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 flex flex-col flex-1 min-h-[300px] lg:min-h-0 overflow-hidden">
                <div className="flex items-center justify-between mb-4 shrink-0">
                     <SectionTitle title="Alertas do Sistema" />
                     {unreadCount > 0 && (
                         <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">{unreadCount}</span>
                     )}
                </div>
                
                <div className="flex-1 overflow-y-auto custom-scrollbar space-y-3 pr-1">
                    {notifications.length === 0 ? (
                        <div className="text-center py-6 text-slate-400">
                            <Bell size={24} className="mx-auto mb-2 opacity-30"/>
                            <p className="text-sm">Tudo tranquilo.</p>
                        </div>
                    ) : (
                        notifications.map(notif => (
                            <div 
                                key={notif.id} 
                                className={`p-3 rounded-lg border text-sm transition-all cursor-pointer ${
                                    notif.read ? 'bg-slate-50 border-slate-100 opacity-60' : 'bg-white border-blue-100 shadow-sm'
                                }`}
                                onClick={() => markNotificationRead(notif.id)}
                            >
                                <div className="flex items-start gap-3">
                                    <div className={`mt-0.5 p-1.5 rounded-full shrink-0 ${
                                        notif.type === 'alert' ? 'bg-red-100 text-red-600' :
                                        notif.type === 'success' ? 'bg-green-100 text-green-600' :
                                        notif.type === 'warning' ? 'bg-amber-100 text-amber-600' :
                                        notif.type === 'info' ? 'bg-indigo-100 text-indigo-600' :
                                        'bg-blue-100 text-blue-600'
                                    }`}>
                                        <Zap size={14} />
                                    </div>
                                    <div className="min-w-0">
                                        <p className={`font-bold truncate ${notif.read ? 'text-slate-600' : 'text-slate-800'}`}>
                                            {notif.title}
                                        </p>
                                        <p className={`text-slate-500 text-xs mt-0.5 line-clamp-2 ${privacyMode ? 'blur-[3px]' : ''}`}>{notif.message}</p>
                                        <p className="text-[10px] text-slate-400 mt-1 text-right">
                                            {new Date(notif.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        ))
                    )}
                </div>
            </div>

            {/* Activities - Flex 1 */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 flex flex-col flex-1 min-h-[300px] lg:min-h-0 overflow-hidden">
                <div className="shrink-0 mb-2">
                    <SectionTitle title="Minhas Tarefas" />
                </div>
                <div className="flex-1 overflow-y-auto custom-scrollbar space-y-3 pr-1">
                    {activities.filter(a => !a.completed).length === 0 ? (
                        <div className="text-center py-6 text-slate-400">
                             <CheckCircle size={24} className="mx-auto mb-2 opacity-30"/>
                             <p className="text-sm">Nenhuma tarefa pendente.</p>
                        </div>
                    ) : (
                        activities.filter(a => !a.completed).map(act => (
                        <div key={act.id} className={`flex items-center gap-3 p-3 rounded-lg border transition bg-white border-slate-200 hover:border-blue-300`}>
                             <button onClick={() => toggleActivity(currentUser, act.id)}>
                                 <Circle size={18} className="text-slate-300 hover:text-blue-500"/>
                             </button>
                             <div className="flex-1 min-w-0">
                                 <p className="text-sm font-medium text-slate-800 truncate">{act.title}</p>
                                 <p className="text-xs text-slate-500 truncate">{act.type} • {privacyMode ? '••••' : act.relatedTo}</p>
                             </div>
                             <span className="text-[10px] font-mono text-slate-400 whitespace-nowrap">{new Date(act.dueDate).toLocaleDateString(undefined, { day: '2-digit', month: '2-digit'})}</span>
                        </div>
                    ))}
                </div>
                <button 
                    onClick={() => onNavigate('commercial')}
                    className="w-full mt-3 py-2 border border-dashed border-slate-300 rounded-lg text-slate-500 hover:text-blue-600 hover:border-blue-300 hover:bg-blue-50 transition text-xs font-medium shrink-0"
                >
                    + Gerenciar
                </button>
            </div>

            {/* Financial List - Flex 1 */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 flex flex-col flex-1 min-h-[300px] lg:min-h-0 overflow-hidden">
                <div className="shrink-0 mb-2">
                    <SectionTitle title="Faturas Pendentes" />
                </div>
                <div className="flex-1 overflow-y-auto custom-scrollbar pr-1">
                    <table className="w-full text-sm text-left">
                        <thead className="text-xs text-slate-500 uppercase bg-slate-50 sticky top-0">
                            <tr>
                                <th className="px-2 py-2">Cliente</th>
                                <th className="px-2 py-2 text-right">R$</th>
                                <th className="px-2 py-2 text-center">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            {pendingInvoices.length > 0 ? pendingInvoices.map(inv => (
                                <tr key={inv.id} className="border-b hover:bg-slate-50">
                                    <td className="px-2 py-2 font-medium text-slate-900 truncate max-w-[100px]" title={inv.customer}>{privacyMode ? '••••••' : inv.customer}</td>
                                    <td className="px-2 py-2 text-right whitespace-nowrap font-mono">{maskValue(inv.amount/1000, 'number')}k</td>
                                    <td className="px-2 py-2 text-center">
                                        <span className={`px-1.5 py-0.5 rounded-full text-[9px] font-bold uppercase
                                            ${inv.status === InvoiceStatus.OVERDUE ? 'bg-red-100 text-red-800' : 
                                              inv.status === InvoiceStatus.SENT ? 'bg-blue-100 text-blue-800' : 
                                              'bg-yellow-100 text-yellow-800'}`}>
                                            {inv.status === InvoiceStatus.OVERDUE ? 'Atrasado' : 
                                             inv.status === InvoiceStatus.SENT ? 'Enviado' : 'Pend.'}
                                        </span>
                                    </td>
                                </tr>
                            )) : (
                                <tr>
                                    <td colSpan={3} className="p-4 text-center text-slate-400 text-xs italic">
                                        Nenhuma pendência.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
      </div>

      {/* MODALS RETAINED AS IS - Content inside modals will typically be viewed intentionally, so masking there is less critical for the "glance" privacy request, but could be added if needed. */}
      {/* MODAL DE LEADS ESTAGNADOS (Pipeline Stall) */}
      {showStagnantModal && !showRetentionModal && !showAnniversaryModal && !showPostSalesModal && (
          <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4 backdrop-blur-sm animate-fade-in">
              <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl overflow-hidden animate-scale-in border-t-4 border-red-500">
                  <div className="p-6 border-b border-slate-100 flex justify-between items-start bg-red-50">
                      <div className="flex gap-4">
                          <div className="bg-red-100 p-3 rounded-full text-red-600 h-fit">
                              <AlertCircle size={24} />
                          </div>
                          <div>
                              <h2 className="text-xl font-bold text-slate-900">Alerta de Inatividade no Pipeline</h2>
                              <p className="text-sm text-red-700 font-medium mt-1">Existem {stagnantLeads.length} leads sem interação há mais de 5 dias.</p>
                          </div>
                      </div>
                      <button onClick={() => setShowStagnantModal(false)} className="text-slate-400 hover:text-slate-600 p-1 hover:bg-red-100 rounded-full transition"><X size={20}/></button>
                  </div>
                  
                  <div className="p-6 max-h-[60vh] overflow-y-auto">
                      <div className="space-y-3">
                          {stagnantLeads.map(lead => {
                              const days = Math.floor((new Date().getTime() - new Date(lead.lastContact).getTime()) / (1000 * 3600 * 24));
                              return (
                                  <div key={lead.id} className="flex items-center justify-between p-4 rounded-lg border border-red-100 bg-red-50/50 hover:bg-red-50 transition">
                                      <div>
                                          <p className="font-bold text-slate-800">{lead.name}</p>
                                          <p className="text-xs text-slate-500">{lead.company} • {maskValue(lead.value, 'currency')}</p>
                                      </div>
                                      <div className="flex items-center gap-4">
                                          <span className="flex items-center gap-1 text-xs font-bold text-red-600 bg-red-100 px-2 py-1 rounded border border-red-200">
                                              <Clock size={12}/> {days} dias parado
                                          </span>
                                          <button 
                                            onClick={handleNavigateToLead}
                                            className="text-xs bg-white border border-slate-200 text-slate-600 px-3 py-1.5 rounded hover:bg-blue-50 hover:text-blue-600 hover:border-blue-200 transition font-medium"
                                          >
                                              Ver Lead
                                          </button>
                                      </div>
                                  </div>
                              );
                          })}
                      </div>
                  </div>

                  <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
                      <button 
                          onClick={() => setShowStagnantModal(false)}
                          className="bg-slate-900 text-white px-6 py-2 rounded-lg font-bold hover:bg-slate-800 transition flex items-center gap-2"
                      >
                          Entendido <ArrowRight size={16}/>
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* MODAL DE ACOMPANHAMENTO PÓS-VENDA (15 DIAS) */}
      {showPostSalesModal && (
          <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4 backdrop-blur-sm animate-fade-in">
              <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl overflow-hidden animate-scale-in border-t-4 border-emerald-500">
                  <div className="p-6 border-b border-slate-100 flex justify-between items-start bg-emerald-50">
                      <div className="flex gap-4">
                          <div className="bg-emerald-100 p-3 rounded-full text-emerald-600 h-fit">
                              <Briefcase size={24} />
                          </div>
                          <div>
                              <h2 className="text-xl font-bold text-slate-900">Acompanhamento Pós-Venda</h2>
                              <p className="text-sm text-emerald-800 font-medium mt-1">
                                  {postSalesLeads.length} leads convertidos precisam de follow-up (15 dias sem contato).
                              </p>
                          </div>
                      </div>
                      <button onClick={() => setShowPostSalesModal(false)} className="text-slate-400 hover:text-slate-600 p-1 hover:bg-emerald-100 rounded-full transition"><X size={20}/></button>
                  </div>
                  
                  <div className="p-6 max-h-[60vh] overflow-y-auto">
                      <p className="text-slate-600 text-sm mb-4">Garanta o sucesso do cliente verificando a entrega e satisfação inicial.</p>
                      
                      <div className="space-y-3">
                          {postSalesLeads.map(lead => {
                              const days = Math.floor((new Date().getTime() - new Date(lead.lastContact).getTime()) / (1000 * 3600 * 24));
                              return (
                                  <div key={lead.id} className="flex items-center justify-between p-4 rounded-lg border border-emerald-100 bg-emerald-50/30 hover:bg-emerald-50 transition">
                                      <div>
                                          <p className="font-bold text-slate-800">{lead.name}</p>
                                          <p className="text-xs text-slate-500">{lead.company} • Convertido há {days} dias</p>
                                      </div>
                                      <div className="flex items-center gap-4">
                                          <button 
                                            onClick={handleNavigateToLead}
                                            className="text-xs flex items-center gap-1 bg-white border border-slate-200 text-slate-600 px-3 py-1.5 rounded hover:bg-emerald-50 hover:text-emerald-600 hover:border-emerald-200 transition font-medium shadow-sm"
                                          >
                                              <Phone size={12}/> Fazer Follow-up
                                          </button>
                                      </div>
                                  </div>
                              );
                          })}
                      </div>
                  </div>

                  <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end gap-3">
                      <button 
                          onClick={() => setShowPostSalesModal(false)}
                          className="bg-emerald-600 text-white px-6 py-2 rounded-lg font-bold hover:bg-emerald-700 transition flex items-center gap-2"
                      >
                          Verificar <ArrowRight size={16}/>
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* MODAL DE RETENÇÃO DE CLIENTES (Churn Risk - 30 Dias) */}
      {showRetentionModal && !showAnniversaryModal && !showPostSalesModal && (
          <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4 backdrop-blur-sm animate-fade-in">
              <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl overflow-hidden animate-scale-in border-t-4 border-amber-500">
                  <div className="p-6 border-b border-slate-100 flex justify-between items-start bg-amber-50">
                      <div className="flex gap-4">
                          <div className="bg-amber-100 p-3 rounded-full text-amber-600 h-fit">
                              <Clock size={24} />
                          </div>
                          <div>
                              <h2 className="text-xl font-bold text-slate-900">Alerta de Retenção (30 Dias)</h2>
                              <p className="text-sm text-amber-800 font-medium mt-1">
                                  Atenção: {inactiveClients.length} clientes ativos estão sem contato há mais de 30 dias.
                              </p>
                          </div>
                      </div>
                      <button onClick={() => setShowRetentionModal(false)} className="text-slate-400 hover:text-slate-600 p-1 hover:bg-amber-100 rounded-full transition"><X size={20}/></button>
                  </div>
                  
                  <div className="p-6 max-h-[60vh] overflow-y-auto">
                      <p className="text-slate-600 text-sm mb-4">Manter o relacionamento é crucial para evitar o Churn. Recomendamos contato imediato.</p>
                      
                      <div className="space-y-3">
                          {inactiveClients.map(client => {
                              const days = Math.floor((new Date().getTime() - new Date(client.lastContact || client.since).getTime()) / (1000 * 3600 * 24));
                              return (
                                  <div key={client.id} className="flex items-center justify-between p-4 rounded-lg border border-amber-100 bg-amber-50/30 hover:bg-amber-50 transition">
                                      <div>
                                          <p className="font-bold text-slate-800">{client.name}</p>
                                          <p className="text-xs text-slate-500">{client.contactPerson}</p>
                                      </div>
                                      <div className="flex items-center gap-4">
                                          <span className="flex items-center gap-1 text-xs font-bold text-amber-700 bg-amber-100 px-2 py-1 rounded border border-amber-200">
                                              <Clock size={12}/> {days} dias sem contato
                                          </span>
                                          <button 
                                            onClick={handleNavigateToClient}
                                            className="text-xs flex items-center gap-1 bg-white border border-slate-200 text-slate-600 px-3 py-1.5 rounded hover:bg-blue-50 hover:text-blue-600 hover:border-blue-200 transition font-medium shadow-sm"
                                          >
                                              <Phone size={12}/> Contatar
                                          </button>
                                      </div>
                                  </div>
                              );
                          })}
                      </div>
                  </div>

                  <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end gap-3">
                      <button 
                          onClick={() => setShowRetentionModal(false)}
                          className="px-4 py-2 text-slate-600 font-medium hover:bg-slate-200 rounded-lg transition"
                      >
                          Lembrar Depois
                      </button>
                      <button 
                          onClick={handleNavigateToClient}
                          className="bg-blue-600 text-white px-6 py-2 rounded-lg font-bold hover:bg-blue-700 transition flex items-center gap-2"
                      >
                          Ver Carteira <ArrowRight size={16}/>
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* MODAL DE ANIVERSÁRIO DE CONTRATO */}
      {showAnniversaryModal && (
          <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4 backdrop-blur-sm animate-fade-in">
              <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl overflow-hidden animate-scale-in border-t-4 border-indigo-500">
                  <div className="p-6 border-b border-slate-100 flex justify-between items-start bg-indigo-50">
                      <div className="flex gap-4">
                          <div className="bg-indigo-100 p-3 rounded-full text-indigo-600 h-fit">
                              <PartyPopper size={24} />
                          </div>
                          <div>
                              <h2 className="text-xl font-bold text-slate-900">Aniversário de Contrato</h2>
                              <p className="text-sm text-indigo-800 font-medium mt-1">
                                  {anniversaryClients.length} clientes completam mais um ano conosco nos próximos 3 dias!
                              </p>
                          </div>
                      </div>
                      <button onClick={() => setShowAnniversaryModal(false)} className="text-slate-400 hover:text-slate-600 p-1 hover:bg-indigo-100 rounded-full transition"><X size={20}/></button>
                  </div>
                  
                  <div className="p-6 max-h-[60vh] overflow-y-auto">
                      <p className="text-slate-600 text-sm mb-4">Aproveite a oportunidade para enviar uma mensagem de agradecimento ou discutir renovações.</p>
                      
                      <div className="space-y-3">
                          {anniversaryClients.map(client => {
                              const start = new Date(client.contractStartDate || client.since);
                              const years = new Date().getFullYear() - start.getFullYear();
                              
                              return (
                                  <div key={client.id} className="flex items-center justify-between p-4 rounded-lg border border-indigo-100 bg-indigo-50/30 hover:bg-indigo-50 transition">
                                      <div>
                                          <p className="font-bold text-slate-800">{client.name}</p>
                                          <p className="text-xs text-slate-500">Início: {start.toLocaleDateString()}</p>
                                      </div>
                                      <div className="flex items-center gap-4">
                                          <span className="flex items-center gap-1 text-xs font-bold text-indigo-700 bg-indigo-100 px-2 py-1 rounded border border-indigo-200">
                                              <PartyPopper size={12}/> Completando {years > 0 ? years : 1} ano(s)
                                          </span>
                                          <button 
                                            onClick={handleNavigateToClient}
                                            className="text-xs flex items-center gap-1 bg-white border border-slate-200 text-slate-600 px-3 py-1.5 rounded hover:bg-indigo-50 hover:text-indigo-600 hover:border-indigo-200 transition font-medium shadow-sm"
                                          >
                                              <Phone size={12}/> Parabenizar
                                          </button>
                                      </div>
                                  </div>
                              );
                          })}
                      </div>
                  </div>

                  <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end gap-3">
                      <button 
                          onClick={() => setShowAnniversaryModal(false)}
                          className="bg-indigo-600 text-white px-6 py-2 rounded-lg font-bold hover:bg-indigo-700 transition flex items-center gap-2"
                      >
                          Fechar <ArrowRight size={16}/>
                      </button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};
