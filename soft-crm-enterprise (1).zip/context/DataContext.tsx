
import React, { createContext, useState, useContext, ReactNode, useEffect, useCallback } from 'react';
import { Lead, Ticket, Issue, Invoice, LeadStatus, InvoiceStatus, Client, Activity, AuditLog, User, Note, Proposal, Notification, Product, ClientDocument } from '../types';
import { MOCK_LEADS, MOCK_TICKETS, MOCK_ISSUES, MOCK_INVOICES, MOCK_CLIENTS, MOCK_ACTIVITIES, MOCK_LOGS, MOCK_PROPOSALS, MOCK_PRODUCTS, MOCK_DOCUMENTS } from '../constants';
import { getSupabase } from '../services/supabaseClient';
import { RealtimePostgresChangesPayload } from '@supabase/supabase-js';

// VERSÃO DO BANCO DE DADOS LOCAL
const DB_VERSION = 'v5-enterprise-features';

interface DataContextType {
  leads: Lead[];
  tickets: Ticket[];
  issues: Issue[];
  invoices: Invoice[];
  clients: Client[];
  activities: Activity[];
  logs: AuditLog[];
  proposals: Proposal[];
  notifications: Notification[];
  products: Product[];
  clientDocuments: ClientDocument[];
  
  updateLeadStatus: (user: User, id: string, newStatus: LeadStatus) => void;
  updateInvoiceStatus: (user: User, id: string, newStatus: InvoiceStatus) => void;
  addLead: (user: User, lead: Lead) => void;
  addClient: (user: User, client: Client) => void;
  addClientsBulk: (user: User, newClients: Client[]) => void;
  updateClient: (user: User, client: Client) => void;
  removeClient: (user: User, clientId: string, justification: string) => void; 
  
  updateIssue: (user: User, id: string, updates: Partial<Issue>) => void;
  addIssueNote: (user: User, issueId: string, text: string) => void;

  toggleActivity: (user: User, id: string) => void;
  addActivity: (user: User, activity: Activity) => void;
  
  addProposal: (user: User, proposal: Proposal) => void;

  addProduct: (user: User, product: Product) => void;
  removeProduct: (user: User, id: string) => void;
  addClientDocument: (user: User, doc: ClientDocument) => void;
  removeClientDocument: (user: User, id: string) => void;

  addLog: (log: AuditLog) => void;
  addSystemNotification: (title: string, message: string, type: 'info' | 'warning' | 'success' | 'alert', relatedTo?: string) => void;
  markNotificationRead: (id: string) => void;
  
  isSyncing: boolean; 
  lastSyncTime: Date | null;
  refreshData: () => Promise<void>; 
  syncLocalToCloud: (specificTable?: string) => Promise<void>; 
}

const DataContext = createContext<DataContextType | undefined>(undefined);

const loadInitialState = <T,>(key: string, fallback: T): T => {
  try {
    const saved = localStorage.getItem(`nexus_${key}`);
    if (!saved || saved === "undefined") return fallback;
    return JSON.parse(saved);
  } catch (e) {
    return fallback;
  }
};

const safeMerge = <T extends { id: string }>(localData: T[], remoteData: T[] | null): T[] => {
    if (!remoteData || remoteData.length === 0) {
        return localData; 
    }
    const mergedMap = new Map<string, T>();
    localData.forEach(item => mergedMap.set(item.id, item));
    remoteData.forEach(item => mergedMap.set(item.id, item));
    return Array.from(mergedMap.values());
};

export const DataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [isInitialized, setIsInitialized] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState<Date | null>(null);

  const [leads, setLeads] = useState<Lead[]>(() => loadInitialState('leads', MOCK_LEADS));
  const [tickets, setTickets] = useState<Ticket[]>(() => loadInitialState('tickets', MOCK_TICKETS));
  const [issues, setIssues] = useState<Issue[]>(() => loadInitialState('issues', MOCK_ISSUES));
  const [invoices, setInvoices] = useState<Invoice[]>(() => loadInitialState('invoices', MOCK_INVOICES));
  const [clients, setClients] = useState<Client[]>(() => loadInitialState('clients', MOCK_CLIENTS));
  const [activities, setActivities] = useState<Activity[]>(() => loadInitialState('activities', MOCK_ACTIVITIES));
  const [logs, setLogs] = useState<AuditLog[]>(() => loadInitialState('logs', MOCK_LOGS));
  const [proposals, setProposals] = useState<Proposal[]>(() => loadInitialState('proposals', MOCK_PROPOSALS));
  const [notifications, setNotifications] = useState<Notification[]>(() => loadInitialState('notifications', []));
  
  // Novos Estados
  const [products, setProducts] = useState<Product[]>(() => loadInitialState('products', MOCK_PRODUCTS));
  const [clientDocuments, setClientDocuments] = useState<ClientDocument[]>(() => loadInitialState('client_documents', MOCK_DOCUMENTS));

  const addSystemNotification = useCallback((title: string, message: string, type: 'info' | 'warning' | 'success' | 'alert', relatedTo?: string) => {
      const newNotif: Notification = {
          id: `NOTIF-${Date.now()}-${Math.random()}`,
          title,
          message,
          type,
          timestamp: new Date().toISOString(),
          read: false,
          relatedTo
      };
      setNotifications(prev => [newNotif, ...prev]);
  }, []);

  const dbUpsert = async (table: string, data: any) => {
      const supabase = getSupabase();
      if (supabase) {
          const { error } = await supabase.from(table).upsert(data);
          if (error) {
              console.error(`Erro ao fazer Upsert em ${table}:`, error);
              addSystemNotification('Erro de Sincronização', `Falha ao salvar dados em ${table}. Verifique permissões (RLS) no Supabase. Erro: ${error.message}`, 'alert');
          }
      }
  };

  const dbDelete = async (table: string, id: string) => {
      const supabase = getSupabase();
      if (supabase) {
          const { error } = await supabase.from(table).delete().eq('id', id);
          if (error) {
              console.error(`Erro ao deletar de ${table}:`, error);
              addSystemNotification('Erro de Exclusão', `Falha ao remover item da nuvem: ${error.message}`, 'alert');
          }
      }
  };

  const syncLocalToCloud = async (specificTable?: string) => {
    const supabase = getSupabase();
    if (!supabase) {
        addSystemNotification('Erro de Conexão', 'Supabase não configurado. Verifique Configurações > Integrações.', 'alert');
        return;
    }
    setIsSyncing(true);

    // Mapeamento de nome da tabela -> dados do estado
    const tablesData: Record<string, any[]> = {
        'leads': leads,
        'clients': clients,
        'tickets': tickets,
        'invoices': invoices,
        'activities': activities,
        'issues': issues,
        'proposals': proposals,
        'products': products,
        'client_documents': clientDocuments,
        'audit_logs': logs
    };

    const targetTables = specificTable ? [specificTable] : Object.keys(tablesData);
    let successCount = 0;
    let errorCount = 0;

    for (const table of targetTables) {
        const data = tablesData[table];
        // Skip empty tables to save bandwidth
        if (!data || data.length === 0) continue;

        try {
            // Upload em chunks de 50 para evitar timeout/payload limit
            const chunkSize = 50; 
            for (let i = 0; i < data.length; i += chunkSize) {
                const chunk = data.slice(i, i + chunkSize);
                const { error } = await supabase.from(table).upsert(chunk);
                if (error) throw error;
            }
            successCount++;
        } catch (e: any) {
            console.error(`Erro ao sincronizar ${table}:`, e);
            errorCount++;
            if (specificTable) {
                addSystemNotification('Erro de Upload', `Falha em ${table}: ${e.message}`, 'alert');
            }
        }
    }

    if (!specificTable) {
        if (errorCount === 0) {
            addSystemNotification('Backup Concluído', `Todos os dados locais foram salvos na nuvem.`, 'success');
        } else {
            addSystemNotification('Backup Parcial', `${successCount} tabelas salvas. ${errorCount} falharam.`, 'warning');
        }
    } else if (errorCount === 0) {
        addSystemNotification('Tabela Sincronizada', `Tabela ${specificTable} atualizada com sucesso.`, 'success');
    }

    setLastSyncTime(new Date());
    setIsSyncing(false);
  }

  const fetchRemoteData = useCallback(async () => {
      const supabase = getSupabase();
      if (!supabase) return;

      setIsSyncing(true);
      try {
          const [
              { data: rLeads }, 
              { data: rClients },
              { data: rTickets },
              { data: rInvoices },
              { data: rActivities },
              { data: rIssues },
              { data: rProposals },
              { data: rProducts },
              { data: rDocs }
          ] = await Promise.all([
              supabase.from('leads').select('*'),
              supabase.from('clients').select('*'),
              supabase.from('tickets').select('*'),
              supabase.from('invoices').select('*'),
              supabase.from('activities').select('*'),
              supabase.from('issues').select('*'),
              supabase.from('proposals').select('*'),
              supabase.from('products').select('*'),
              supabase.from('client_documents').select('*')
          ]);

          setLeads(prev => safeMerge(prev, rLeads));
          setClients(prev => safeMerge(prev, rClients));
          setTickets(prev => safeMerge(prev, rTickets));
          setInvoices(prev => safeMerge(prev, rInvoices));
          setActivities(prev => safeMerge(prev, rActivities));
          setIssues(prev => safeMerge(prev, rIssues));
          setProposals(prev => safeMerge(prev, rProposals));
          setProducts(prev => safeMerge(prev, rProducts));
          setClientDocuments(prev => safeMerge(prev, rDocs));
          
          setLastSyncTime(new Date());

      } catch (err) {
          console.error("Erro ao sincronizar com Supabase:", err);
      } finally {
          setIsSyncing(false);
      }
  }, []);

  useEffect(() => {
      const initApp = async () => {
          const currentVersion = localStorage.getItem('nexus_db_version');
          
          if (currentVersion !== DB_VERSION) {
              const savedUrl = localStorage.getItem('nexus_supabase_url');
              const savedKey = localStorage.getItem('nexus_supabase_key');
              localStorage.clear(); 
              if (savedUrl) localStorage.setItem('nexus_supabase_url', savedUrl);
              if (savedKey) localStorage.setItem('nexus_supabase_key', savedKey);
              localStorage.setItem('nexus_db_version', DB_VERSION);
          }
          await fetchRemoteData();
          setIsInitialized(true);
      };
      initApp();
  }, [fetchRemoteData]);

  useEffect(() => {
    if (!isInitialized) return;
    const intervalId = setInterval(() => { fetchRemoteData(); }, 60000);
    return () => clearInterval(intervalId);
  }, [isInitialized, fetchRemoteData]);

  useEffect(() => {
      const handleVisibilityChange = () => { if (document.visibilityState === 'visible') fetchRemoteData(); };
      window.addEventListener("focus", fetchRemoteData);
      document.addEventListener("visibilitychange", handleVisibilityChange);
      return () => {
          window.removeEventListener("focus", fetchRemoteData);
          document.removeEventListener("visibilitychange", handleVisibilityChange);
      };
  }, [fetchRemoteData]);

  // Realtime
  useEffect(() => {
    if (!isInitialized) return;
    const supabase = getSupabase();
    if (!supabase) return;

    const handleRealtime = <T extends { id: string }>(payload: RealtimePostgresChangesPayload<T>, setState: React.Dispatch<React.SetStateAction<T[]>>) => {
        if (payload.eventType === 'INSERT') {
            setState(prev => { if (prev.some(item => item.id === payload.new.id)) return prev; return [...prev, payload.new as T]; });
        } else if (payload.eventType === 'UPDATE') {
            setState(prev => prev.map(item => item.id === payload.new.id ? payload.new as T : item));
        } else if (payload.eventType === 'DELETE') {
            setState(prev => prev.filter(item => item.id !== payload.old.id));
        }
    };

    const channel = supabase.channel('nexus_db_changes_v5')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'clients' }, (payload) => handleRealtime(payload, setClients))
        .on('postgres_changes', { event: '*', schema: 'public', table: 'leads' }, (payload) => handleRealtime(payload, setLeads))
        .on('postgres_changes', { event: '*', schema: 'public', table: 'tickets' }, (payload) => handleRealtime(payload, setTickets))
        .on('postgres_changes', { event: '*', schema: 'public', table: 'invoices' }, (payload) => handleRealtime(payload, setInvoices))
        .on('postgres_changes', { event: '*', schema: 'public', table: 'activities' }, (payload) => handleRealtime(payload, setActivities))
        .on('postgres_changes', { event: '*', schema: 'public', table: 'issues' }, (payload) => handleRealtime(payload, setIssues))
        .on('postgres_changes', { event: '*', schema: 'public', table: 'proposals' }, (payload) => handleRealtime(payload, setProposals))
        .on('postgres_changes', { event: '*', schema: 'public', table: 'products' }, (payload) => handleRealtime(payload, setProducts))
        .on('postgres_changes', { event: '*', schema: 'public', table: 'client_documents' }, (payload) => handleRealtime(payload, setClientDocuments))
        .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [isInitialized]);

  // Persistence
  useEffect(() => { if(isInitialized) localStorage.setItem('nexus_leads', JSON.stringify(leads)); }, [leads, isInitialized]);
  useEffect(() => { if(isInitialized) localStorage.setItem('nexus_tickets', JSON.stringify(tickets)); }, [tickets, isInitialized]);
  useEffect(() => { if(isInitialized) localStorage.setItem('nexus_issues', JSON.stringify(issues)); }, [issues, isInitialized]);
  useEffect(() => { if(isInitialized) localStorage.setItem('nexus_invoices', JSON.stringify(invoices)); }, [invoices, isInitialized]);
  useEffect(() => { if(isInitialized) localStorage.setItem('nexus_clients', JSON.stringify(clients)); }, [clients, isInitialized]);
  useEffect(() => { if(isInitialized) localStorage.setItem('nexus_activities', JSON.stringify(activities)); }, [activities, isInitialized]);
  useEffect(() => { if(isInitialized) localStorage.setItem('nexus_logs', JSON.stringify(logs)); }, [logs, isInitialized]);
  useEffect(() => { if(isInitialized) localStorage.setItem('nexus_proposals', JSON.stringify(proposals)); }, [proposals, isInitialized]);
  useEffect(() => { if(isInitialized) localStorage.setItem('nexus_products', JSON.stringify(products)); }, [products, isInitialized]);
  useEffect(() => { if(isInitialized) localStorage.setItem('nexus_client_documents', JSON.stringify(clientDocuments)); }, [clientDocuments, isInitialized]);
  useEffect(() => { if(isInitialized) localStorage.setItem('nexus_notifications', JSON.stringify(notifications)); }, [notifications, isInitialized]);

  const logAction = (user: User, action: string, details: string, module: string) => {
    const newLog: AuditLog = {
      id: `LOG-${Date.now()}`, timestamp: new Date().toISOString(), userId: user.id, userName: user.name, action, details, module
    };
    setLogs(prev => [newLog, ...prev]);
    dbUpsert('audit_logs', newLog);
  };

  const addLog = (log: AuditLog) => { setLogs(prev => [log, ...prev]); dbUpsert('audit_logs', log); }

  const markNotificationRead = (id: string) => { setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n)); };

  const updateLeadStatus = (user: User, id: string, newStatus: LeadStatus) => {
    setLeads(prev => prev.map(lead => lead.id === id ? { ...lead, status: newStatus } : lead));
    const lead = leads.find(l => l.id === id);
    if (lead) {
        logAction(user, 'Update Lead Status', `Lead ${lead.name} movido para ${newStatus}`, 'Comercial');
        dbUpsert('leads', { ...lead, status: newStatus });
    }
  };

  const updateInvoiceStatus = (user: User, id: string, newStatus: InvoiceStatus) => {
    setInvoices(prev => prev.map(inv => inv.id === id ? { ...inv, status: newStatus } : inv));
    const inv = invoices.find(i => i.id === id);
    if (inv) {
        logAction(user, 'Update Invoice Status', `Fatura ${id} alterada para ${newStatus}`, 'Financeiro');
        dbUpsert('invoices', { ...inv, status: newStatus });
    }
  };

  const addLead = (user: User, lead: Lead) => {
    setLeads(prev => [...prev, lead]); dbUpsert('leads', lead); logAction(user, 'Create Lead', `Novo lead criado: ${lead.name}`, 'Comercial');
  };

  const addClient = (user: User, client: Client) => {
    setClients(prev => [...prev, client]); dbUpsert('clients', client); logAction(user, 'Create Client', `Novo cliente adicionado: ${client.name}`, 'Clientes');
  };

  const addClientsBulk = (user: User, newClients: Client[]) => {
    setClients(prev => { const uniqueNew = newClients.filter(nc => !prev.some(pc => pc.id === nc.id)); return [...prev, ...uniqueNew]; });
    const supabase = getSupabase();
    if(supabase) supabase.from('clients').upsert(newClients);
    logAction(user, 'Bulk Import', `Importados ${newClients.length} clientes via CSV`, 'Clientes');
  };

  const removeClient = (user: User, clientId: string, justification: string) => {
      const clientName = clients.find(c => c.id === clientId)?.name || 'Desconhecido';
      setClients(prev => prev.filter(c => c.id !== clientId));
      dbDelete('clients', clientId);
      logAction(user, 'Delete Client', `Cliente ${clientName} removido. Motivo: ${justification}`, 'Clientes');
  };

  const updateClient = (user: User, updatedClient: Client) => {
    setClients(prev => prev.map(c => c.id === updatedClient.id ? updatedClient : c));
    logAction(user, 'Update Client', `Dados de ${updatedClient.name} atualizados`, 'Clientes');
    dbUpsert('clients', updatedClient);
  };

  const updateIssue = (user: User, id: string, updates: Partial<Issue>) => {
    setIssues(prev => prev.map(issue => issue.id === id ? { ...issue, ...updates } : issue));
    const issue = issues.find(i => i.id === id);
    if(issue) {
        logAction(user, 'Update Issue', `Issue ${id} atualizada`, 'Desenvolvimento');
        dbUpsert('issues', { ...issue, ...updates });
    }
  };

  const addIssueNote = (user: User, issueId: string, text: string) => {
    const newNote: Note = { id: `NOTE-${Date.now()}`, text, author: user.name, created_at: new Date().toISOString() };
    const issue = issues.find(i => i.id === issueId);
    if(issue) {
        const updatedIssue = { ...issue, notes: [...(issue.notes || []), newNote] };
        dbUpsert('issues', updatedIssue);
        setIssues(prev => prev.map(i => i.id === issueId ? updatedIssue : i));
        logAction(user, 'Add Note', `Nova nota na issue ${issueId}`, 'Desenvolvimento');
    }
  };

  const toggleActivity = (user: User, id: string) => {
      const activity = activities.find(a => a.id === id);
      if (!activity) return;
      const updatedActivity = { ...activity, completed: !activity.completed };
      setActivities(prev => prev.map(act => act.id === id ? updatedActivity : act));
      dbUpsert('activities', updatedActivity);
  }

  const addActivity = (user: User, activity: Activity) => {
      setActivities(prev => [activity, ...prev]); dbUpsert('activities', activity);
  };

  const addProposal = (user: User, proposal: Proposal) => {
    setProposals(prev => [proposal, ...prev]); dbUpsert('proposals', proposal); logAction(user, 'Create Proposal', `Nova proposta gerada para ${proposal.companyName}`, 'Propostas');
  };

  // --- MÉTODOS PARA PRODUTOS E DOCUMENTOS ---
  const addProduct = (user: User, product: Product) => {
      setProducts(prev => [...prev, product]);
      dbUpsert('products', product);
      logAction(user, 'Add Product', `Produto ${product.sku} adicionado`, 'Configurações');
  };

  const removeProduct = (user: User, id: string) => {
      setProducts(prev => prev.filter(p => p.id !== id));
      dbDelete('products', id);
      logAction(user, 'Delete Product', `Produto ${id} removido`, 'Configurações');
  };

  const addClientDocument = (user: User, doc: ClientDocument) => {
      setClientDocuments(prev => [...prev, doc]);
      dbUpsert('client_documents', doc);
      logAction(user, 'Upload Document', `Documento ${doc.title} anexado`, 'Clientes');
  };

  const removeClientDocument = (user: User, id: string) => {
      setClientDocuments(prev => prev.filter(d => d.id !== id));
      dbDelete('client_documents', id);
      logAction(user, 'Delete Document', `Documento ${id} removido`, 'Clientes');
  };

  if (!isInitialized) return <div className="h-screen flex items-center justify-center">Carregando Nexus CRM...</div>;

  return (
    <DataContext.Provider value={{ 
      leads, tickets, issues, invoices, clients, activities, logs, proposals, notifications, products, clientDocuments,
      updateLeadStatus, updateInvoiceStatus, addLead, addClient, addClientsBulk, updateClient, removeClient,
      updateIssue, addIssueNote, toggleActivity, addActivity, addProposal, addLog, markNotificationRead, addSystemNotification,
      addProduct, removeProduct, addClientDocument, removeClientDocument,
      isSyncing, lastSyncTime, refreshData: fetchRemoteData, syncLocalToCloud
    }}>
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) throw new Error('useData must be used within a DataProvider');
  return context;
};
