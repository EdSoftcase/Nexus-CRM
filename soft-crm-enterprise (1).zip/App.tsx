
import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { DataProvider } from './context/DataContext';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './pages/Dashboard';
import { Commercial } from './pages/Commercial';
import { Support } from './pages/Support';
import { Settings } from './pages/Settings';
import { Development } from './pages/Development';
import { Finance } from './pages/Finance';
import { Reports } from './pages/Reports';
import { Clients } from './pages/Clients';
import { CustomerSuccess } from './pages/CustomerSuccess';
import { Proposals } from './pages/Proposals';
import { Retention } from './pages/Retention'; 
import { Calendar } from './pages/Calendar';
import { Login } from './pages/Login';
import { CommandPalette } from './components/CommandPalette';
import { SubscriptionLock } from './components/SubscriptionLock'; // Novo componente
import { Menu, Loader2 } from 'lucide-react';

const AppContent: React.FC = () => {
  const [activeModule, setActiveModule] = useState<string>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false); 
  const { hasPermission, currentUser, currentOrganization, loading } = useAuth();

  const handleModuleChange = (module: string) => {
      setActiveModule(module);
  };

  if (loading) {
      return (
          <div className="h-screen w-full flex flex-col items-center justify-center bg-slate-50 text-slate-400 gap-3">
              <Loader2 size={40} className="animate-spin text-blue-600"/>
              <p className="text-sm font-medium">Carregando Nexus CRM...</p>
          </div>
      );
  }

  // Se não estiver logado, mostra Login
  if (!currentUser) {
      return <Login />;
  }

  // --- LICENSE GATING / PAYWALL ---
  // Verifica se a organização tem status válido. Se não, bloqueia tudo.
  // Permitimos 'active', 'trial' e null (para evitar bloqueio acidental em setups legados, mas idealmente seria restrito)
  if (currentOrganization?.subscription_status && 
      !['active', 'trial'].includes(currentOrganization.subscription_status)) {
      return <SubscriptionLock status={currentOrganization.subscription_status} />;
  }

  const renderModule = () => {
    // Basic permissions check before rendering (View Access)
    // Dashboard and Calendar are usually open to everyone or have minimal checks
    if (activeModule !== 'settings' && activeModule !== 'dashboard' && activeModule !== 'calendar' && !hasPermission(activeModule, 'view')) {
        return (
            <div className="flex h-full items-center justify-center text-slate-500">
                <div className="text-center">
                    <h2 className="text-2xl font-bold text-slate-800">Acesso Negado</h2>
                    <p>Seu perfil não tem permissão para visualizar este módulo.</p>
                </div>
            </div>
        );
    }

    switch (activeModule) {
      case 'dashboard': return <Dashboard onNavigate={handleModuleChange} />;
      case 'calendar': return <Calendar />;
      case 'commercial': return <Commercial />;
      case 'clients': return <Clients />;
      case 'customer-success': return <CustomerSuccess />;
      case 'retention': return <Retention />;
      case 'support': return <Support />;
      case 'dev': return <Development />;
      case 'finance': return <Finance />;
      case 'reports': return <Reports />;
      case 'proposals': return <Proposals />; 
      case 'settings': return <Settings />;
      default: return <Dashboard onNavigate={handleModuleChange} />;
    }
  };

  return (
    <div className="flex h-[100dvh] bg-slate-50 font-sans overflow-hidden">
      <CommandPalette onNavigate={handleModuleChange} onAction={(action) => console.log(action)} />
      
      <Sidebar 
        activeModule={activeModule} 
        onChangeModule={handleModuleChange} 
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
      />
      
      {/* Main Content Area */}
      <main className="flex-1 h-full flex flex-col bg-slate-50 overflow-hidden relative w-full">
        {/* Mobile Header Trigger */}
        <div className="md:hidden bg-slate-900 text-white p-4 flex items-center justify-between shrink-0 z-10">
            <button onClick={() => setIsSidebarOpen(true)} className="p-2 hover:bg-slate-800 rounded">
                <Menu size={24} />
            </button>
            <span className="font-bold text-lg">Nexus CRM</span>
            <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-xs font-bold">
                {currentUser.avatar}
            </div>
        </div>

        <div className="flex-1 overflow-y-auto w-full pb-24 md:pb-0">
            {renderModule()}
        </div>
      </main>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <DataProvider>
        <AppContent />
      </DataProvider>
    </AuthProvider>
  );
}

export default App;
