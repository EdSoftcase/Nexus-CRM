import { createClient, SupabaseClient } from '@supabase/supabase-js';

const SUPABASE_URL_KEY = 'nexus_supabase_url';
const SUPABASE_KEY_KEY = 'nexus_supabase_key';

export const getSupabaseConfig = () => {
  // Prioridade: 1. LocalStorage (Configuração Manual do Usuário) -> 2. Variável de Ambiente (Build/Define)
  // @ts-ignore
  const envUrl = process.env.VITE_SUPABASE_URL;
  // @ts-ignore
  const envKey = process.env.VITE_SUPABASE_KEY;

  return {
    url: localStorage.getItem(SUPABASE_URL_KEY) || envUrl || '',
    key: localStorage.getItem(SUPABASE_KEY_KEY) || envKey || ''
  };
};

export const saveSupabaseConfig = (url: string, key: string) => {
  if (!url) localStorage.removeItem(SUPABASE_URL_KEY);
  else localStorage.setItem(SUPABASE_URL_KEY, url);
  
  if (!key) localStorage.removeItem(SUPABASE_KEY_KEY);
  else localStorage.setItem(SUPABASE_KEY_KEY, key);
  
  // Force reload of instance on next get
  supabaseInstance = null;
};

let supabaseInstance: SupabaseClient | null = null;

export const getSupabase = (): SupabaseClient | null => {
  if (supabaseInstance) return supabaseInstance;

  const { url, key } = getSupabaseConfig();
  if (url && key) {
    try {
        supabaseInstance = createClient(url, key);
        return supabaseInstance;
    } catch (e) {
        console.error("Failed to init Supabase", e);
        return null;
    }
  }
  return null;
};

export const testSupabaseConnection = async (): Promise<{ success: boolean; message: string }> => {
    const client = getSupabase();
    if (!client) return { success: false, message: "Cliente não inicializado. Verifique as credenciais." };
    
    try {
        // Attempt to fetch session or simple health check
        const { error } = await client.auth.getSession();
        if (error) throw error;
        
        return { success: true, message: "Conexão estabelecida com sucesso!" };
    } catch (e: any) {
        console.error(e);
        return { success: false, message: `Erro de conexão: ${e.message || 'Desconhecido'}` };
    }
};