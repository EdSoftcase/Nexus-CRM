
import React, { createContext, useState, useContext, ReactNode, useEffect } from 'react';
import { User, Role, PermissionMatrix, PermissionAction, Organization } from '../types';
import { MOCK_USERS, MOCK_ORGANIZATIONS } from '../constants';
import { getSupabase } from '../services/supabaseClient';

// LISTA DE EMAILS DOS DONOS DA PLATAFORMA (SUPER ADMINS)
// Apenas estes emails podem ver a aba "Gestão SaaS" e "Zona de Perigo"
const SUPER_ADMIN_EMAILS = ['edson.softcase@gmail.com'];

interface AuthContextType {
  currentUser: User | null;
  currentOrganization: Organization | null;
  permissionMatrix: PermissionMatrix;
  usersList: User[];
  isSuperAdmin: boolean; // Nova propriedade
  login: (email: string, password: string) => Promise<{ error?: string }>;
  signUp: (email: string, password: string, fullName: string, companyName: string) => Promise<{ error?: string, success?: boolean }>;
  logout: () => void;
  switchOrganization: (orgId: string) => void;
  hasPermission: (module: string, action?: PermissionAction) => boolean;
  updatePermission: (role: Role, module: string, action: PermissionAction, value: boolean) => void;
  updateUser: (data: Partial<User>) => void;
  adminUpdateUser: (user: User) => void;
  adminDeleteUser: (userId: string) => void;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Default Matrix Builder - Configuração Inicial de Regras de Negócio
const createDefaultMatrix = (): PermissionMatrix => {
  const matrix: PermissionMatrix = {};
  
  const roles: Role[] = ['admin', 'executive', 'sales', 'support', 'dev', 'finance'];
  const modules = ['dashboard', 'commercial', 'clients', 'finance', 'support', 'dev', 'reports', 'settings', 'customer-success', 'proposals', 'retention', 'calendar'];
  
  const noAccess = { view: false, create: false, edit: false, delete: false };
  const fullAccess = { view: true, create: true, edit: true, delete: true };
  const viewOnly = { view: true, create: false, edit: false, delete: false };

  roles.forEach(role => {
    matrix[role] = {};
    modules.forEach(mod => {
      matrix[role][mod] = { ...noAccess };
    });
  });

  // --- REGRAS DE ACESSO POR CARGO ---
  ['admin', 'executive'].forEach(role => {
      modules.forEach(mod => matrix[role][mod] = { ...fullAccess });
  });

  matrix['sales']['dashboard'] = { ...fullAccess };
  matrix['sales']['commercial'] = { ...fullAccess };
  matrix['sales']['clients'] = { ...fullAccess };
  matrix['sales']['reports'] = { ...fullAccess };
  matrix['sales']['finance'] = { view: true, create: true, edit: false, delete: false };
  matrix['sales']['proposals'] = { ...fullAccess };
  matrix['sales']['retention'] = { ...fullAccess };
  matrix['sales']['calendar'] = { ...fullAccess };

  matrix['support']['dashboard'] = { ...viewOnly };
  matrix['support']['support'] = { ...fullAccess };
  matrix['support']['clients'] = { ...viewOnly };
  matrix['support']['retention'] = { ...viewOnly };
  matrix['support']['calendar'] = { ...viewOnly };
  
  matrix['finance']['dashboard'] = { ...viewOnly };
  matrix['finance']['finance'] = { ...fullAccess };
  matrix['finance']['reports'] = { ...fullAccess };
  matrix['finance']['commercial'] = { ...viewOnly };

  matrix['dev']['dashboard'] = { ...viewOnly };
  matrix['dev']['dev'] = { ...fullAccess };
  matrix['dev']['support'] = { view: true, create: false, edit: true, delete: false };

  return matrix;
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentOrganization, setCurrentOrganization] = useState<Organization | null>(null);
  const [loading, setLoading] = useState(true);
  
  // Super Admin Check
  const isSuperAdmin = currentUser?.email ? SUPER_ADMIN_EMAILS.includes(currentUser.email) : false;

  const [permissionMatrix, setPermissionMatrix] = useState<PermissionMatrix>(() => {
      const saved = localStorage.getItem('nexus_permissions');
      return saved ? JSON.parse(saved) : createDefaultMatrix();
  });
  
  const [usersList, setUsersList] = useState<User[]>(MOCK_USERS);

  // Inicialização: Verifica sessão existente no Supabase
  useEffect(() => {
    const initSession = async () => {
      const supabase = getSupabase();
      if (!supabase) {
        setLoading(false);
        return;
      }

      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.user) {
          await fetchProfileAndOrg(session.user.id);
        } else {
          setLoading(false);
        }

        const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
          if (session?.user) {
            // Em caso de login (SIGNED_IN), busca dados. 
            // Em caso de logout (SIGNED_OUT), já limpamos no método logout, mas isso é uma garantia extra.
            if (_event === 'SIGNED_IN') await fetchProfileAndOrg(session.user.id);
          } else if (_event === 'SIGNED_OUT') {
            setCurrentUser(null);
            setCurrentOrganization(null);
            setLoading(false);
          }
        });

        return () => subscription.unsubscribe();
      } catch (err) {
        console.error("Erro na inicialização da sessão:", err);
        setLoading(false);
      }
    };

    initSession();
  }, []);

  const fetchProfileAndOrg = async (userId: string) => {
    const supabase = getSupabase();
    if (!supabase) return;

    try {
      // 1. Busca o perfil do usuário
      // Pequeno delay para garantir que o trigger de criação do perfil rodou (em caso de sign up)
      await new Promise(r => setTimeout(r, 1000));

      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (profileError || !profile) {
        // Se não achar perfil, tenta novamente (race condition do trigger)
        console.warn("Perfil não encontrado imediatamente, tentando novamente...", profileError);
        return; 
      }

      // 2. Busca a organização
      let orgData = null;
      if (profile.organization_id) {
        const { data: org, error: orgError } = await supabase
          .from('organizations')
          .select('*')
          .eq('id', profile.organization_id)
          .single();
        
        if (org) orgData = org;
      }

      // 3. Monta o objeto User
      const mappedUser: User = {
        id: profile.id,
        name: profile.full_name || 'Usuário',
        email: profile.email,
        role: (profile.role as Role) || 'admin',
        avatar: (profile.full_name || 'U').charAt(0).toUpperCase(),
        organizationId: profile.organization_id
      };

      setCurrentUser(mappedUser);
      setCurrentOrganization(orgData);
      
    } catch (error) {
      console.error("Erro fatal no fetchProfile:", error);
    } finally {
      setLoading(false);
    }
  };

  const login = async (email: string, password: string): Promise<{ error?: string }> => {
    const supabase = getSupabase();
    if (!supabase) return { error: "Erro de configuração do Supabase." };

    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) return { error: error.message };
      return {};
    } catch (err: any) {
      return { error: err.message };
    }
  };

  const signUp = async (email: string, password: string, fullName: string, companyName: string): Promise<{ error?: string, success?: boolean }> => {
    const supabase = getSupabase();
    if (!supabase) return { error: "Erro de configuração do Supabase." };

    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: fullName,
            company_name: companyName
          }
        }
      });

      if (error) return { error: error.message };
      
      // Se o email confirmation estiver ligado no Supabase, data.session será null
      if (data.user && !data.session) {
          return { success: true, error: "Verifique seu e-mail para confirmar o cadastro antes de entrar." };
      }

      return { success: true };
    } catch (err: any) {
      return { error: err.message };
    }
  };

  const logout = async () => {
    setLoading(true);

    try {
        const supabase = getSupabase();
        
        // 1. Limpeza Otimista do Estado (UI first)
        setCurrentUser(null);
        setCurrentOrganization(null);

        // 2. Limpar dados locais, preservando configurações de conexão
        const keysToKeep = ['nexus_supabase_url', 'nexus_supabase_key', 'nexus_db_version'];
        const keysToRemove: string[] = [];
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && (key.startsWith('nexus_') || key.startsWith('sb-'))) {
                if (!keysToKeep.includes(key)) {
                    keysToRemove.push(key);
                }
            }
        }
        keysToRemove.forEach(k => localStorage.removeItem(k));

        // 3. Tentar logout no backend (sem bloquear a UI se falhar ou demorar)
        if (supabase) {
            supabase.auth.signOut().catch(err => console.warn("Logout background warning:", err));
        }
        
    } catch (error) {
        console.error("Erro no logout:", error);
    } finally {
        setLoading(false);
    }
  };

  const switchOrganization = (orgId: string) => {
      console.log("Troca de organização solicitada:", orgId);
  };

  const hasPermission = (module: string, action: PermissionAction = 'view'): boolean => {
    if (!currentUser) return false;
    const role = currentUser.role;
    
    if (!permissionMatrix[role] || !permissionMatrix[role][module]) {
        if (role === 'admin') return true;
        return false;
    }
    return permissionMatrix[role][module][action];
  };

  const updatePermission = (role: Role, module: string, action: PermissionAction, value: boolean) => {
      setPermissionMatrix(prev => {
          const newMatrix = {
              ...prev,
              [role]: {
                  ...prev[role],
                  [module]: {
                      ...prev[role][module] || {view: false, create: false, edit: false, delete: false},
                      [action]: value
                  }
              }
          };
          localStorage.setItem('nexus_permissions', JSON.stringify(newMatrix));
          return newMatrix;
      });
  };

  const updateUser = (data: Partial<User>) => {
      setCurrentUser(prev => prev ? { ...prev, ...data } : null);
  };

  const adminUpdateUser = (updatedUser: User) => {
      setUsersList(prev => prev.map(u => u.id === updatedUser.id ? updatedUser : u));
  };

  const adminDeleteUser = (userId: string) => {
      setUsersList(prev => prev.filter(u => u.id !== userId));
  };

  return (
    <AuthContext.Provider value={{ 
        currentUser, currentOrganization, permissionMatrix, usersList, loading, isSuperAdmin,
        login, signUp, logout, switchOrganization, hasPermission, updatePermission, updateUser, 
        adminUpdateUser, adminDeleteUser 
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
