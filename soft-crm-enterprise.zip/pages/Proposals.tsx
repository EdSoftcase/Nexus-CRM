
import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';
import { Proposal } from '../types';
import { FileText, Plus, Eye, Download, Send, ChevronLeft, Save, Trash2, Printer, MessageCircle, Mail, X, Share2, AlertCircle, Edit3, LayoutTemplate } from 'lucide-react';
import { Badge } from '../components/Widgets';

const DEFAULT_INTRO = "Agradecemos a oportunidade de apresentar nossa solução. Com base em nossas conversas, desenhamos um projeto focado em atender suas necessidades e otimizar seus processos.";
const DEFAULT_TERMS = "Validade da proposta: 15 dias. Pagamento: 50% no aceite e 50% na entrega. O cronograma inicia-se após a confirmação do pagamento inicial.";

export const Proposals: React.FC = () => {
    const { proposals, leads, addProposal } = useData();
    const { currentUser } = useAuth();
    
    const [view, setView] = useState<'list' | 'create'>('list');
    
    // Mobile View State (Editor vs Preview)
    const [mobileTab, setMobileTab] = useState<'editor' | 'preview'>('editor');
    
    // Preview Modal State
    const [showPreviewModal, setShowPreviewModal] = useState(false);

    // Form State
    const [formData, setFormData] = useState({
        leadId: '',
        title: '',
        clientName: '',
        companyName: '',
        price: 0,
        timeline: '30 dias',
        introduction: DEFAULT_INTRO,
        terms: DEFAULT_TERMS,
        scopeItem: '',
        scope: [] as string[]
    });

    // Validation State
    const [errors, setErrors] = useState<{ price?: string; scope?: string }>({});

    const handleSelectLead = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const leadId = e.target.value;
        const lead = leads.find(l => l.id === leadId);
        
        if (lead) {
            setFormData(prev => ({
                ...prev,
                leadId: lead.id,
                clientName: lead.name,
                companyName: lead.company,
                price: lead.value,
                title: `Proposta Comercial - ${lead.company}`
            }));
            // Validar preço automaticamente ao carregar do lead
            if (lead.value > 0) {
                setErrors(prev => ({ ...prev, price: undefined }));
            }
        } else {
            setFormData(prev => ({ ...prev, leadId: '' }));
        }
    };

    const handlePriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const val = Number(e.target.value);
        setFormData(prev => ({ ...prev, price: val }));

        if (val <= 0) {
            setErrors(prev => ({ ...prev, price: 'O valor deve ser maior que zero.' }));
        } else {
            setErrors(prev => ({ ...prev, price: undefined }));
        }
    };

    const addScopeItem = () => {
        if (formData.scopeItem.trim()) {
            setFormData(prev => ({
                ...prev,
                scope: [...prev.scope, prev.scopeItem],
                scopeItem: ''
            }));
            // Limpar erro de escopo se existir
            setErrors(prev => ({ ...prev, scope: undefined }));
        }
    };

    const removeScopeItem = (index: number) => {
        setFormData(prev => ({
            ...prev,
            scope: prev.scope.filter((_, i) => i !== index)
        }));
    };

    const handleSave = () => {
        // Validação Final antes de Salvar
        const newErrors: { price?: string; scope?: string } = {};
        let isValid = true;

        if (formData.price <= 0) {
            newErrors.price = 'O valor do investimento é obrigatório.';
            isValid = false;
        }

        if (formData.scope.length === 0) {
            newErrors.scope = 'Adicione pelo menos um item ao escopo do projeto.';
            isValid = false;
        }

        setErrors(newErrors);

        if (!isValid) {
            alert("Por favor, corrija os erros no formulário antes de salvar.");
            return;
        }

        const newProposal: Proposal = {
            id: `PROP-${Date.now()}`,
            title: formData.title || 'Nova Proposta',
            leadId: formData.leadId,
            clientName: formData.clientName,
            companyName: formData.companyName,
            price: formData.price,
            createdDate: new Date().toISOString(),
            validUntil: new Date(new Date().setDate(new Date().getDate() + 15)).toISOString(),
            status: 'Sent',
            introduction: formData.introduction,
            scope: formData.scope,
            timeline: formData.timeline,
            terms: formData.terms
        };

        addProposal(currentUser, newProposal);
        setView('list');
        // Reset form
        setFormData({
            leadId: '', title: '', clientName: '', companyName: '', price: 0, timeline: '30 dias',
            introduction: DEFAULT_INTRO, terms: DEFAULT_TERMS, scopeItem: '', scope: []
        });
        setErrors({});
    };

    const handlePrint = () => {
        window.print();
    };

    const handleShareWhatsApp = () => {
        const text = encodeURIComponent(`Olá ${formData.clientName}, segue o link da proposta comercial "${formData.title}" para análise. Qualquer dúvida, estou à disposição!`);
        window.open(`https://wa.me/?text=${text}`, '_blank');
    };

    const handleShareEmail = () => {
        const subject = encodeURIComponent(`Proposta Comercial: ${formData.title}`);
        const body = encodeURIComponent(`Olá ${formData.clientName},\n\nConforme conversamos, segue a proposta comercial anexa para o projeto na ${formData.companyName}.\n\nFico no aguardo do seu retorno.\n\nAtenciosamente,\nEquipe Soft Case`);
        window.open(`mailto:?subject=${subject}&body=${body}`, '_blank');
    };

    // Componente reutilizável para renderizar o documento (Paper)
    const ProposalDocument = () => (
        <div className="bg-white w-[21cm] min-h-[29.7cm] p-[2cm] shadow-2xl text-slate-800 flex flex-col relative printable-area mx-auto">
            {/* Paper Header - SOFT CASE BRANDING */}
            <div className="flex justify-between items-center mb-12 border-b-2 border-slate-100 pb-6">
                {/* LOGO RECREATION */}
                <div className="flex items-center gap-3">
                    {/* Graphic Icon */}
                    <div className="w-12 h-12 rounded-tl-2xl rounded-br-2xl bg-gradient-to-br from-[#0ea5e9] to-[#0f172a] relative overflow-hidden flex items-center justify-center shadow-sm shrink-0">
                        <div className="absolute inset-0 opacity-30">
                            <div className="absolute w-[150%] h-[150%] border-2 border-white rounded-[40%] -top-[40%] -left-[40%]"></div>
                            <div className="absolute w-[150%] h-[150%] border-2 border-white rounded-[40%] -top-[30%] -left-[30%]"></div>
                            <div className="absolute w-[150%] h-[150%] border-2 border-white rounded-[40%] -top-[20%] -left-[20%]"></div>
                        </div>
                    </div>
                    {/* Text Logo */}
                    <div className="flex flex-col justify-center leading-none">
                        <span className="text-3xl font-black text-[#0f172a] tracking-tighter">SOFT</span>
                        <span className="text-3xl font-bold text-[#0ea5e9] tracking-widest" style={{ letterSpacing: '0.15em' }}>CASE</span>
                    </div>
                </div>

                {/* Company Info */}
                <div className="text-right">
                    <h1 className="text-xl font-bold text-slate-900 tracking-tight uppercase mb-1">Proposta Comercial</h1>
                    <div className="text-xs text-slate-500 space-y-0.5">
                        <p className="font-bold text-slate-700">Soft Case Tecnologia</p>
                        <p>contato@softcase.com.br</p>
                        <p>(11) 99999-0000</p>
                    </div>
                </div>
            </div>

            {/* Proposal Info */}
            <div className="mb-10">
                <h2 className="text-xl font-bold text-slate-900 mb-2">{formData.title || 'Título da Proposta'}</h2>
                <div className="flex justify-between text-sm mt-4">
                    <div>
                        <p className="text-slate-400 uppercase text-xs font-bold">Preparado para:</p>
                        <p className="font-medium text-lg">{formData.clientName || 'Nome do Cliente'}</p>
                        <p className="text-slate-600">{formData.companyName || 'Empresa'}</p>
                    </div>
                    <div className="text-right">
                        <p className="text-slate-400 uppercase text-xs font-bold">Data:</p>
                        <p className="font-medium">{new Date().toLocaleDateString()}</p>
                        <p className="text-slate-400 uppercase text-xs font-bold mt-2">Validade:</p>
                        <p className="font-medium">15 dias</p>
                    </div>
                </div>
            </div>

            {/* Body */}
            <div className="space-y-8 flex-1">
                <section>
                    <h3 className="text-sm font-bold text-[#0ea5e9] uppercase tracking-wider mb-2 border-b border-blue-100 pb-1">Introdução</h3>
                    <p className="text-sm leading-relaxed text-slate-600 whitespace-pre-wrap">
                        {formData.introduction || 'Texto de introdução...'}
                    </p>
                </section>

                <section>
                    <h3 className="text-sm font-bold text-[#0ea5e9] uppercase tracking-wider mb-2 border-b border-blue-100 pb-1">Escopo do Projeto</h3>
                    {formData.scope.length > 0 ? (
                        <ul className="list-disc pl-5 space-y-2 text-sm text-slate-700">
                            {formData.scope.map((item, i) => (
                                <li key={i}>{item}</li>
                            ))}
                        </ul>
                    ) : (
                        <p className="text-sm text-slate-400 italic">Itens do escopo aparecerão aqui.</p>
                    )}
                </section>

                <section className="bg-slate-50 p-6 rounded-lg border border-slate-100">
                    <h3 className="text-sm font-bold text-[#0ea5e9] uppercase tracking-wider mb-4 border-b border-blue-100 pb-1">Investimento & Prazo</h3>
                    <div className="flex justify-between items-center mb-4">
                        <span className="text-slate-600 font-medium">Investimento Total</span>
                        <span className="text-2xl font-bold text-slate-900">R$ {formData.price.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between items-center">
                        <span className="text-slate-600 font-medium">Prazo Estimado</span>
                        <span className="font-bold text-slate-700">{formData.timeline}</span>
                    </div>
                </section>

                <section>
                    <h3 className="text-sm font-bold text-[#0ea5e9] uppercase tracking-wider mb-2 border-b border-blue-100 pb-1">Termos</h3>
                    <p className="text-xs text-slate-500 whitespace-pre-wrap">
                        {formData.terms}
                    </p>
                </section>
            </div>

            {/* Footer */}
            <div className="mt-12 pt-8 border-t border-slate-200 flex justify-between items-end">
                <div className="text-center w-1/3">
                    <div className="border-b border-slate-300 mb-2 h-8"></div>
                    <p className="text-xs font-bold uppercase">Soft Case</p>
                </div>
                <div className="text-center w-1/3">
                    <div className="border-b border-slate-300 mb-2 h-8"></div>
                    <p className="text-xs font-bold uppercase">De Acordo (Cliente)</p>
                </div>
            </div>
        </div>
    );

    if (view === 'list') {
        return (
            <div className="p-8 h-screen flex flex-col">
                <div className="flex justify-between items-center mb-6">
                    <div>
                        <h1 className="text-3xl font-bold text-slate-900">Gerador de Propostas</h1>
                        <p className="text-slate-500">Crie, edite e envie propostas comerciais profissionais.</p>
                    </div>
                    <button 
                        onClick={() => setView('create')}
                        className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition shadow-sm font-medium flex items-center gap-2"
                    >
                        <Plus size={20} /> Nova Proposta
                    </button>
                </div>

                <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden flex-1">
                    <table className="w-full text-left text-sm">
                        <thead className="bg-slate-50 text-slate-500 uppercase text-xs font-medium border-b border-slate-200">
                            <tr>
                                <th className="p-4">Título / Cliente</th>
                                <th className="p-4">Data Criação</th>
                                <th className="p-4">Valor</th>
                                <th className="p-4">Validade</th>
                                <th className="p-4">Status</th>
                                <th className="p-4 text-center">Ações</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                            {proposals.map(prop => (
                                <tr key={prop.id} className="hover:bg-slate-50">
                                    <td className="p-4">
                                        <div className="font-bold text-slate-900">{prop.title}</div>
                                        <div className="text-xs text-slate-500">{prop.companyName} ({prop.clientName})</div>
                                    </td>
                                    <td className="p-4 text-slate-600">{new Date(prop.createdDate).toLocaleDateString()}</td>
                                    <td className="p-4 font-bold text-slate-700">R$ {prop.price.toLocaleString()}</td>
                                    <td className="p-4 text-slate-600">{new Date(prop.validUntil).toLocaleDateString()}</td>
                                    <td className="p-4">
                                        <Badge color={prop.status === 'Accepted' ? 'green' : prop.status === 'Sent' ? 'blue' : 'gray'}>
                                            {prop.status === 'Sent' ? 'Enviado' : prop.status === 'Accepted' ? 'Aceito' : prop.status}
                                        </Badge>
                                    </td>
                                    <td className="p-4 flex justify-center gap-2">
                                        <button className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded" title="Visualizar">
                                            <Eye size={18} />
                                        </button>
                                        <button className="p-2 text-slate-400 hover:text-green-600 hover:bg-green-50 rounded" title="Baixar PDF">
                                            <Download size={18} />
                                        </button>
                                    </td>
                                </tr>
                            ))}
                            {proposals.length === 0 && (
                                <tr>
                                    <td colSpan={6} className="p-8 text-center text-slate-400 italic">
                                        Nenhuma proposta criada. Clique em "Nova Proposta" para começar.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        );
    }

    return (
        <div className="h-screen flex flex-col bg-slate-100">
            {/* Toolbar */}
            <div className="bg-white border-b border-slate-200 p-3 md:p-4 flex flex-col md:flex-row justify-between items-start md:items-center shadow-sm shrink-0 no-print gap-3 md:gap-0">
                <div className="flex items-center gap-4 w-full md:w-auto">
                    <button onClick={() => setView('list')} className="text-slate-500 hover:text-slate-800 p-2 hover:bg-slate-100 rounded-full">
                        <ChevronLeft size={24}/>
                    </button>
                    <div className="flex-1 md:flex-none">
                        <h2 className="text-lg md:text-xl font-bold text-slate-800">Nova Proposta</h2>
                        <p className="text-xs text-slate-500 md:hidden">Preencha os dados abaixo</p>
                    </div>
                </div>
                
                <div className="flex gap-2 w-full md:w-auto overflow-x-auto pb-1 md:pb-0">
                    <button 
                        onClick={() => setShowPreviewModal(true)}
                        className="hidden md:flex items-center gap-2 px-4 py-2 text-slate-600 hover:bg-slate-50 rounded-lg border border-transparent hover:border-slate-200 transition whitespace-nowrap"
                    >
                        <Eye size={18}/> Preview
                    </button>
                    <button onClick={handlePrint} className="hidden md:flex items-center gap-2 px-4 py-2 text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-lg font-medium transition whitespace-nowrap" title="Imprimir ou Salvar PDF">
                        <Printer size={18}/> Imprimir
                    </button>
                    <button 
                        onClick={handleSave} 
                        className="flex-1 md:flex-none flex items-center justify-center gap-2 px-4 md:px-6 py-2 bg-blue-600 text-white hover:bg-blue-700 rounded-lg font-bold shadow-sm transition whitespace-nowrap"
                    >
                        <Save size={18}/> Salvar
                    </button>
                </div>
            </div>

            {/* Mobile Tab Switcher */}
            <div className="lg:hidden flex border-b border-slate-200 bg-white shadow-sm shrink-0">
                <button 
                    onClick={() => setMobileTab('editor')}
                    className={`flex-1 py-3 text-sm font-bold flex items-center justify-center gap-2 ${mobileTab === 'editor' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-500'}`}
                >
                    <Edit3 size={16}/> Editor
                </button>
                <button 
                    onClick={() => setMobileTab('preview')}
                    className={`flex-1 py-3 text-sm font-bold flex items-center justify-center gap-2 ${mobileTab === 'preview' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-slate-500'}`}
                >
                    <LayoutTemplate size={16}/> Visualizar
                </button>
            </div>

            <div className="flex flex-1 overflow-hidden relative">
                {/* Editor (Left) - Hidden on Mobile if Preview is active */}
                <div className={`
                    w-full lg:w-1/2 p-4 md:p-6 overflow-y-auto bg-slate-50 border-r border-slate-200 no-print transition-all
                    ${mobileTab === 'preview' ? 'hidden lg:block' : 'block'}
                `}>
                    <div className="max-w-xl mx-auto space-y-6 pb-20 lg:pb-0">
                        
                        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                            <h3 className="text-sm font-bold text-slate-900 uppercase mb-4 pb-2 border-b border-slate-100">Dados do Cliente</h3>
                            <div className="space-y-4">
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Carregar dados de Lead</label>
                                    <select onChange={handleSelectLead} value={formData.leadId} className="w-full border border-slate-300 rounded p-2 text-sm bg-white">
                                        <option value="">Selecione um lead para preencher...</option>
                                        {leads.map(l => <option key={l.id} value={l.id}>{l.name} - {l.company}</option>)}
                                    </select>
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Nome Cliente</label>
                                        <input type="text" className="w-full border border-slate-300 rounded p-2 text-sm" value={formData.clientName} onChange={e => setFormData({...formData, clientName: e.target.value})} />
                                    </div>
                                    <div>
                                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Empresa</label>
                                        <input type="text" className="w-full border border-slate-300 rounded p-2 text-sm" value={formData.companyName} onChange={e => setFormData({...formData, companyName: e.target.value})} />
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Título da Proposta</label>
                                    <input type="text" className="w-full border border-slate-300 rounded p-2 text-sm font-medium" value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} />
                                </div>
                            </div>
                        </div>

                        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                            <h3 className="text-sm font-bold text-slate-900 uppercase mb-4 pb-2 border-b border-slate-100">Escopo e Valores</h3>
                            <div className="space-y-4">
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Introdução</label>
                                    <textarea className="w-full border border-slate-300 rounded p-2 text-sm h-24 resize-none" value={formData.introduction} onChange={e => setFormData({...formData, introduction: e.target.value})} />
                                </div>
                                
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1 flex justify-between">
                                        Itens do Escopo
                                        {errors.scope && <span className="text-red-500 font-normal normal-case flex items-center gap-1"><AlertCircle size={12}/> {errors.scope}</span>}
                                    </label>
                                    <div className="flex gap-2 mb-2">
                                        <input 
                                            type="text" 
                                            className={`flex-1 border rounded p-2 text-sm ${errors.scope ? 'border-red-300 bg-red-50' : 'border-slate-300'}`}
                                            placeholder="Adicione um item entregável..."
                                            value={formData.scopeItem}
                                            onChange={e => setFormData({...formData, scopeItem: e.target.value})}
                                            onKeyDown={e => e.key === 'Enter' && addScopeItem()}
                                        />
                                        <button onClick={addScopeItem} className="bg-slate-100 hover:bg-slate-200 p-2 rounded border border-slate-300 text-slate-600"><Plus size={18}/></button>
                                    </div>
                                    <ul className="space-y-2">
                                        {formData.scope.map((item, idx) => (
                                            <li key={idx} className="flex justify-between items-center bg-slate-50 p-2 rounded border border-slate-100 text-sm">
                                                <span>• {item}</span>
                                                <button onClick={() => removeScopeItem(idx)} className="text-red-400 hover:text-red-600"><Trash2 size={14}/></button>
                                            </li>
                                        ))}
                                    </ul>
                                </div>

                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Investimento Total (R$)</label>
                                        <div className="relative">
                                            <input 
                                                type="number" 
                                                className={`w-full border rounded p-2 text-sm outline-none focus:ring-2 
                                                    ${errors.price ? 'border-red-500 focus:ring-red-200' : 'border-slate-300 focus:ring-blue-500'}`}
                                                value={formData.price} 
                                                onChange={handlePriceChange}
                                            />
                                            {errors.price && <AlertCircle size={16} className="absolute right-2 top-2 text-red-500" title={errors.price} />}
                                        </div>
                                        {errors.price && <p className="text-xs text-red-500 mt-1">{errors.price}</p>}
                                    </div>
                                    <div>
                                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Prazo de Execução</label>
                                        <input type="text" className="w-full border border-slate-300 rounded p-2 text-sm" value={formData.timeline} onChange={e => setFormData({...formData, timeline: e.target.value})} />
                                    </div>
                                </div>

                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Termos e Condições</label>
                                    <textarea className="w-full border border-slate-300 rounded p-2 text-sm h-20 resize-none" value={formData.terms} onChange={e => setFormData({...formData, terms: e.target.value})} />
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                {/* Live Preview (Right) - Hidden on Mobile if Editor is active */}
                <div className={`
                    w-full lg:w-1/2 bg-slate-200 p-4 md:p-8 overflow-y-auto justify-center no-print
                    ${mobileTab === 'editor' ? 'hidden lg:flex' : 'flex'}
                `}>
                    <div className="transform scale-[0.45] sm:scale-[0.6] md:scale-[0.8] lg:scale-[0.8] origin-top h-fit shadow-2xl">
                        <ProposalDocument />
                    </div>
                </div>
            </div>

            {/* --- PREVIEW MODAL WITH ACTIONS --- */}
            {showPreviewModal && (
                <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4 backdrop-blur-sm no-print animate-fade-in">
                    <div className="bg-slate-100 w-full h-full max-w-5xl rounded-xl shadow-2xl overflow-hidden flex flex-col">
                        <div className="bg-white p-4 border-b border-slate-200 flex justify-between items-center shrink-0">
                            <div>
                                <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                                    <Eye className="text-blue-600"/> Pré-visualização da Proposta
                                </h2>
                                <p className="text-xs text-slate-500">Confira o layout final antes de enviar.</p>
                            </div>
                            <div className="flex gap-2">
                                <button 
                                    onClick={handleShareWhatsApp}
                                    className="flex items-center gap-2 px-4 py-2 bg-[#25D366] text-white hover:bg-[#128C7E] rounded-lg font-medium transition shadow-sm"
                                >
                                    <MessageCircle size={18}/> <span className="hidden md:inline">WhatsApp</span>
                                </button>
                                <button 
                                    onClick={handleShareEmail}
                                    className="flex items-center gap-2 px-4 py-2 bg-slate-800 text-white hover:bg-slate-700 rounded-lg font-medium transition shadow-sm"
                                >
                                    <Mail size={18}/> <span className="hidden md:inline">Email</span>
                                </button>
                                <div className="w-px h-8 bg-slate-200 mx-2 hidden md:block"></div>
                                <button onClick={() => setShowPreviewModal(false)} className="p-2 hover:bg-slate-100 rounded-full text-slate-500">
                                    <X size={24}/>
                                </button>
                            </div>
                        </div>
                        
                        <div className="flex-1 overflow-y-auto p-4 md:p-8 flex justify-center bg-slate-200 custom-scrollbar">
                            <div className="shadow-2xl transform scale-[0.5] md:scale-100 origin-top md:origin-center">
                                <ProposalDocument />
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};
