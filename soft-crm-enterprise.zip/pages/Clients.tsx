
import React, { useState, useRef, useEffect } from 'react';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';
import { Client360 } from '../components/Client360';
import { Client } from '../types';
import { Search, MoreHorizontal, X, Save, User, Building, Mail, Phone, MapPin, Globe, Briefcase, Filter, Upload, Download, FileSpreadsheet, Trash2, Clock, AlertCircle, ArrowRight, AlertTriangle, MessageCircle, Send, CheckCircle, FileText } from 'lucide-react';
// CORREÇÃO: Importação 'namespace' para compatibilidade com CDN ESM
import * as XLSX from 'xlsx';

export const Clients: React.FC = () => {
    const { clients, leads, tickets, invoices, addClient, addClientsBulk, removeClient } = useData();
    const { currentUser, hasPermission } = useAuth();
    const [selectedClient, setSelectedClient] = useState<Client | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    
    // WhatsApp Modal State
    const [showWhatsAppModal, setShowWhatsAppModal] = useState(false);
    const [whatsAppMessage, setWhatsAppMessage] = useState('');
    const [clientForWhatsApp, setClientForWhatsApp] = useState<Client | null>(null);

    const whatsappTemplates = [
        { label: 'Boas Vindas', text: 'Olá [Nome], seja bem-vindo à Soft Case! Estou aqui para ajudar com qualquer dúvida sobre seu contrato.' },
        { label: 'Cobrança Suave', text: 'Oi [Nome], tudo bem? Notei que temos uma fatura em aberto. Precisa de ajuda com o boleto?' },
        { label: 'Agendar Reunião', text: 'Olá [Nome], gostaria de agendar uma visita técnica/reunião para alinharmos os próximos passos. Qual sua disponibilidade?' },
        { label: 'Pesquisa NPS', text: 'Oi [Nome], você poderia avaliar nosso atendimento rapidamente? Sua opinião é muito importante para nós!' }
    ];

    // Global Search
    const [searchTerm, setSearchTerm] = useState('');

    // --- COLUMN FILTERS STATE ---
    const [filters, setFilters] = useState({
        name: '',
        unit: '',
        spots: '',
        status: 'All',
        lastContact: '',
        value: ''
    });

    // New Client Modal State
    const [isNewClientModalOpen, setIsNewClientModalOpen] = useState(false);
    const [newClientForm, setNewClientForm] = useState({
        name: '',
        contactPerson: '',
        email: '',
        phone: '',
        segment: '',
        address: '',
        website: '',
        ltv: '',
        cnpj: '' // Added CNPJ field
    });
    
    // Validation State
    const [emailError, setEmailError] = useState<string | null>(null);
    const [phoneError, setPhoneError] = useState<string | null>(null);
    const [cnpjError, setCnpjError] = useState<string | null>(null);

    // Delete Client Modal State
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [clientToDelete, setClientToDelete] = useState<Client | null>(null);
    const [deleteReason, setDeleteReason] = useState('');

    // --- 30 DAYS INACTIVE CLIENTS ALERT ---
    const [inactiveClients, setInactiveClients] = useState<Client[]>([]);
    const [showInactiveModal, setShowInactiveModal] = useState(false);

    useEffect(() => {
        const isSessionChecked = sessionStorage.getItem('nexus_inactive_alert_shown');
        if (isSessionChecked) return;

        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

        const stagnant = clients.filter(c => {
            const lastContactDate = c.lastContact ? new Date(c.lastContact) : new Date(c.since);
            return lastContactDate < thirtyDaysAgo && c.status === 'Active';
        });

        if (stagnant.length > 0) {
            setInactiveClients(stagnant);
            setShowInactiveModal(true);
            sessionStorage.setItem('nexus_inactive_alert_shown', 'true');
        }
    }, [clients]);

    // --- FILTERING LOGIC ---
    const filteredClients = clients.filter(c => {
        // 1. Global Search (Generic)
        const matchesGlobal = 
            searchTerm === '' ||
            c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
            c.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
            (c.contractId && c.contractId.toLowerCase().includes(searchTerm.toLowerCase()));

        // 2. Column Specific Filters
        const matchesName = filters.name === '' || 
                            c.name.toLowerCase().includes(filters.name.toLowerCase()) ||
                            (c.contractId && c.contractId.toLowerCase().includes(filters.name.toLowerCase()));
        
        const matchesUnit = filters.unit === '' || 
                            (c.unit || c.address || '').toLowerCase().includes(filters.unit.toLowerCase());
        
        const matchesSpots = filters.spots === '' || 
                             (c.parkingSpots !== undefined && c.parkingSpots.toString().includes(filters.spots));
        
        const matchesStatus = filters.status === 'All' || c.status === filters.status;

        // Simplistic value matching (convert to string)
        const totalVal = c.totalTablePrice || c.ltv || 0;
        const matchesValue = filters.value === '' || totalVal.toString().includes(filters.value);

        return matchesGlobal && matchesName && matchesUnit && matchesSpots && matchesStatus && matchesValue;
    });

    // Helper: Validate Email
    const validateEmail = (email: string) => {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    };

    const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const val = e.target.value;
        setNewClientForm({ ...newClientForm, email: val });
        
        if (val.length === 0) {
            setEmailError(null);
        } else if (!validateEmail(val)) {
            setEmailError('Formato de e-mail inválido');
        } else {
            setEmailError(''); // Empty string means valid
        }
    };

    // Helper: Mask Phone
    const maskPhone = (value: string) => {
        return value
            .replace(/\D/g, '') // Remove non-digits
            .replace(/^(\d{2})(\d)/g, '($1) $2') // (DD) ...
            .replace(/(\d)(\d{4})$/, '$1-$2') // ...-NNNN
            .substring(0, 15); // Max length
    };

    const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const maskedVal = maskPhone(e.target.value);
        setNewClientForm({ ...newClientForm, phone: maskedVal });

        if (maskedVal.length === 0) {
            setPhoneError(null);
        } else if (maskedVal.length < 14) { // (11) 1234-5678 is 14 chars minimum
            setPhoneError('Telefone inválido');
        } else {
            setPhoneError(''); // Empty string means valid
        }
    };

    // Helper: CNPJ Validation
    const validateCNPJ = (cnpj: string) => {
        cnpj = cnpj.replace(/[^\d]+/g, '');
        if (cnpj === '') return false;
        if (cnpj.length !== 14) return false;

        // Elimina CNPJs invalidos conhecidos
        if (/^(\d)\1+$/.test(cnpj)) return false;

        // Valida DVs
        let tamanho = cnpj.length - 2
        let numeros = cnpj.substring(0, tamanho);
        let digitos = cnpj.substring(tamanho);
        let soma = 0;
        let pos = tamanho - 7;
        
        for (let i = tamanho; i >= 1; i--) {
            soma += parseInt(numeros.charAt(tamanho - i)) * pos--;
            if (pos < 2) pos = 9;
        }
        
        let resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
        if (resultado !== parseInt(digitos.charAt(0))) return false;

        tamanho = tamanho + 1;
        numeros = cnpj.substring(0, tamanho);
        soma = 0;
        pos = tamanho - 7;
        
        for (let i = tamanho; i >= 1; i--) {
            soma += parseInt(numeros.charAt(tamanho - i)) * pos--;
            if (pos < 2) pos = 9;
        }
        resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
        if (resultado !== parseInt(digitos.charAt(1))) return false;

        return true;
    };

    const maskCNPJ = (value: string) => {
        return value
            .replace(/\D/g, '')
            .replace(/^(\d{2})(\d)/, '$1.$2')
            .replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3')
            .replace(/\.(\d{3})(\d)/, '.$1/$2')
            .replace(/(\d{4})(\d)/, '$1-$2')
            .substring(0, 18);
    };

    const handleCnpjChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const maskedVal = maskCNPJ(e.target.value);
        setNewClientForm({ ...newClientForm, cnpj: maskedVal });

        if (maskedVal.length === 0) {
            setCnpjError(null);
        } else if (maskedVal.length < 18 || !validateCNPJ(maskedVal)) {
            setCnpjError('CNPJ inválido');
        } else {
            setCnpjError('');
        }
    };

    const handleCreateClient = (e: React.FormEvent) => {
        e.preventDefault();
        
        if (emailError || (newClientForm.email && !validateEmail(newClientForm.email))) {
            setEmailError('Por favor, corrija o e-mail antes de salvar.');
            return;
        }

        if (phoneError || (newClientForm.phone && newClientForm.phone.length < 14)) {
            setPhoneError('Por favor, insira um telefone válido.');
            return;
        }

        if (cnpjError || (newClientForm.cnpj && !validateCNPJ(newClientForm.cnpj))) {
            setCnpjError('Por favor, insira um CNPJ válido.');
            return;
        }

        const newClient: Client = {
            id: `C-${Date.now()}`,
            name: newClientForm.name,
            contactPerson: newClientForm.contactPerson,
            document: newClientForm.cnpj,
            email: newClientForm.email,
            phone: newClientForm.phone,
            segment: newClientForm.segment || 'Geral',
            since: new Date().toISOString(),
            status: 'Active',
            ltv: Number(newClientForm.ltv) || 0,
            nps: 0,
            healthScore: 100,
            onboardingStatus: 'Pending',
            address: newClientForm.address,
            website: newClientForm.website,
            lastContact: new Date().toISOString()
        };

        addClient(currentUser, newClient);
        setIsNewClientModalOpen(false);
        setNewClientForm({
            name: '', contactPerson: '', email: '', phone: '', segment: '', address: '', website: '', ltv: '', cnpj: ''
        });
        setEmailError(null);
        setPhoneError(null);
        setCnpjError(null);
    };

    const handleDeleteClick = (e: React.MouseEvent, client: Client) => {
        e.stopPropagation();
        setClientToDelete(client);
        setDeleteReason('');
        setIsDeleteModalOpen(true);
    };

    const handleWhatsAppClick = (e: React.MouseEvent, client: Client) => {
        e.stopPropagation();
        setClientForWhatsApp(client);
        
        // Default Template
        const defaultTmpl = whatsappTemplates[0];
        const text = defaultTmpl.text
            .replace('[Nome]', client.contactPerson.split(' ')[0])
            .replace('[Empresa]', client.name);
        
        setWhatsAppMessage(text);
        setShowWhatsAppModal(true);
    };

    const handleSendWhatsApp = () => {
        if (!clientForWhatsApp) return;
        const phone = clientForWhatsApp.phone?.replace(/\D/g, '') || '';
        const text = encodeURIComponent(whatsAppMessage);
        window.open(`https://wa.me/${phone}?text=${text}`, '_blank');
        setShowWhatsAppModal(false);
    };

    const handleConfirmDelete = () => {
        if (clientToDelete && deleteReason.length >= 5) {
            removeClient(currentUser, clientToDelete.id, deleteReason);
            setIsDeleteModalOpen(false);
            setClientToDelete(null);
            setDeleteReason('');
        }
    };

    const handleViewClientFromAlert = (client: Client) => {
        setShowInactiveModal(false);
        setSelectedClient(client);
    };

    const handleDownloadTemplate = () => {
        const headers = ["Contrato", "Cód. Int.", "Início", "Fim", "Tipo", "Cliente", "Unidade", "Status", "Vagas", "Isentas", "Qtd. Veículos", "Qtd. Credenciais", "Tabela", "R$ Tabela", "R$ Tabela Total", "Dia Espec.", "R$ Especial", "R$ Especial Total", "Email", "Telefone"];
        const exampleData = [["10023", "C001", "01/01/2024", "31/12/2024", "Mensalista", "Empresa Exemplo LTDA", "Edifício Central", "Ativo", 10, 2, 15, 20, "Tabela 2024", 250.00, 2500.00, "", 0, 0, "financeiro@exemplo.com", "(11) 99999-9999"]];
        const ws = XLSX.utils.aoa_to_sheet([headers, ...exampleData]);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Modelo Clientes");
        XLSX.writeFile(wb, "modelo_importacao_clientes.xlsx");
    };

    const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (e) => {
            const data = e.target?.result;
            if (!data) return;
            try {
                const workbook = XLSX.read(data, { type: 'binary' });
                const sheetName = workbook.SheetNames[0];
                const sheet = workbook.Sheets[sheetName];
                const json = XLSX.utils.sheet_to_json(sheet);
                const newClients: Client[] = [];
                json.forEach((row: any, index) => {
                    const clientName = row["Cliente"] || `Cliente ${index + 1}`;
                    let status: 'Active' | 'Churn Risk' | 'Inactive' = 'Active';
                    if (row["Status"]) {
                        const s = row["Status"].toString().toLowerCase();
                        if (s.includes('cancelado') || s.includes('inativo')) status = 'Inactive';
                        else if (s.includes('risco')) status = 'Churn Risk';
                    }
                    const client: Client = {
                        id: `C-IMP-${Date.now()}-${index}`,
                        name: clientName,
                        contactPerson: "A/C Financeiro",
                        email: row["Email"] || "",
                        phone: row["Telefone"] || "",
                        segment: row["Tipo"] || "Geral",
                        address: row["Unidade"] || "",
                        since: new Date().toISOString(),
                        status: status,
                        lastContact: new Date().toISOString(),
                        ltv: Number(row["R$ Tabela Total"]) || 0,
                        nps: 0,
                        healthScore: 100,
                        onboardingStatus: 'Pending',
                        contractId: row["Contrato"]?.toString(),
                        contractStartDate: row["Início"], 
                        contractEndDate: row["Fim"],
                        unit: row["Unidade"],
                        parkingSpots: Number(row["Vagas"]) || 0,
                        exemptSpots: Number(row["Isentas"]) || 0,
                        vehicleCount: Number(row["Qtd. Veículos"]) || 0,
                        credentialCount: Number(row["Qtd. Credenciais"]) || 0,
                        pricingTable: row["Tabela"],
                        tablePrice: Number(row["R$ Tabela"]) || 0,
                        totalTablePrice: Number(row["R$ Tabela Total"]) || 0,
                        specialDay: row["Dia Espec."],
                        specialPrice: Number(row["R$ Especial"]) || 0,
                        totalSpecialPrice: Number(row["R$ Especial Total"]) || 0
                    };
                    newClients.push(client);
                });
                if (newClients.length > 0) {
                    addClientsBulk(currentUser, newClients);
                    alert(`${newClients.length} clientes importados com sucesso via Excel!`);
                } else {
                    alert("Nenhum dado válido encontrado.");
                }
            } catch (error) {
                console.error("Erro ao importar Excel", error);
                alert("Erro ao processar arquivo Excel.");
            }
            if (fileInputRef.current) fileInputRef.current.value = '';
        };
        reader.readAsBinaryString(file);
    };

    return (
        <div className="p-8 h-screen flex flex-col">
            <div className="flex justify-between items-center mb-6">
                <div>
                    <h1 className="text-3xl font-bold text-slate-900">Carteira de Clientes</h1>
                    <p className="text-slate-500">Gestão 360° e relacionamento.</p>
                </div>
                <div className="flex gap-2">
                    <input type="file" accept=".xlsx, .xls" ref={fileInputRef} onChange={handleFileUpload} className="hidden" />
                    <div className="flex bg-white rounded-lg border border-slate-200 p-1 shadow-sm">
                        <button onClick={handleDownloadTemplate} className="p-2 hover:bg-slate-100 rounded text-slate-500 hover:text-blue-600 transition" title="Baixar Modelo Excel"><FileSpreadsheet size={20} /></button>
                        <div className="w-px h-auto bg-slate-200 mx-1"></div>
                        <button onClick={() => fileInputRef.current?.click()} className="flex items-center gap-2 px-3 py-1.5 text-sm font-medium text-slate-600 hover:bg-slate-50 hover:text-slate-900 rounded transition"><Upload size={18} /> Importar Excel</button>
                    </div>
                    <button onClick={() => { setIsNewClientModalOpen(true); setEmailError(null); setPhoneError(null); setCnpjError(null); }} className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 font-medium flex items-center gap-2 shadow-sm transition ml-2"><User size={20} /> + Novo Cliente</button>
                </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-slate-200 flex flex-col flex-1 overflow-hidden">
                {/* Global Search Bar */}
                <div className="p-4 border-b border-slate-200 flex items-center gap-4">
                    <div className="relative flex-1">
                        <Search className="absolute left-3 top-2.5 text-slate-400" size={20}/>
                        <input 
                            type="text" 
                            placeholder="Pesquisa Global (Nome, Email, Contrato)..." 
                            className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50 focus:bg-white transition"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>
                    <div className="text-xs text-slate-400 font-medium">
                        Exibindo {filteredClients.length} de {clients.length}
                    </div>
                </div>

                {/* Table with Header Filters */}
                <div className="overflow-auto flex-1 custom-scrollbar">
                    <table className="w-full text-left text-sm">
                        <thead className="bg-slate-50 text-slate-500 font-medium sticky top-0 z-10 shadow-sm">
                            {/* Labels Row */}
                            <tr>
                                <th className="p-3 pb-1 text-xs uppercase tracking-wider font-bold">Contrato / Cliente</th>
                                <th className="p-3 pb-1 text-xs uppercase tracking-wider font-bold">Unidade</th>
                                <th className="p-3 pb-1 text-center text-xs uppercase tracking-wider font-bold">Vagas</th>
                                <th className="p-3 pb-1 text-center text-xs uppercase tracking-wider font-bold">Status</th>
                                <th className="p-3 pb-1 text-center text-xs uppercase tracking-wider font-bold">Último Contato</th>
                                <th className="p-3 pb-1 text-right text-xs uppercase tracking-wider font-bold">Valor Total</th>
                                <th className="p-3 pb-1 text-center text-xs uppercase tracking-wider font-bold">Ações</th>
                            </tr>
                            {/* Filters Row */}
                            <tr className="bg-slate-50 border-b border-slate-200">
                                <th className="p-2">
                                    <input 
                                        type="text" 
                                        placeholder="Filtrar Nome/Contrato..." 
                                        className="w-full border border-slate-300 rounded px-2 py-1 text-xs focus:ring-1 focus:ring-blue-500 outline-none font-normal"
                                        value={filters.name}
                                        onChange={e => setFilters({...filters, name: e.target.value})}
                                    />
                                </th>
                                <th className="p-2">
                                    <input 
                                        type="text" 
                                        placeholder="Filtrar Unidade..." 
                                        className="w-full border border-slate-300 rounded px-2 py-1 text-xs focus:ring-1 focus:ring-blue-500 outline-none font-normal"
                                        value={filters.unit}
                                        onChange={e => setFilters({...filters, unit: e.target.value})}
                                    />
                                </th>
                                <th className="p-2">
                                    <input 
                                        type="text" 
                                        placeholder="Qtd..." 
                                        className="w-16 mx-auto block border border-slate-300 rounded px-2 py-1 text-xs focus:ring-1 focus:ring-blue-500 outline-none font-normal text-center"
                                        value={filters.spots}
                                        onChange={e => setFilters({...filters, spots: e.target.value})}
                                    />
                                </th>
                                <th className="p-2">
                                    <select 
                                        className="w-full border border-slate-300 rounded px-2 py-1 text-xs focus:ring-1 focus:ring-blue-500 outline-none font-normal bg-white"
                                        value={filters.status}
                                        onChange={e => setFilters({...filters, status: e.target.value})}
                                    >
                                        <option value="All">Todos</option>
                                        <option value="Active">Ativo</option>
                                        <option value="Churn Risk">Risco</option>
                                        <option value="Inactive">Inativo</option>
                                    </select>
                                </th>
                                <th className="p-2 text-center text-xs text-slate-400 font-normal">
                                    -
                                </th>
                                <th className="p-2">
                                    <input 
                                        type="text" 
                                        placeholder="Valor..." 
                                        className="w-full border border-slate-300 rounded px-2 py-1 text-xs focus:ring-1 focus:ring-blue-500 outline-none font-normal text-right"
                                        value={filters.value}
                                        onChange={e => setFilters({...filters, value: e.target.value})}
                                    />
                                </th>
                                <th className="p-2"></th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                            {filteredClients.map(client => {
                                const daysInactive = client.lastContact 
                                    ? Math.floor((new Date().getTime() - new Date(client.lastContact).getTime()) / (1000 * 3600 * 24))
                                    : 999;
                                    
                                return (
                                <tr key={client.id} className="hover:bg-slate-50 group cursor-pointer transition-colors" onClick={() => setSelectedClient(client)}>
                                    <td className="p-4">
                                        <div className="font-bold text-slate-900">{client.name}</div>
                                        <div className="text-xs text-slate-400 flex gap-2">
                                            {client.contractId && <span className="bg-slate-100 px-1 rounded">Contrato: {client.contractId}</span>}
                                            <span>ID: {client.id}</span>
                                        </div>
                                    </td>
                                    <td className="p-4">
                                        <div className="text-slate-800 text-sm">{client.unit || client.address || '-'}</div>
                                        <div className="text-[10px] text-slate-500 uppercase">{client.segment}</div>
                                    </td>
                                    <td className="p-4 text-center">
                                        {client.parkingSpots !== undefined ? (
                                            <span className="bg-blue-50 text-blue-700 px-2 py-1 rounded text-xs font-bold border border-blue-100">
                                                {client.parkingSpots}
                                            </span>
                                        ) : '-'}
                                    </td>
                                    <td className="p-4 text-center">
                                        <span className={`px-2 py-1 rounded-full text-xs font-bold flex w-fit mx-auto items-center gap-1 border
                                            ${client.status === 'Active' ? 'bg-green-50 text-green-700 border-green-100' : 
                                              client.status === 'Churn Risk' ? 'bg-red-50 text-red-700 border-red-100' :
                                              'bg-slate-100 text-slate-500 border-slate-200'}`}>
                                            <div className={`w-1.5 h-1.5 rounded-full ${
                                                client.status === 'Active' ? 'bg-green-500' : 
                                                client.status === 'Churn Risk' ? 'bg-red-500' : 'bg-slate-400'
                                            }`}></div>
                                            {client.status === 'Active' ? 'Ativo' : client.status === 'Churn Risk' ? 'Risco' : 'Inativo'}
                                        </span>
                                    </td>
                                    <td className="p-4 text-center">
                                        {client.lastContact ? (
                                            <div className="flex flex-col items-center">
                                                <span className={`text-xs font-medium flex items-center gap-1 ${daysInactive > 30 ? 'text-red-600' : 'text-slate-600'}`}>
                                                    {new Date(client.lastContact).toLocaleDateString()}
                                                    {daysInactive > 30 && <AlertCircle size={12} />}
                                                </span>
                                                <span className="text-[10px] text-slate-400">{daysInactive} dias</span>
                                            </div>
                                        ) : (
                                            <span className="text-xs text-slate-400 italic">Sem registro</span>
                                        )}
                                    </td>
                                    <td className="p-4 text-right font-medium text-slate-700">
                                        {client.totalTablePrice ? `R$ ${client.totalTablePrice.toLocaleString()}` : `R$ ${client.ltv.toLocaleString()}`}
                                    </td>
                                    <td className="p-4 text-center">
                                        <div className="flex items-center justify-center gap-1">
                                            <button 
                                                onClick={(e) => handleWhatsAppClick(e, client)}
                                                className="p-2 text-slate-400 hover:text-green-600 hover:bg-green-50 rounded-full transition"
                                                title="Mensagem WhatsApp"
                                            >
                                                <MessageCircle size={20}/>
                                            </button>
                                            
                                            {(currentUser.role === 'admin' || hasPermission('clients', 'delete')) && (
                                                <button 
                                                    onClick={(e) => handleDeleteClick(e, client)}
                                                    className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-full transition"
                                                    title="Excluir Cliente"
                                                >
                                                    <Trash2 size={18}/>
                                                </button>
                                            )}
                                        </div>
                                    </td>
                                </tr>
                            )})}
                            {filteredClients.length === 0 && (
                                <tr>
                                    <td colSpan={7} className="p-12 text-center text-slate-400 italic">
                                        <Filter size={48} className="mx-auto mb-3 opacity-20"/>
                                        <p>Nenhum cliente encontrado com os filtros atuais.</p>
                                        <button onClick={() => {setSearchTerm(''); setFilters({name:'', unit:'', spots:'', status:'All', lastContact:'', value:''})}} className="text-blue-600 text-xs font-bold mt-2 hover:underline">Limpar todos os filtros</button>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* WHATSAPP MODAL */}
            {showWhatsAppModal && clientForWhatsApp && (
                <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
                    <div className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden animate-scale-in">
                        <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-[#25D366]/10">
                            <h2 className="text-lg font-bold text-[#128C7E] flex items-center gap-2">
                                <MessageCircle size={20}/> WhatsApp: {clientForWhatsApp.name}
                            </h2>
                            <button onClick={() => setShowWhatsAppModal(false)} className="text-slate-400 hover:text-slate-600 p-1 rounded-full hover:bg-slate-100"><X size={20}/></button>
                        </div>
                        
                        <div className="p-6">
                            <p className="text-sm text-slate-600 mb-4">Escolha um modelo de mensagem:</p>
                            
                            <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
                                {whatsappTemplates.map((tmpl, idx) => (
                                    <button 
                                        key={idx}
                                        onClick={() => setWhatsAppMessage(tmpl.text.replace('[Nome]', clientForWhatsApp.contactPerson.split(' ')[0]).replace('[Empresa]', clientForWhatsApp.name))}
                                        className="px-3 py-1.5 bg-slate-100 hover:bg-blue-50 text-slate-600 hover:text-blue-600 text-xs font-medium rounded-full border border-slate-200 transition whitespace-nowrap"
                                    >
                                        {tmpl.label}
                                    </button>
                                ))}
                            </div>

                            <textarea 
                                className="w-full h-32 p-3 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-[#25D366] outline-none resize-none"
                                value={whatsAppMessage}
                                onChange={(e) => setWhatsAppMessage(e.target.value)}
                            />
                            
                            <div className="mt-4 flex justify-end">
                                <button 
                                    onClick={handleSendWhatsApp}
                                    className="bg-[#25D366] text-white px-6 py-2 rounded-lg font-bold hover:bg-[#128C7E] transition flex items-center gap-2 shadow-sm"
                                >
                                    <Send size={16}/> Enviar
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* NEW CLIENT MODAL */}
            {isNewClientModalOpen && (
                <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
                    <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl overflow-hidden animate-scale-in">
                        <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                            <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                                <Building className="text-blue-600" size={24}/> Cadastro de Cliente
                            </h2>
                            <button onClick={() => { setIsNewClientModalOpen(false); setEmailError(null); setPhoneError(null); setCnpjError(null); }} className="text-slate-400 hover:text-slate-600 p-2 rounded-full hover:bg-slate-200 transition">
                                <X size={20}/>
                            </button>
                        </div>
                        
                        <form onSubmit={handleCreateClient} className="p-6 overflow-y-auto max-h-[80vh]">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="col-span-1 md:col-span-2">
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Nome da Empresa *</label>
                                    <div className="relative">
                                        <Building size={18} className="absolute left-3 top-2.5 text-slate-400"/>
                                        <input 
                                            required 
                                            type="text" 
                                            className="w-full border border-slate-300 rounded-lg pl-10 p-2.5 focus:ring-2 focus:ring-blue-500 outline-none" 
                                            placeholder="Razão Social ou Nome Fantasia"
                                            value={newClientForm.name}
                                            onChange={e => setNewClientForm({...newClientForm, name: e.target.value})}
                                        />
                                    </div>
                                </div>

                                <div className="col-span-1 md:col-span-2">
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">CNPJ</label>
                                    <div className="relative">
                                        <FileText size={18} className={`absolute left-3 top-2.5 ${cnpjError ? 'text-red-500' : 'text-slate-400'}`}/>
                                        <input 
                                            type="text" 
                                            className={`w-full border rounded-lg pl-10 p-2.5 outline-none transition
                                                ${cnpjError 
                                                    ? 'border-red-500 focus:ring-red-200' 
                                                    : 'border-slate-300 focus:ring-2 focus:ring-blue-500'
                                                }
                                                ${!cnpjError && newClientForm.cnpj.length === 18 ? 'border-green-500' : ''}
                                            `}
                                            placeholder="00.000.000/0000-00"
                                            value={newClientForm.cnpj}
                                            onChange={handleCnpjChange}
                                            maxLength={18}
                                        />
                                        {/* Feedback Icon Right */}
                                        {cnpjError && (
                                            <AlertCircle size={18} className="absolute right-3 top-2.5 text-red-500 animate-pulse"/>
                                        )}
                                        {!cnpjError && newClientForm.cnpj.length === 18 && (
                                            <CheckCircle size={18} className="absolute right-3 top-2.5 text-green-500"/>
                                        )}
                                    </div>
                                    {cnpjError && <p className="text-xs text-red-500 mt-1 font-medium">{cnpjError}</p>}
                                </div>

                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Pessoa de Contato *</label>
                                    <div className="relative">
                                        <User size={18} className="absolute left-3 top-2.5 text-slate-400"/>
                                        <input 
                                            required 
                                            type="text" 
                                            className="w-full border border-slate-300 rounded-lg pl-10 p-2.5 focus:ring-2 focus:ring-blue-500 outline-none" 
                                            placeholder="Nome do responsável"
                                            value={newClientForm.contactPerson}
                                            onChange={e => setNewClientForm({...newClientForm, contactPerson: e.target.value})}
                                        />
                                    </div>
                                </div>

                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Segmento</label>
                                    <div className="relative">
                                        <Briefcase size={18} className="absolute left-3 top-2.5 text-slate-400"/>
                                        <input 
                                            type="text" 
                                            className="w-full border border-slate-300 rounded-lg pl-10 p-2.5 focus:ring-2 focus:ring-blue-500 outline-none" 
                                            placeholder="Ex: Varejo, Tecnologia..."
                                            value={newClientForm.segment}
                                            onChange={e => setNewClientForm({...newClientForm, segment: e.target.value})}
                                        />
                                    </div>
                                </div>

                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Email *</label>
                                    <div className="relative">
                                        <Mail size={18} className={`absolute left-3 top-2.5 ${emailError ? 'text-red-500' : 'text-slate-400'}`}/>
                                        <input 
                                            required 
                                            type="email" 
                                            className={`w-full border rounded-lg pl-10 p-2.5 outline-none transition
                                                ${emailError 
                                                    ? 'border-red-500 focus:ring-red-200' 
                                                    : 'border-slate-300 focus:ring-2 focus:ring-blue-500'
                                                }
                                                ${!emailError && newClientForm.email.length > 5 ? 'border-green-500' : ''}
                                            `}
                                            placeholder="contato@empresa.com"
                                            value={newClientForm.email}
                                            onChange={handleEmailChange}
                                        />
                                        {/* Feedback Icon Right */}
                                        {emailError && (
                                            <AlertCircle size={18} className="absolute right-3 top-2.5 text-red-500 animate-pulse"/>
                                        )}
                                        {!emailError && newClientForm.email.length > 0 && emailError === '' && (
                                            <CheckCircle size={18} className="absolute right-3 top-2.5 text-green-500"/>
                                        )}
                                    </div>
                                    {emailError && <p className="text-xs text-red-500 mt-1 font-medium">{emailError}</p>}
                                </div>

                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Telefone</label>
                                    <div className="relative">
                                        <Phone size={18} className={`absolute left-3 top-2.5 ${phoneError ? 'text-red-500' : 'text-slate-400'}`}/>
                                        <input 
                                            type="text" 
                                            className={`w-full border rounded-lg pl-10 p-2.5 outline-none transition
                                                ${phoneError 
                                                    ? 'border-red-500 focus:ring-red-200' 
                                                    : 'border-slate-300 focus:ring-2 focus:ring-blue-500'
                                                }
                                                ${!phoneError && newClientForm.phone.length > 13 ? 'border-green-500' : ''}
                                            `}
                                            placeholder="(00) 00000-0000"
                                            value={newClientForm.phone}
                                            onChange={handlePhoneChange}
                                            maxLength={15}
                                        />
                                         {/* Feedback Icon Right */}
                                         {phoneError && (
                                            <AlertCircle size={18} className="absolute right-3 top-2.5 text-red-500 animate-pulse"/>
                                        )}
                                        {!phoneError && newClientForm.phone.length > 13 && phoneError === '' && (
                                            <CheckCircle size={18} className="absolute right-3 top-2.5 text-green-500"/>
                                        )}
                                    </div>
                                    {phoneError && <p className="text-xs text-red-500 mt-1 font-medium">{phoneError}</p>}
                                </div>

                                <div className="col-span-1 md:col-span-2">
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Endereço / Unidade</label>
                                    <div className="relative">
                                        <MapPin size={18} className="absolute left-3 top-2.5 text-slate-400"/>
                                        <input 
                                            type="text" 
                                            className="w-full border border-slate-300 rounded-lg pl-10 p-2.5 focus:ring-2 focus:ring-blue-500 outline-none" 
                                            placeholder="Rua, Número, Cidade - Estado"
                                            value={newClientForm.address}
                                            onChange={e => setNewClientForm({...newClientForm, address: e.target.value})}
                                        />
                                    </div>
                                </div>

                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Site</label>
                                    <div className="relative">
                                        <Globe size={18} className="absolute left-3 top-2.5 text-slate-400"/>
                                        <input 
                                            type="text" 
                                            className="w-full border border-slate-300 rounded-lg pl-10 p-2.5 focus:ring-2 focus:ring-blue-500 outline-none" 
                                            placeholder="www.empresa.com.br"
                                            value={newClientForm.website}
                                            onChange={e => setNewClientForm({...newClientForm, website: e.target.value})}
                                        />
                                    </div>
                                </div>

                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">LTV Estimado Inicial (R$)</label>
                                    <input 
                                        type="number" 
                                        className="w-full border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none" 
                                        placeholder="0.00"
                                        value={newClientForm.ltv}
                                        onChange={e => setNewClientForm({...newClientForm, ltv: e.target.value})}
                                    />
                                </div>
                            </div>

                            <div className="mt-8 flex justify-end gap-3 pt-4 border-t border-slate-100">
                                <button 
                                    type="button" 
                                    onClick={() => { setIsNewClientModalOpen(false); setEmailError(null); setPhoneError(null); setCnpjError(null); }} 
                                    className="px-6 py-2.5 rounded-lg border border-slate-300 text-slate-700 font-medium hover:bg-slate-50 transition"
                                >
                                    Cancelar
                                </button>
                                <button 
                                    type="submit" 
                                    disabled={!!emailError || !!phoneError || !!cnpjError}
                                    className={`px-6 py-2.5 rounded-lg text-white font-bold shadow-lg transition transform active:scale-95 flex items-center gap-2
                                        ${emailError || phoneError || cnpjError 
                                            ? 'bg-slate-400 cursor-not-allowed' 
                                            : 'bg-blue-600 hover:bg-blue-700 shadow-blue-500/30'
                                        }
                                    `}
                                >
                                    <Save size={18}/> Salvar Cliente
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* INACTIVE CLIENTS MODAL */}
            {showInactiveModal && inactiveClients.length > 0 && (
                <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4 backdrop-blur-sm animate-fade-in">
                    <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl overflow-hidden animate-scale-in border-t-4 border-amber-500">
                        <div className="p-6 border-b border-slate-100 flex justify-between items-start bg-amber-50">
                            <div className="flex gap-4">
                                <div className="bg-amber-100 p-3 rounded-full text-amber-600 h-fit">
                                    <Clock size={24} />
                                </div>
                                <div>
                                    <h2 className="text-xl font-bold text-slate-900">Alerta de Contato Mensal</h2>
                                    <p className="text-sm text-amber-800 font-medium mt-1">
                                        Existem {inactiveClients.length} clientes ativos sem contato há mais de 30 dias.
                                    </p>
                                </div>
                            </div>
                            <button onClick={() => setShowInactiveModal(false)} className="text-slate-400 hover:text-slate-600 p-1 hover:bg-amber-100 rounded-full transition"><X size={20}/></button>
                        </div>
                        
                        <div className="p-0 max-h-[60vh] overflow-y-auto custom-scrollbar">
                            {inactiveClients.map(client => {
                                const days = Math.floor((new Date().getTime() - new Date(client.lastContact || client.since).getTime()) / (1000 * 3600 * 24));
                                return (
                                    <div key={client.id} className="flex items-center justify-between p-4 border-b border-slate-100 hover:bg-slate-50 transition group">
                                        <div>
                                            <p className="font-bold text-slate-800">{client.name}</p>
                                            <p className="text-xs text-slate-500">{client.contactPerson}</p>
                                        </div>
                                        <div className="flex items-center gap-4">
                                            <div className="text-right">
                                                <span className="text-xs font-bold text-amber-600 bg-amber-50 px-2 py-1 rounded border border-amber-100 block mb-1">
                                                    {days} dias sem contato
                                                </span>
                                                <p className="text-[10px] text-slate-400">Último: {client.lastContact ? new Date(client.lastContact).toLocaleDateString() : 'N/A'}</p>
                                            </div>
                                            <button 
                                                onClick={() => handleViewClientFromAlert(client)}
                                                className="flex items-center gap-1 text-xs bg-white border border-slate-200 text-slate-600 px-3 py-1.5 rounded hover:bg-blue-50 hover:text-blue-600 hover:border-blue-200 transition font-medium shadow-sm"
                                            >
                                                Contatar <ArrowRight size={14}/>
                                            </button>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>

                        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
                            <button 
                                onClick={() => setShowInactiveModal(false)}
                                className="bg-slate-800 text-white px-6 py-2 rounded-lg font-medium hover:bg-slate-700 transition text-sm"
                            >
                                Fechar e Analisar Depois
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* CONFIRM DELETE MODAL */}
            {isDeleteModalOpen && clientToDelete && (
                <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4 backdrop-blur-sm animate-fade-in">
                    <div className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden animate-scale-in">
                        <div className="p-6 border-b border-red-100 flex justify-between items-start bg-red-50">
                            <div className="flex gap-4">
                                <div className="bg-red-100 p-3 rounded-full text-red-600 h-fit">
                                    <AlertTriangle size={24} />
                                </div>
                                <div>
                                    <h2 className="text-lg font-bold text-slate-900">Confirmar Exclusão</h2>
                                    <p className="text-sm text-red-700 font-medium mt-1">Esta ação é irreversível.</p>
                                </div>
                            </div>
                            <button onClick={() => setIsDeleteModalOpen(false)} className="text-slate-400 hover:text-slate-600 p-1 hover:bg-red-100 rounded-full transition"><X size={20}/></button>
                        </div>
                        
                        <div className="p-6 space-y-4">
                            <p className="text-slate-600 text-sm">
                                Você está prestes a remover permanentemente o cliente <strong>{clientToDelete.name}</strong> da base de dados.
                            </p>
                            
                            <div>
                                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                                    Justificativa da Exclusão <span className="text-red-500">*</span>
                                </label>
                                <textarea 
                                    className="w-full border border-slate-300 rounded-lg p-3 focus:ring-2 focus:ring-red-500 outline-none text-sm h-24 resize-none"
                                    placeholder="Digite o motivo da exclusão (mínimo 5 caracteres)..."
                                    value={deleteReason}
                                    onChange={(e) => setDeleteReason(e.target.value)}
                                />
                                <p className="text-xs text-slate-400 mt-1 text-right">
                                    {deleteReason.length}/5 caracteres
                                </p>
                            </div>
                        </div>

                        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end gap-3">
                            <button 
                                onClick={() => setIsDeleteModalOpen(false)}
                                className="px-4 py-2 rounded-lg border border-slate-300 text-slate-700 font-medium hover:bg-slate-100 transition"
                            >
                                Cancelar
                            </button>
                            <button 
                                onClick={handleConfirmDelete}
                                disabled={deleteReason.length < 5}
                                className="px-6 py-2 rounded-lg bg-red-600 text-white font-bold hover:bg-red-700 shadow-md transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                            >
                                <Trash2 size={16}/> Confirmar Exclusão
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {selectedClient && (
                <Client360 
                    client={selectedClient} 
                    leads={leads}
                    tickets={tickets}
                    invoices={invoices}
                    onClose={() => setSelectedClient(null)} 
                />
            )}
        </div>
    );
};