import React, { useState, useMemo, useRef } from 'react';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';
import { Badge } from '../components/Widgets';
import { PipelineFunnel } from '../components/Charts';
import { Mail, Phone, Calendar, MapPin, Globe, Car, Box, X, AlertCircle, Clock, Flame, ThermometerSnowflake, Activity, MessageCircle, Send, BarChart2, ChevronDown, ChevronUp, Mic, Square, Loader2, PlayCircle, GraduationCap, Sparkles, Copy } from 'lucide-react';
import { generateLeadEmail, processAudioNote, generateSalesObjectionResponse } from '../services/geminiService';
import { Lead, LeadStatus, Note } from '../types';

export const Commercial: React.FC = () => {
  const { leads, updateLeadStatus, addLead, addIssueNote } = useData(); // addIssueNote reutilizado para leads (simulado via lógica local abaixo)
  const { currentUser } = useAuth();
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [generatedEmail, setGeneratedEmail] = useState<string>('');
  const [loadingEmail, setLoadingEmail] = useState(false);
  const [showFunnelChart, setShowFunnelChart] = useState(true);

  // Audio Recording State
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessingAudio, setIsProcessingAudio] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // Sales Coach State
  const [activeTab, setActiveTab] = useState<'details' | 'coach'>('details');
  const [coachScript, setCoachScript] = useState('');
  const [isCoachLoading, setIsCoachLoading] = useState(false);

  // WhatsApp Modal State
  const [showWhatsAppModal, setShowWhatsAppModal] = useState(false);
  const [whatsAppMessage, setWhatsAppMessage] = useState('');

  // New Lead Modal State
  const [isNewLeadModalOpen, setIsNewLeadModalOpen] = useState(false);
  const [newLeadForm, setNewLeadForm] = useState({
      name: '',
      company: '',
      email: '',
      phone: '',
      address: '',
      website: '',
      parkingSpots: '',
      productInterest: '',
      source: 'Web',
      value: '' // Estimated value
  });

  const whatsappTemplates = [
      { label: 'Primeiro Contato', text: 'Olá [Nome], tudo bem? Sou da Nexus CRM. Vi que você demonstrou interesse em nossa solução e gostaria de entender melhor seu cenário.' },
      { label: 'Follow-up Proposta', text: 'Olá [Nome], como vai? Conseguiu avaliar a proposta que enviei? Estou à disposição para tirar dúvidas.' },
      { label: 'Agendar Reunião', text: 'Oi [Nome], gostaria de agendar uma breve conversa para te apresentar como podemos ajudar a [Empresa]. Qual sua disponibilidade?' },
      { label: 'Confirmação', text: 'Olá [Nome], confirmando nossa reunião para amanhã. Tudo certo?' }
  ];

  // Define the order of stages for easy movement
  const stages: LeadStatus[] = [
    LeadStatus.NEW,
    LeadStatus.QUALIFIED,
    LeadStatus.PROPOSAL,
    LeadStatus.NEGOTIATION,
    LeadStatus.CLOSED_WON
  ];

  // Prepare Data for Funnel Chart
  const funnelData = useMemo(() => [
      { name: 'Novo', value: leads.filter(l => l.status === LeadStatus.NEW).length },
      { name: 'Qualificado', value: leads.filter(l => l.status === LeadStatus.QUALIFIED).length },
      { name: 'Proposta', value: leads.filter(l => l.status === LeadStatus.PROPOSAL).length },
      { name: 'Negociação', value: leads.filter(l => l.status === LeadStatus.NEGOTIATION).length },
      { name: 'Fechado', value: leads.filter(l => l.status === LeadStatus.CLOSED_WON).length },
  ], [leads]);

  // --- LEAD SCORING ALGORITHM (Based on Profile, Interactions, Interest) ---
  const calculateLeadScore = (lead: Lead) => {
      let score = 0;
      const reasons: string[] = [];

      // 1. Perfil (Valor & Cargo/Origem) (Max 40)
      if (lead.value > 10000) { score += 30; reasons.push("+30 Perfil: Alto Valor Potencial"); }
      else if (lead.value > 5000) { score += 15; reasons.push("+15 Perfil: Valor Médio"); }
      
      if (lead.source === 'Indicação' || lead.source === 'LinkedIn') { score += 10; reasons.push("+10 Perfil: Origem Qualificada"); }

      // 2. Interesse (Produto) (Max 20)
      if (lead.productInterest && (lead.productInterest.includes('Enterprise') || lead.productInterest.includes('Corporate'))) {
          score += 20;
          reasons.push("+20 Interesse: Solução Enterprise");
      }

      // 3. Interações (Recência) (Max 40)
      const daysInactive = getDaysInactive(lead.lastContact);
      if (daysInactive <= 3) { score += 40; reasons.push("+40 Interação: Contato Recente (< 3 dias)"); }
      else if (daysInactive <= 7) { score += 20; reasons.push("+20 Interação: Contato Semanal"); }
      else if (daysInactive > 30) { score -= 10; reasons.push("-10 Interação: Inativo há muito tempo"); }

      // Bônus de Estágio
      if (lead.status === LeadStatus.NEGOTIATION) score += 10;

      // Cap at 100
      const finalScore = Math.min(Math.max(score, 0), 100);
      
      let term = 'Frio';
      let color = 'text-blue-500';
      let icon = ThermometerSnowflake;
      let bg = 'bg-blue-50';

      if (finalScore >= 80) { term = 'Quente 🔥'; color = 'text-red-500'; icon = Flame; bg = 'bg-red-50'; }
      else if (finalScore >= 50) { term = 'Morno'; color = 'text-yellow-500'; icon = Activity; bg = 'bg-yellow-50'; }

      return { score: finalScore, term, color, icon, reasons, bg };
  };

  const handleGenerateEmail = async (lead: Lead) => {
    setLoadingEmail(true);
    setGeneratedEmail('');
    const email = await generateLeadEmail(lead);
    setGeneratedEmail(email);
    setLoadingEmail(false);
  };

  const handleGenerateObjection = async (objectionType: string) => {
      if (!selectedLead) return;
      setIsCoachLoading(true);
      setCoachScript('');
      const script = await generateSalesObjectionResponse(selectedLead, objectionType);
      setCoachScript(script);
      setIsCoachLoading(false);
  };

  const changeStatus = (newStatus: LeadStatus) => {
    if (selectedLead) {
        updateLeadStatus(currentUser, selectedLead.id, newStatus);
        setSelectedLead({ ...selectedLead, status: newStatus }); // Update local state for modal
    }
  };

  // Google Calendar Integration
  const handleAddToCalendar = (lead: Lead) => {
      // Define event details
      const title = `Reunião: ${lead.name} - ${lead.company}`;
      
      const details = `
Reunião Comercial - Nexus CRM
---------------------------
Cliente: ${lead.name}
Empresa: ${lead.company}
Telefone: ${lead.phone || 'Não informado'}
Email: ${lead.email}
Interesse: ${lead.productInterest || 'Geral'}
Valor Potencial: R$ ${lead.value.toLocaleString()}

Gerado via Nexus CRM
      `.trim();

      const location = lead.address || '';

      // Create Google Calendar Render URL
      const params = new URLSearchParams({
          action: 'TEMPLATE',
          text: title,
          details: details,
          location: location,
          // dates: Not setting dates lets Google Calendar default to the next available hour slot
      });

      const url = `https://calendar.google.com/calendar/render?${params.toString()}`;
      
      // Open in new tab
      window.open(url, '_blank');
  };

  const openWhatsAppModal = () => {
      if (selectedLead) {
          // Select first template by default and replace variables
          const defaultTmpl = whatsappTemplates[0];
          const text = defaultTmpl.text
            .replace('[Nome]', selectedLead.name.split(' ')[0])
            .replace('[Empresa]', selectedLead.company);
          setWhatsAppMessage(text);
          setShowWhatsAppModal(true);
      }
  };

  const handleQuickWhatsApp = (e: React.MouseEvent, lead: Lead) => {
      e.stopPropagation(); // Previne abrir o modal de detalhes
      setSelectedLead(lead);
      
      const defaultTmpl = whatsappTemplates[0];
      const text = defaultTmpl.text
        .replace('[Nome]', lead.name.split(' ')[0])
        .replace('[Empresa]', lead.company);
      
      setWhatsAppMessage(text);
      setShowWhatsAppModal(true);
  };

  const handleSendWhatsApp = () => {
      if (!selectedLead) return;
      const phone = selectedLead.phone?.replace(/\D/g, '') || '';
      const text = encodeURIComponent(whatsAppMessage);
      window.open(`https://wa.me/${phone}?text=${text}`, '_blank');
      setShowWhatsAppModal(false);
  };

  const handleCreateLead = (e: React.FormEvent) => {
      e.preventDefault();
      const newLead: Lead = {
          id: `L-${Date.now()}`,
          name: newLeadForm.name,
          company: newLeadForm.company,
          email: newLeadForm.email,
          phone: newLeadForm.phone,
          address: newLeadForm.address,
          website: newLeadForm.website,
          parkingSpots: Number(newLeadForm.parkingSpots) || 0,
          productInterest: newLeadForm.productInterest,
          source: newLeadForm.source,
          value: Number(newLeadForm.value) || 0,
          status: LeadStatus.NEW,
          probability: 10,
          lastContact: new Date().toISOString(),
          createdAt: new Date().toISOString() // Set creation date for cycle calculation
      };

      addLead(currentUser, newLead);
      setIsNewLeadModalOpen(false);
      setNewLeadForm({
        name: '', company: '', email: '', phone: '', address: '', website: '', parkingSpots: '', productInterest: '', source: 'Web', value: ''
      });
  };

  const getDaysInactive = (dateStr: string) => {
      const diff = new Date().getTime() - new Date(dateStr).getTime();
      return Math.floor(diff / (1000 * 3600 * 24));
  };

  // --- AUDIO RECORDING LOGIC ---
  const startRecording = async () => {
      try {
          const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
          const mediaRecorder = new MediaRecorder(stream);
          mediaRecorderRef.current = mediaRecorder;
          audioChunksRef.current = [];

          mediaRecorder.ondataavailable = (event) => {
              if (event.data.size > 0) {
                  audioChunksRef.current.push(event.data);
              }
          };

          mediaRecorder.onstop = handleAudioStop;
          mediaRecorder.start();
          setIsRecording(true);
      } catch (err) {
          console.error("Error accessing microphone:", err);
          alert("Não foi possível acessar o microfone. Verifique as permissões.");
      }
  };

  const stopRecording = () => {
      if (mediaRecorderRef.current && isRecording) {
          mediaRecorderRef.current.stop();
          setIsRecording(false);
          // Stop all tracks to release mic
          mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
      }
  };

  const handleAudioStop = async () => {
      setIsProcessingAudio(true);
      const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
      
      // Convert Blob to Base64
      const reader = new FileReader();
      reader.readAsDataURL(audioBlob);
      reader.onloadend = async () => {
          const base64Audio = reader.result as string;
          const analysis = await processAudioNote(base64Audio);
          
          // Add Note to System (Simulated via a temp Note state locally for this demo, 
          // or we could add a `notes` field to Lead type. 
          // Since we don't have updateLeadNotes, we will use a local state visualization or alert)
          
          if(selectedLead) {
             // In a real app, we would save this note to the lead.
             // Here we just append to generatedEmail for demo visibility or alert.
             setGeneratedEmail(prev => (prev ? prev + "\n\n--- NOTA DE VOZ ---\n" : "--- NOTA DE VOZ ---\n") + analysis);
          }
          setIsProcessingAudio(false);
      };
  };

  return (
    <div className="p-4 md:p-8 h-full flex flex-col">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4 shrink-0">
        <div>
            <h1 className="text-3xl font-bold text-slate-900">Comercial / Pipeline</h1>
            <p className="text-slate-500">Gestão de oportunidades com Lead Scoring Inteligente.</p>
        </div>
        <div className="flex gap-2 w-full md:w-auto overflow-x-auto">
            <button 
                onClick={() => setShowFunnelChart(!showFunnelChart)}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg border text-sm font-medium transition whitespace-nowrap ${showFunnelChart ? 'bg-indigo-50 text-indigo-700 border-indigo-200' : 'bg-white text-slate-600 border-slate-200'}`}
            >
                <BarChart2 size={18}/> {showFunnelChart ? 'Ocultar Funil' : 'Ver Funil'}
            </button>
            <button 
                onClick={() => setIsNewLeadModalOpen(true)}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition shadow-sm font-medium whitespace-nowrap"
            >
                + Novo Lead
            </button>
        </div>
      </div>

      {/* ANALYTICS SECTION (TOGGLEABLE) */}
      {showFunnelChart && (
          <div className="mb-6 bg-white p-6 rounded-xl shadow-sm border border-slate-200 shrink-0 animate-fade-in flex flex-col md:flex-row gap-6">
               <div className="flex-1">
                   <h3 className="text-sm font-bold text-slate-700 uppercase mb-4">Saúde do Pipeline</h3>
                   <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                       <div className="p-3 bg-blue-50 rounded-lg border border-blue-100">
                           <p className="text-xs text-blue-500 font-bold uppercase">Volume Total</p>
                           <p className="text-xl font-bold text-blue-700">{leads.length} Leads</p>
                       </div>
                       <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-100">
                           <p className="text-xs text-emerald-500 font-bold uppercase">Valor em Jogo</p>
                           <p className="text-xl font-bold text-emerald-700">R$ {leads.filter(l => l.status !== 'Perdido' && l.status !== 'Ganho').reduce((acc, curr) => acc + curr.value, 0).toLocaleString()}</p>
                       </div>
                       <div className="p-3 bg-indigo-50 rounded-lg border border-indigo-100">
                           <p className="text-xs text-indigo-500 font-bold uppercase">Taxa de Conversão</p>
                           <p className="text-xl font-bold text-indigo-700">
                               {leads.length > 0 ? ((leads.filter(l => l.status === 'Ganho').length / leads.length) * 100).toFixed(1) : 0}%
                           </p>
                       </div>
                       <div className="p-3 bg-amber-50 rounded-lg border border-amber-100">
                           <p className="text-xs text-amber-500 font-bold uppercase">Estagnados (>30d)</p>
                           <p className="text-xl font-bold text-amber-700">{leads.filter(l => getDaysInactive(l.lastContact) > 30 && l.status !== 'Ganho' && l.status !== 'Perdido').length}</p>
                       </div>
                   </div>
               </div>
               <div className="w-full md:w-1/3 border-l border-slate-100 md:pl-6">
                    <h3 className="text-sm font-bold text-slate-700 uppercase mb-2">Funil Visual</h3>
                    <div className="h-40">
                         <PipelineFunnel data={funnelData} />
                    </div>
               </div>
          </div>
      )}

      {/* KANBAN BOARD */}
      <div className="flex flex-1 gap-4 md:gap-6 overflow-x-auto pb-4 px-1">
        {[LeadStatus.NEW, LeadStatus.QUALIFIED, LeadStatus.PROPOSAL, LeadStatus.NEGOTIATION, LeadStatus.CLOSED_WON].map((stage, idx) => (
            <div key={stage} className="min-w-[280px] md:min-w-[300px] bg-slate-100 rounded-xl p-3 md:p-4 flex flex-col border border-slate-200">
                <div className={`flex justify-between items-center mb-4 sticky top-0 pb-2 z-10 border-b border-slate-200/50 rounded-t-lg
                     ${idx === 0 ? 'bg-slate-100' : ''}
                `}>
                    <h3 className="font-bold text-slate-700 truncate pr-2 text-sm md:text-base" title={stage}>{stage}</h3>
                    <span className="bg-white px-2 py-1 rounded text-xs font-bold text-slate-500 shadow-sm">
                        {leads.filter(l => l.status === stage).length}
                    </span>
                </div>
                
                <div className="space-y-3 overflow-y-auto flex-1 custom-scrollbar">
                    {leads.filter(l => l.status === stage).map(lead => {
                        const daysInactive = getDaysInactive(lead.lastContact);
                        const { score, color, icon: ScoreIcon } = calculateLeadScore(lead);
                        
                        return (
                        <div 
                            key={lead.id} 
                            onClick={() => { setSelectedLead(lead); setActiveTab('details'); setCoachScript(''); }}
                            className={`bg-white p-3 md:p-4 rounded-lg shadow-sm cursor-pointer hover:shadow-md transition border group relative
                                ${daysInactive > 5 && lead.status !== 'Ganho' ? 'border-red-200 ring-1 ring-red-100' : 'border-slate-200 hover:border-blue-300'}
                            `}
                        >
                            {/* Score Indicator Badge (Top Right) */}
                            {lead.status !== 'Ganho' && lead.status !== 'Perdido' && (
                                <div className="absolute top-2 right-2 flex items-center gap-1">
                                    <div className={`flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[10px] font-bold border ${score >= 80 ? 'bg-red-50 text-red-600 border-red-100' : 'bg-slate-50 text-slate-500 border-slate-100'}`}>
                                        <ScoreIcon size={10} className={score >= 80 ? 'fill-red-500' : ''}/> {score}
                                    </div>
                                    
                                    {daysInactive > 5 && (
                                        <div className="text-red-500 bg-red-50 p-1 rounded-full" title={`${daysInactive} dias sem atividade`}>
                                            <AlertCircle size={14} />
                                        </div>
                                    )}
                                </div>
                            )}

                            <div className="flex justify-between items-start mb-2 pr-16">
                                <span className="font-bold text-slate-800 group-hover:text-blue-700 transition-colors truncate max-w-[150px] text-sm md:text-base">{lead.name}</span>
                            </div>
                            <p className="text-xs md:text-sm text-slate-500 mb-2 truncate">{lead.company}</p>
                            
                            <div className="flex items-center justify-between text-xs text-slate-400 mt-3 border-t pt-2">
                                <div className="flex items-center gap-2">
                                    <span>R$ {lead.value.toLocaleString()}</span>
                                    {lead.phone && (
                                        <button 
                                            onClick={(e) => handleQuickWhatsApp(e, lead)}
                                            className="text-slate-300 hover:text-green-600 hover:bg-green-50 p-1 rounded transition"
                                            title="Enviar WhatsApp Rápido"
                                        >
                                            <MessageCircle size={14} />
                                        </button>
                                    )}
                                </div>
                                <Badge color={lead.probability > 70 ? 'green' : lead.probability > 30 ? 'yellow' : 'gray'}>{lead.probability}%</Badge>
                            </div>
                        </div>
                    )})}
                </div>
            </div>
        ))}
      </div>

      {/* NEW LEAD MODAL */}
      {isNewLeadModalOpen && (
          <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
              <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl overflow-hidden animate-scale-in">
                  <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                      <h2 className="text-xl font-bold text-slate-900">Cadastrar Novo Lead</h2>
                      <button onClick={() => setIsNewLeadModalOpen(false)} className="text-slate-400 hover:text-slate-600 hover:bg-slate-200 p-2 rounded-full transition"><X size={20}/></button>
                  </div>
                  
                  <form onSubmit={handleCreateLead} className="p-6 overflow-y-auto max-h-[80vh]">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          {/* ... (Existing form fields unchanged) ... */}
                          <div className="col-span-1 md:col-span-2">
                              <label className="block text-sm font-bold text-slate-700 mb-1">Nome Completo *</label>
                              <input required type="text" className="w-full border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Ex: João Silva" value={newLeadForm.name} onChange={e => setNewLeadForm({...newLeadForm, name: e.target.value})} />
                          </div>

                          <div>
                              <label className="block text-sm font-bold text-slate-700 mb-1">Nome da Empresa *</label>
                              <input required type="text" className="w-full border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Ex: Acme Corp" value={newLeadForm.company} onChange={e => setNewLeadForm({...newLeadForm, company: e.target.value})} />
                          </div>

                          <div>
                              <label className="block text-sm font-bold text-slate-700 mb-1">Email Corporativo *</label>
                              <input required type="email" className="w-full border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="joao@acme.com" value={newLeadForm.email} onChange={e => setNewLeadForm({...newLeadForm, email: e.target.value})} />
                          </div>

                          <div>
                              <label className="block text-sm font-bold text-slate-700 mb-1">Telefone / WhatsApp</label>
                              <input type="text" className="w-full border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="(11) 99999-9999" value={newLeadForm.phone} onChange={e => setNewLeadForm({...newLeadForm, phone: e.target.value})} />
                          </div>

                           <div>
                              <label className="block text-sm font-bold text-slate-700 mb-1">Site</label>
                              <input type="text" className="w-full border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="www.empresa.com" value={newLeadForm.website} onChange={e => setNewLeadForm({...newLeadForm, website: e.target.value})} />
                          </div>

                          <div className="col-span-1 md:col-span-2">
                              <label className="block text-sm font-bold text-slate-700 mb-1">Endereço</label>
                              <input type="text" className="w-full border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Rua das Flores, 123 - São Paulo" value={newLeadForm.address} onChange={e => setNewLeadForm({...newLeadForm, address: e.target.value})} />
                          </div>

                          <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 col-span-1 md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4">
                              <h3 className="text-sm font-bold text-slate-900 col-span-full border-b border-slate-200 pb-2 mb-2">Detalhes de Contratação</h3>
                              
                              <div>
                                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1">Qtd. Estacionamentos</label>
                                  <input type="number" min="0" className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="0" value={newLeadForm.parkingSpots} onChange={e => setNewLeadForm({...newLeadForm, parkingSpots: e.target.value})} />
                              </div>

                              <div>
                                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1">Produto de Interesse</label>
                                  <input type="text" className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Ex: Plano Enterprise" value={newLeadForm.productInterest} onChange={e => setNewLeadForm({...newLeadForm, productInterest: e.target.value})} />
                              </div>
                              
                              <div>
                                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1">Origem do Lead</label>
                                  <select className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none bg-white" value={newLeadForm.source} onChange={e => setNewLeadForm({...newLeadForm, source: e.target.value})}>
                                      <option value="Web">Web / Site</option>
                                      <option value="LinkedIn">LinkedIn</option>
                                      <option value="Indicação">Indicação</option>
                                      <option value="Evento">Evento</option>
                                      <option value="Outro">Outro</option>
                                  </select>
                              </div>

                               <div>
                                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1">Valor Potencial (R$)</label>
                                  <input type="number" className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="0.00" value={newLeadForm.value} onChange={e => setNewLeadForm({...newLeadForm, value: e.target.value})} />
                              </div>
                          </div>

                      </div>

                      <div className="mt-8 flex justify-end gap-3">
                          <button type="button" onClick={() => setIsNewLeadModalOpen(false)} className="px-6 py-2.5 rounded-lg border border-slate-300 text-slate-700 font-medium hover:bg-slate-50 transition">Cancelar</button>
                          <button type="submit" className="px-6 py-2.5 rounded-lg bg-blue-600 text-white font-bold hover:bg-blue-700 shadow-lg shadow-blue-500/30 transition transform active:scale-95">Criar Lead</button>
                      </div>
                  </form>
              </div>
          </div>
      )}

      {/* WHATSAPP MODAL */}
      {showWhatsAppModal && selectedLead && (
          <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
              <div className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden animate-scale-in">
                  <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-[#25D366]/10">
                      <h2 className="text-lg font-bold text-[#128C7E] flex items-center gap-2">
                          <MessageCircle size={20}/> Mensagem WhatsApp
                      </h2>
                      <button onClick={() => setShowWhatsAppModal(false)} className="text-slate-400 hover:text-slate-600 p-1 rounded-full hover:bg-slate-100"><X size={20}/></button>
                  </div>
                  
                  <div className="p-6">
                      <p className="text-sm text-slate-600 mb-4">Escolha um modelo para iniciar a conversa com <strong>{selectedLead.name}</strong>:</p>
                      
                      <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
                          {whatsappTemplates.map((tmpl, idx) => (
                              <button 
                                key={idx}
                                onClick={() => setWhatsAppMessage(tmpl.text.replace('[Nome]', selectedLead.name.split(' ')[0]).replace('[Empresa]', selectedLead.company))}
                                className="px-3 py-1.5 bg-slate-100 hover:bg-blue-50 text-slate-600 hover:text-blue-600 text-xs font-medium rounded-full border border-slate-200 transition whitespace-nowrap"
                              >
                                  {tmpl.label}
                              </button>
                          ))}
                      </div>

                      <textarea 
                          className="w-full h-32 p-3 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-[#25D366] outline-none resize-none"
                          value={whatsAppMessage}
                          onChange={(e) => setWhatsAppMessage(e.target.value)}
                      />
                      
                      <div className="mt-4 flex justify-end">
                          <button 
                            onClick={handleSendWhatsApp}
                            className="bg-[#25D366] text-white px-6 py-2 rounded-lg font-bold hover:bg-[#128C7E] transition flex items-center gap-2 shadow-sm"
                          >
                              <Send size={16}/> Enviar
                          </button>
                      </div>
                  </div>
              </div>
          </div>
      )}

      {/* LEAD DETAIL MODAL */}
      {selectedLead && !showWhatsAppModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col animate-scale-in overflow-hidden">
                <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50 shrink-0">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-bold">
                            {selectedLead.name.charAt(0)}
                        </div>
                        <div>
                            <h2 className="text-xl font-bold text-slate-900">{selectedLead.name}</h2>
                            <p className="text-sm text-slate-500">{selectedLead.id}</p>
                        </div>
                    </div>
                    <button onClick={() => { setSelectedLead(null); setGeneratedEmail(''); }} className="text-slate-400 hover:text-slate-600 p-2 hover:bg-slate-200 rounded-full">✕</button>
                </div>
                
                {/* Status Changer Toolbar */}
                <div className="bg-slate-50 px-6 py-3 border-b border-slate-200 flex items-center gap-2 overflow-x-auto shrink-0">
                    <span className="text-xs font-bold text-slate-500 uppercase whitespace-nowrap">Mover para:</span>
                    {stages.map(s => (
                        <button
                            key={s}
                            onClick={() => changeStatus(s)}
                            disabled={selectedLead.status === s}
                            className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-colors
                                ${selectedLead.status === s 
                                    ? 'bg-blue-600 text-white cursor-default' 
                                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-blue-50 hover:text-blue-600 hover:border-blue-200'
                                }`}
                        >
                            {s}
                        </button>
                    ))}
                     <button
                        onClick={() => changeStatus(LeadStatus.CLOSED_LOST)}
                        className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-colors border
                            ${selectedLead.status === LeadStatus.CLOSED_LOST
                                ? 'bg-red-600 text-white border-red-600'
                                : 'bg-white border-slate-200 text-slate-600 hover:bg-red-50 hover:text-red-600 hover:border-red-200'
                            }`}
                    >
                        Perdido
                    </button>
                </div>

                <div className="flex-1 overflow-y-auto p-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        {/* LEFT COLUMN: Details */}
                        <div className="space-y-4">
                            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                                <span className="w-1 h-4 bg-blue-500 rounded-full"></span>
                                Detalhes do Lead
                            </h3>
                            <div className="bg-slate-50 p-4 rounded-lg space-y-3 text-sm border border-slate-100">
                                <p className="flex justify-between"><span className="text-slate-500">Empresa:</span> <span className="font-medium">{selectedLead.company}</span></p>
                                <p className="flex justify-between"><span className="text-slate-500">Email:</span> <span className="font-medium text-blue-600">{selectedLead.email}</span></p>
                                
                                {selectedLead.phone && (
                                    <p className="flex justify-between items-center"><span className="text-slate-500">Telefone:</span> <span className="font-medium flex items-center gap-1"><Phone size={12}/>{selectedLead.phone}</span></p>
                                )}
                                {selectedLead.website && (
                                    <p className="flex justify-between items-center"><span className="text-slate-500">Site:</span> <span className="font-medium flex items-center gap-1"><Globe size={12}/>{selectedLead.website}</span></p>
                                )}
                                {selectedLead.address && (
                                    <p className="flex justify-between items-start"><span className="text-slate-500">Endereço:</span> <span className="font-medium text-right max-w-[150px]"><MapPin size={12} className="inline mr-1"/>{selectedLead.address}</span></p>
                                )}

                                <div className="border-t border-slate-200 my-2"></div>

                                {selectedLead.parkingSpots !== undefined && (
                                    <p className="flex justify-between items-center"><span className="text-slate-500">Estacionamentos:</span> <span className="font-medium flex items-center gap-1 bg-white px-2 py-0.5 rounded border border-slate-200"><Car size={12}/> {selectedLead.parkingSpots}</span></p>
                                )}
                                {selectedLead.productInterest && (
                                    <p className="flex justify-between items-center"><span className="text-slate-500">Interesse:</span> <span className="font-medium flex items-center gap-1 bg-blue-50 text-blue-700 px-2 py-0.5 rounded border border-blue-100"><Box size={12}/> {selectedLead.productInterest}</span></p>
                                )}

                                <div className="border-t border-slate-200 my-2"></div>

                                <p className="flex justify-between"><span className="text-slate-500">Valor Estimado:</span> <span className="font-medium text-emerald-600">R$ {selectedLead.value.toLocaleString()}</span></p>
                                <p className="flex justify-between"><span className="text-slate-500">Probabilidade:</span> <span className="font-medium">{selectedLead.probability}%</span></p>
                                <p className="flex justify-between"><span className="text-slate-500">Origem:</span> <span className="font-medium">{selectedLead.source}</span></p>
                                
                                <div className="border-t border-slate-200 my-2"></div>
                                
                                <p className="flex justify-between">
                                    <span className="text-slate-500">Última Interação:</span> 
                                    <span className="font-medium text-slate-800 flex items-center gap-1">
                                        {new Date(selectedLead.lastContact).toLocaleDateString()}
                                        {getDaysInactive(selectedLead.lastContact) > 3 && (
                                            <Clock size={12} className={getDaysInactive(selectedLead.lastContact) > 5 ? 'text-red-500' : 'text-amber-500'} />
                                        )}
                                    </span>
                                </p>
                            </div>
                        </div>
                        
                        {/* RIGHT COLUMN: Actions / Score / Coach */}
                        <div className="space-y-6">
                            {/* Toggle Tabs */}
                            <div className="flex bg-slate-100 p-1 rounded-lg">
                                <button 
                                    onClick={() => setActiveTab('details')}
                                    className={`flex-1 py-1.5 text-xs font-bold rounded-md transition ${activeTab === 'details' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                                >
                                    Ações & Score
                                </button>
                                <button 
                                    onClick={() => setActiveTab('coach')}
                                    className={`flex-1 py-1.5 text-xs font-bold rounded-md transition flex items-center justify-center gap-1 ${activeTab === 'coach' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                                >
                                    <GraduationCap size={14}/> Nexus Coach
                                </button>
                            </div>

                            {activeTab === 'details' ? (
                                <>
                                    {/* LEAD SCORING WIDGET */}
                                    {(() => {
                                        const { score, term, color, icon: ScoreIcon, reasons, bg } = calculateLeadScore(selectedLead);
                                        return (
                                            <div className={`p-4 rounded-xl shadow-lg relative overflow-hidden ${bg}`}>
                                                <div className="absolute top-0 right-0 w-24 h-24 bg-white opacity-5 rounded-full -mr-10 -mt-10"></div>
                                                <h3 className="text-sm font-bold uppercase tracking-wider mb-2 flex items-center gap-2 text-slate-700">
                                                    <Activity size={16}/> Lead Score
                                                </h3>
                                                <div className="flex items-end gap-3 mb-4">
                                                    <span className={`text-4xl font-bold ${color.replace('text-', 'text-')}`}>{score}</span>
                                                    <span className={`text-sm font-bold px-2 py-1 rounded bg-white/50 border border-white/20 ${color.replace('text-', 'text-')}`}>{term}</span>
                                                </div>
                                                <div className="space-y-1">
                                                    {reasons.map((r, i) => (
                                                        <div key={i} className="text-xs text-slate-600 flex items-center gap-1 font-medium">
                                                            <div className={`w-1 h-1 rounded-full ${color.replace('text-', 'bg-')}`}></div> {r}
                                                        </div>
                                                    ))}
                                                </div>
                                            </div>
                                        );
                                    })()}

                                    <div>
                                        <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2 mb-4">
                                            <span className="w-1 h-4 bg-indigo-500 rounded-full"></span>
                                            Ações Rápidas
                                        </h3>
                                        <div className="grid grid-cols-3 gap-2">
                                            <button className="flex flex-col items-center justify-center p-3 bg-white border border-slate-200 rounded-lg hover:bg-blue-50 hover:border-blue-200 hover:text-blue-600 transition group">
                                                <Mail size={20} className="mb-1 text-slate-400 group-hover:text-blue-500"/>
                                                <span className="text-xs font-medium">Email</span>
                                            </button>
                                            <button 
                                                onClick={openWhatsAppModal}
                                                className="flex flex-col items-center justify-center p-3 bg-white border border-slate-200 rounded-lg hover:bg-green-50 hover:border-green-200 hover:text-green-600 transition group"
                                            >
                                                <MessageCircle size={20} className="mb-1 text-slate-400 group-hover:text-green-500"/>
                                                <span className="text-xs font-medium">WhatsApp</span>
                                            </button>
                                            <button 
                                                onClick={() => handleAddToCalendar(selectedLead)}
                                                className="flex flex-col items-center justify-center p-3 bg-white border border-slate-200 rounded-lg hover:bg-purple-50 hover:border-purple-200 hover:text-purple-600 transition group"
                                            >
                                                <Calendar size={20} className="mb-1 text-slate-400 group-hover:text-purple-500"/>
                                                <span className="text-xs font-medium">Agendar</span>
                                            </button>
                                        </div>
                                    </div>

                                    {/* NEXUS VOICE RECORDER */}
                                    <div className="bg-slate-800 p-4 rounded-xl text-white">
                                        <div className="flex justify-between items-center mb-3">
                                            <h3 className="text-sm font-bold flex items-center gap-2">
                                                <Mic size={16} className="text-red-400"/> Nexus Voice Note
                                            </h3>
                                            {isProcessingAudio ? (
                                                <span className="text-xs flex items-center gap-1 text-slate-300"><Loader2 size={12} className="animate-spin"/> Transcrevendo...</span>
                                            ) : isRecording ? (
                                                <span className="text-xs text-red-400 animate-pulse font-bold">Gravando...</span>
                                            ) : (
                                                <span className="text-xs text-slate-400">Toque para gravar</span>
                                            )}
                                        </div>
                                        
                                        <div className="flex justify-center py-4 bg-slate-900/50 rounded-lg border border-slate-700 relative overflow-hidden">
                                            {isRecording && (
                                                <div className="absolute inset-0 flex items-center justify-center opacity-20 pointer-events-none">
                                                    <div className="w-16 h-16 bg-red-500 rounded-full animate-ping"></div>
                                                </div>
                                            )}
                                            
                                            {!isRecording ? (
                                                <button 
                                                    onClick={startRecording}
                                                    disabled={isProcessingAudio}
                                                    className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center hover:bg-red-600 hover:scale-110 transition shadow-lg shadow-red-500/30 disabled:opacity-50 disabled:cursor-not-allowed"
                                                >
                                                    <Mic size={24} className="text-white"/>
                                                </button>
                                            ) : (
                                                <button 
                                                    onClick={stopRecording}
                                                    className="w-12 h-12 bg-slate-700 border-2 border-red-500 rounded-full flex items-center justify-center hover:bg-slate-600 transition"
                                                >
                                                    <Square size={20} className="text-red-500 fill-red-500"/>
                                                </button>
                                            )}
                                        </div>
                                        <p className="text-[10px] text-center text-slate-500 mt-2">
                                            A IA irá transcrever, resumir e extrair próximos passos.
                                        </p>
                                    </div>
                                </>
                            ) : (
                                /* --- NEXUS COACH TAB --- */
                                <div className="space-y-4 animate-fade-in h-full flex flex-col">
                                    <div className="bg-indigo-50 p-4 rounded-xl border border-indigo-100">
                                        <div className="flex items-start gap-3">
                                            <div className="bg-indigo-100 p-2 rounded-full text-indigo-600">
                                                <GraduationCap size={20}/>
                                            </div>
                                            <div>
                                                <h4 className="text-sm font-bold text-indigo-900">Treinador de Vendas IA</h4>
                                                <p className="text-xs text-indigo-700 mt-1 leading-relaxed">
                                                    Selecione a objeção do cliente para receber um roteiro de contorno personalizado em tempo real.
                                                </p>
                                            </div>
                                        </div>
                                    </div>

                                    <div>
                                        <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Objeção Principal</label>
                                        <div className="grid grid-cols-2 gap-2">
                                            {['Preço Alto', 'Já usa Concorrente', 'Não é o momento', 'Preciso falar com Sócio'].map(obj => (
                                                <button
                                                    key={obj}
                                                    onClick={() => handleGenerateObjection(obj)}
                                                    className="text-xs py-2 px-3 bg-white border border-slate-200 rounded-lg hover:border-indigo-300 hover:bg-indigo-50 text-slate-700 hover:text-indigo-700 transition text-left"
                                                >
                                                    {obj}
                                                </button>
                                            ))}
                                        </div>
                                    </div>

                                    <div className="flex-1 bg-slate-50 rounded-xl border border-slate-200 p-4 relative min-h-[150px]">
                                        {isCoachLoading ? (
                                            <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-400 gap-2">
                                                <Sparkles size={24} className="animate-spin text-indigo-500"/>
                                                <span className="text-xs font-medium">Gerando script vencedor...</span>
                                            </div>
                                        ) : coachScript ? (
                                            <div className="space-y-2">
                                                <div className="flex justify-between items-center mb-1">
                                                    <span className="text-xs font-bold text-indigo-600 uppercase">Script Sugerido</span>
                                                    <button onClick={() => navigator.clipboard.writeText(coachScript)} className="text-slate-400 hover:text-indigo-600 p-1" title="Copiar"><Copy size={12}/></button>
                                                </div>
                                                <p className="text-sm text-slate-800 leading-relaxed italic">
                                                    "{coachScript}"
                                                </p>
                                            </div>
                                        ) : (
                                            <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-300 gap-2 text-center p-4">
                                                <MessageCircle size={24}/>
                                                <span className="text-xs">Selecione uma objeção acima para ver a mágica acontecer.</span>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
                
                {/* FOOTER: AI Email Generator (Visible in Details Tab only) */}
                {activeTab === 'details' && (
                    <div className="p-6 bg-indigo-50/50 border-t border-indigo-100 shrink-0">
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="font-bold flex items-center gap-2 text-indigo-900">
                            ✨ Nexus AI Assistant
                            </h3>
                            <button 
                                onClick={() => handleGenerateEmail(selectedLead)}
                                disabled={loadingEmail}
                                className="text-xs bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 disabled:opacity-50 font-medium shadow-sm transition-all"
                            >
                                {loadingEmail ? 'Gerando...' : 'Gerar E-mail de Follow-up'}
                            </button>
                        </div>
                        {generatedEmail && (
                            <div className="bg-white p-4 rounded-lg border border-indigo-100 text-sm whitespace-pre-wrap text-slate-700 font-mono shadow-sm animate-fade-in max-h-40 overflow-y-auto custom-scrollbar">
                                {generatedEmail}
                            </div>
                        )}
                        {!generatedEmail && (
                            <p className="text-sm text-indigo-400 italic">
                                O assistente exibirá sugestões de email ou as transcrições de voz aqui.
                            </p>
                        )}
                    </div>
                )}
            </div>
        </div>
      )}
    </div>
  );
};