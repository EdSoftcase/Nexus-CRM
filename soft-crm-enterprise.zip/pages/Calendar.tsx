
import React, { useState, useMemo } from 'react';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';
import { ChevronLeft, ChevronRight, Calendar as CalIcon, Clock, CheckCircle, Circle, Plus, Phone, Mail, Users, Filter, X, Video } from 'lucide-react';
import { Activity } from '../types';

export const Calendar: React.FC = () => {
    const { activities, toggleActivity, addActivity } = useData();
    const { currentUser } = useAuth();
    
    // State for Calendar View
    const [currentDate, setCurrentDate] = useState(new Date());
    const [selectedDate, setSelectedDate] = useState<Date | null>(new Date());
    
    // State for New Activity
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [createMeet, setCreateMeet] = useState(false);
    const [newActivityForm, setNewActivityForm] = useState({
        title: '',
        type: 'Call' as 'Call' | 'Meeting' | 'Email' | 'Task',
        time: '09:00',
        relatedTo: ''
    });

    // Helpers
    const getDaysInMonth = (year: number, month: number) => new Date(year, month + 1, 0).getDate();
    const getFirstDayOfMonth = (year: number, month: number) => new Date(year, month, 1).getDay();

    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    
    const daysInMonth = getDaysInMonth(year, month);
    const firstDay = getFirstDayOfMonth(year, month);
    
    const monthNames = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];

    // Navigation
    const prevMonth = () => setCurrentDate(new Date(year, month - 1, 1));
    const nextMonth = () => setCurrentDate(new Date(year, month + 1, 1));
    const goToToday = () => {
        const now = new Date();
        setCurrentDate(now);
        setSelectedDate(now);
    };

    // Data filtering
    const monthActivities = useMemo(() => {
        return activities.filter(a => {
            const d = new Date(a.dueDate);
            return d.getMonth() === month && d.getFullYear() === year;
        });
    }, [activities, month, year]);

    const selectedDayActivities = useMemo(() => {
        if (!selectedDate) return [];
        return activities.filter(a => {
            const d = new Date(a.dueDate);
            return d.getDate() === selectedDate.getDate() && 
                   d.getMonth() === selectedDate.getMonth() && 
                   d.getFullYear() === selectedDate.getFullYear();
        }).sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime());
    }, [activities, selectedDate]);

    // Handle Create Activity
    const handleCreateActivity = (e: React.FormEvent) => {
        e.preventDefault();
        if (!selectedDate) return;

        // Combine selected date with time input
        const [hours, minutes] = newActivityForm.time.split(':');
        const dueDateTime = new Date(selectedDate);
        dueDateTime.setHours(parseInt(hours), parseInt(minutes));

        const newActivity: Activity = {
            id: `ACT-${Date.now()}`,
            title: newActivityForm.title,
            type: newActivityForm.type,
            dueDate: dueDateTime.toISOString(),
            completed: false,
            relatedTo: newActivityForm.relatedTo || 'Geral',
            assignee: currentUser.id
        };

        addActivity(currentUser, newActivity);

        // Google Meet Logic
        if (createMeet) {
             // Format dates for Google Calendar URL (YYYYMMDDTHHMMSSZ)
             const startTime = dueDateTime.toISOString().replace(/-|:|\.\d\d\d/g, "");
             const endDate = new Date(dueDateTime.getTime() + 60 * 60 * 1000); // Assumes 1 hour duration
             const endTime = endDate.toISOString().replace(/-|:|\.\d\d\d/g, "");

             const title = encodeURIComponent(newActivityForm.title);
             const details = encodeURIComponent(`Contexto: ${newActivityForm.relatedTo || 'Geral'}\n\nAgendado via Nexus CRM.`);
             const location = encodeURIComponent("Google Meet");

             // Open Google Calendar Event Creation
             const url = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${title}&dates=${startTime}/${endTime}&details=${details}&location=${location}`;

             window.open(url, '_blank');
        }

        setIsAddModalOpen(false);
        setNewActivityForm({ title: '', type: 'Call', time: '09:00', relatedTo: '' });
        setCreateMeet(false);
    };

    const getTypeIcon = (type: string) => {
        switch(type) {
            case 'Call': return <Phone size={14} className="text-blue-500"/>;
            case 'Meeting': return <Users size={14} className="text-purple-500"/>;
            case 'Email': return <Mail size={14} className="text-yellow-500"/>;
            default: return <CheckCircle size={14} className="text-green-500"/>;
        }
    };

    const getTypeColor = (type: string) => {
        switch(type) {
            case 'Call': return 'bg-blue-100 text-blue-700 border-blue-200';
            case 'Meeting': return 'bg-purple-100 text-purple-700 border-purple-200';
            case 'Email': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
            default: return 'bg-green-100 text-green-700 border-green-200';
        }
    };

    // Calendar Grid Generation
    const renderCalendarDays = () => {
        const days = [];
        // Padding for previous month
        for (let i = 0; i < firstDay; i++) {
            days.push(<div key={`empty-${i}`} className="h-24 md:h-32 bg-slate-50/50 border border-slate-100"></div>);
        }
        
        // Days of current month
        for (let d = 1; d <= daysInMonth; d++) {
            const date = new Date(year, month, d);
            const isToday = new Date().toDateString() === date.toDateString();
            const isSelected = selectedDate?.toDateString() === date.toDateString();
            
            const dayActs = monthActivities.filter(a => new Date(a.dueDate).getDate() === d);
            
            days.push(
                <div 
                    key={d} 
                    onClick={() => setSelectedDate(date)}
                    className={`h-24 md:h-32 border p-2 cursor-pointer transition relative group flex flex-col
                        ${isSelected ? 'bg-blue-50 border-blue-300 ring-1 ring-blue-300 z-10' : 'bg-white border-slate-200 hover:border-blue-200 hover:bg-slate-50'}
                    `}
                >
                    <div className="flex justify-between items-start mb-1">
                        <span className={`text-sm font-bold w-7 h-7 flex items-center justify-center rounded-full
                            ${isToday ? 'bg-blue-600 text-white' : 'text-slate-700'}
                        `}>
                            {d}
                        </span>
                        {dayActs.length > 0 && (
                            <span className="text-[10px] font-bold bg-slate-100 text-slate-500 px-1.5 rounded-full border border-slate-200 md:hidden">
                                {dayActs.length}
                            </span>
                        )}
                    </div>
                    
                    {/* Desktop: Show list of items */}
                    <div className="hidden md:flex flex-col gap-1 overflow-y-auto custom-scrollbar flex-1">
                        {dayActs.slice(0, 3).map(act => (
                            <div key={act.id} className={`text-[10px] px-1.5 py-0.5 rounded border truncate flex items-center gap-1 ${getTypeColor(act.type)} ${act.completed ? 'opacity-50 line-through' : ''}`}>
                                {getTypeIcon(act.type)}
                                <span className="truncate">{act.title}</span>
                            </div>
                        ))}
                        {dayActs.length > 3 && (
                            <div className="text-[10px] text-slate-400 pl-1">
                                + {dayActs.length - 3} mais
                            </div>
                        )}
                    </div>

                    {/* Mobile: Show simple dots */}
                    <div className="md:hidden flex flex-wrap gap-1 mt-1 justify-center">
                        {dayActs.slice(0, 5).map((act, i) => (
                            <div key={i} className={`w-1.5 h-1.5 rounded-full ${
                                act.type === 'Call' ? 'bg-blue-500' : 
                                act.type === 'Meeting' ? 'bg-purple-500' : 
                                act.type === 'Email' ? 'bg-yellow-500' : 'bg-green-500'
                            }`}></div>
                        ))}
                    </div>
                </div>
            );
        }
        return days;
    };

    return (
        <div className="p-4 md:p-8 h-full flex flex-col">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4 shrink-0">
                <div>
                    <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-2">
                        <CalIcon className="text-blue-600"/> Agenda
                    </h1>
                    <p className="text-slate-500">Organize suas reuniões e tarefas.</p>
                </div>
                <div className="flex items-center gap-2 w-full md:w-auto">
                    <button onClick={goToToday} className="px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm font-medium hover:bg-slate-50 transition">Hoje</button>
                    <div className="flex items-center bg-white rounded-lg border border-slate-300 shadow-sm mx-2">
                        <button onClick={prevMonth} className="p-2 hover:bg-slate-100 text-slate-600"><ChevronLeft size={20}/></button>
                        <span className="px-4 font-bold text-slate-800 min-w-[140px] text-center">{monthNames[month]} {year}</span>
                        <button onClick={nextMonth} className="p-2 hover:bg-slate-100 text-slate-600"><ChevronRight size={20}/></button>
                    </div>
                    <button 
                        onClick={() => setIsAddModalOpen(true)}
                        className="ml-auto md:ml-0 bg-blue-600 text-white p-2 md:px-4 md:py-2 rounded-lg hover:bg-blue-700 transition flex items-center gap-2 shadow-sm"
                    >
                        <Plus size={20}/> <span className="hidden md:inline">Nova Tarefa</span>
                    </button>
                </div>
            </div>

            <div className="flex flex-col lg:flex-row gap-6 flex-1 overflow-hidden min-h-0">
                {/* Calendar Grid */}
                <div className="flex-1 bg-white rounded-xl shadow-sm border border-slate-200 flex flex-col overflow-hidden">
                    {/* Weekday Headers */}
                    <div className="grid grid-cols-7 border-b border-slate-200 bg-slate-50">
                        {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map(day => (
                            <div key={day} className="p-3 text-center text-xs font-bold text-slate-500 uppercase">
                                {day}
                            </div>
                        ))}
                    </div>
                    {/* Days Grid */}
                    <div className="grid grid-cols-7 flex-1 overflow-y-auto custom-scrollbar bg-slate-100 gap-px border-l border-t border-slate-200">
                        {renderCalendarDays()}
                    </div>
                </div>

                {/* Side Panel: Selected Day Details */}
                <div className="w-full lg:w-80 bg-white rounded-xl shadow-sm border border-slate-200 flex flex-col overflow-hidden shrink-0 h-[300px] lg:h-auto">
                    <div className="p-4 border-b border-slate-200 bg-slate-50">
                        <h3 className="font-bold text-slate-800 flex items-center gap-2">
                            <Clock size={18} className="text-slate-400"/> 
                            {selectedDate ? selectedDate.toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' }) : 'Selecione um dia'}
                        </h3>
                    </div>
                    <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
                        {selectedDayActivities.length === 0 ? (
                            <div className="text-center py-8 text-slate-400">
                                <p className="text-sm">Nenhuma atividade para este dia.</p>
                                <button onClick={() => setIsAddModalOpen(true)} className="text-blue-600 text-xs font-bold mt-2 hover:underline">Adicionar Agora</button>
                            </div>
                        ) : (
                            selectedDayActivities.map(act => (
                                <div key={act.id} className={`p-3 rounded-lg border transition group ${act.completed ? 'bg-slate-50 border-slate-100 opacity-70' : 'bg-white border-slate-200 hover:border-blue-300 shadow-sm'}`}>
                                    <div className="flex items-start gap-3">
                                        <button onClick={() => toggleActivity(currentUser, act.id)} className={`mt-0.5 ${act.completed ? 'text-green-500' : 'text-slate-300 hover:text-blue-500'}`}>
                                            {act.completed ? <CheckCircle size={18}/> : <Circle size={18}/>}
                                        </button>
                                        <div className="flex-1 min-w-0">
                                            <p className={`text-sm font-medium truncate ${act.completed ? 'text-slate-500 line-through' : 'text-slate-800'}`}>{act.title}</p>
                                            <div className="flex items-center gap-2 mt-1">
                                                <span className={`text-[10px] px-1.5 py-0.5 rounded flex items-center gap-1 border ${getTypeColor(act.type)}`}>
                                                    {getTypeIcon(act.type)} {act.type}
                                                </span>
                                                <span className="text-xs text-slate-400 font-mono">
                                                    {new Date(act.dueDate).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                                </span>
                                            </div>
                                            {act.relatedTo && <p className="text-xs text-slate-500 mt-1 truncate">Ref: {act.relatedTo}</p>}
                                        </div>
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                </div>
            </div>

            {/* NEW ACTIVITY MODAL */}
            {isAddModalOpen && (
                <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
                    <div className="bg-white rounded-xl shadow-2xl w-full max-w-md animate-scale-in overflow-hidden">
                        <div className="p-4 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
                            <h3 className="font-bold text-slate-900">Nova Atividade</h3>
                            <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-slate-600"><X size={20}/></button>
                        </div>
                        <form onSubmit={handleCreateActivity} className="p-6 space-y-4">
                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Título</label>
                                <input required type="text" className="w-full border rounded p-2 text-sm" placeholder="Ex: Reunião com Cliente" value={newActivityForm.title} onChange={e => setNewActivityForm({...newActivityForm, title: e.target.value})} />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Tipo</label>
                                    <select className="w-full border rounded p-2 text-sm bg-white" value={newActivityForm.type} onChange={e => setNewActivityForm({...newActivityForm, type: e.target.value as any})}>
                                        <option value="Call">Ligação</option>
                                        <option value="Meeting">Reunião</option>
                                        <option value="Email">Email</option>
                                        <option value="Task">Tarefa</option>
                                    </select>
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Horário</label>
                                    <input type="time" className="w-full border rounded p-2 text-sm" value={newActivityForm.time} onChange={e => setNewActivityForm({...newActivityForm, time: e.target.value})} />
                                </div>
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Relacionado a (Opcional)</label>
                                <input type="text" className="w-full border rounded p-2 text-sm" placeholder="Nome do Cliente ou Lead" value={newActivityForm.relatedTo} onChange={e => setNewActivityForm({...newActivityForm, relatedTo: e.target.value})} />
                            </div>

                            {/* GOOGLE MEET CHECKBOX */}
                            <div className="flex items-start gap-3 p-3 bg-blue-50 border border-blue-100 rounded-lg">
                                <div className="bg-white p-1 rounded-full border border-blue-200 mt-0.5">
                                    <Video size={16} className="text-blue-600"/>
                                </div>
                                <div>
                                    <label className="flex items-center gap-2 text-sm font-bold text-slate-700 cursor-pointer">
                                        <input 
                                            type="checkbox" 
                                            checked={createMeet} 
                                            onChange={(e) => setCreateMeet(e.target.checked)}
                                            className="w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                                        />
                                        Criar reunião no Google Meet?
                                    </label>
                                    <p className="text-xs text-slate-500 mt-1">
                                        Isso abrirá o Google Calendar para você adicionar convidados e gerar o link da reunião.
                                    </p>
                                </div>
                            </div>

                            <div className="pt-2">
                                <p className="text-xs text-slate-500 mb-2">Data selecionada: <strong>{selectedDate?.toLocaleDateString()}</strong></p>
                                <button type="submit" className="w-full bg-blue-600 text-white font-bold py-2 rounded-lg hover:bg-blue-700">Salvar Atividade</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};
