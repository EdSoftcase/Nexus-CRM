
import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { UserCircle, Shield, Check, Activity, Search, Lock, Eye, Edit, Trash, Plus, Users, UserCog, Edit2, Trash2, X, Save, Phone, Mail, FileText, User as UserIcon, Database, CheckCircle, AlertCircle, RefreshCw, BarChart2, Cloud, HardDrive, UploadCloud, Package, Tag, ShoppingCart, ShieldCheck, Code, Copy, Wrench, Building2, Key, Globe, Terminal, Info, ExternalLink, Share2, MessageCircle, AlertTriangle } from 'lucide-react';
import { SectionTitle } from '../components/Widgets';
import { Role, PermissionAction, User, Product } from '../types';
import { getSupabaseConfig, saveSupabaseConfig, testSupabaseConnection, getSupabase } from '../services/supabaseClient';
import { MOCK_ORGANIZATIONS } from '../constants';

export const Settings: React.FC = () => {
  const { currentUser, currentOrganization, switchOrganization, login, logout, permissionMatrix, updatePermission, updateUser, usersList, adminUpdateUser, adminDeleteUser, isSuperAdmin } = useAuth();
  const { logs, leads, clients, tickets, invoices, issues, syncLocalToCloud, isSyncing, products, addProduct, removeProduct, activities } = useData();
  const [activeTab, setActiveTab] = useState<'profile' | 'permissions' | 'audit' | 'access' | 'integrations' | 'products' | 'saas_admin'>('profile');
  const [logSearch, setLogSearch] = useState('');
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  
  // Products State
  const [newProduct, setNewProduct] = useState<Partial<Product>>({ active: true, category: 'Subscription' });
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);

  // SaaS Provisioning State
  const [newTenantForm, setNewTenantForm] = useState({ name: '', slug: '', adminEmail: '', plan: 'Standard', adminPassword: '' });
  const [generatedTenantData, setGeneratedTenantData] = useState<{ id: string, sql: string, steps: string, welcomeMessage: string } | null>(null);

  const [isEditUserModalOpen, setIsEditUserModalOpen] = useState(false);
  const [selectedUserForEdit, setSelectedUserForEdit] = useState<User | null>(null);
  const [supabaseForm, setSupabaseForm] = useState({ url: '', key: '' });
  const [connectionStatus, setConnectionStatus] = useState<'idle' | 'testing' | 'success' | 'error'>('idle');
  const [statusMessage, setStatusMessage] = useState('');
  const [diagnosticRunning, setDiagnosticRunning] = useState(false);
  const [diagnosticData, setDiagnosticData] = useState<any[] | null>(null);
  
  // Schema Generator State
  const [showSqlModal, setShowSqlModal] = useState(false);
  
  // Profile Form State
  const [profileForm, setProfileForm] = useState({
      name: currentUser.name,
      email: currentUser.email || '',
      phone: currentUser.phone || '',
      cpf: currentUser.cpf || '',
      password: '',
      confirmPassword: ''
  });
  
  // Permissions State
  const [selectedRoleForPerms, setSelectedRoleForPerms] = useState<Role>('sales');

  useEffect(() => {
      const config = getSupabaseConfig();
      setSupabaseForm({ url: config.url, key: config.key });
  }, []);

  const handleSaveSupabase = async (e: React.FormEvent) => {
      e.preventDefault();
      saveSupabaseConfig(supabaseForm.url, supabaseForm.key);
      setConnectionStatus('testing');
      const result = await testSupabaseConnection();
      if (result.success) {
          setConnectionStatus('success');
          setStatusMessage(result.message);
          setTimeout(() => {
             if(confirm("Conexão bem sucedida! O sistema precisa ser recarregado para sincronizar os dados da nuvem. Recarregar agora?")) {
                 window.location.reload();
             }
          }, 500);
      } else {
          setConnectionStatus('error');
          setStatusMessage(result.message);
      }
  };

  const runDiagnostic = async () => {
      const supabase = getSupabase();
      if (!supabase) { alert("Configure o Supabase primeiro."); return; }
      setDiagnosticRunning(true);
      try {
          const tables = [
              { name: 'leads', label: 'Leads', local: leads.length },
              { name: 'clients', label: 'Clientes', local: clients.length },
              { name: 'tickets', label: 'Tickets', local: tickets.length },
              { name: 'products', label: 'Produtos', local: products.length },
              { name: 'invoices', label: 'Faturas', local: invoices.length },
              { name: 'issues', label: 'Issues (Dev)', local: issues.length },
              { name: 'activities', label: 'Atividades', local: activities.length },
          ];
          const results = await Promise.all(tables.map(async (t) => {
              const { count, error } = await supabase.from(t.name).select('*', { count: 'exact', head: true });
              return { ...t, cloud: error ? 'Tabela não existe' : count || 0, status: error ? 'error' : (count === t.local ? 'synced' : 'diff') };
          }));
          setDiagnosticData(results);
      } catch (error) { console.error(error); alert("Erro ao rodar diagnóstico"); } finally { setDiagnosticRunning(false); }
  };

  const handleClearTable = async (tableName: string, label: string) => {
      if (!confirm(`ATENÇÃO: Você tem certeza que deseja APAGAR TODOS os dados de ${label}? Esta ação removerá apenas os dados da organização atual (${currentOrganization?.name || 'Atual'}), mas é irreversível.`)) return;
      
      const supabase = getSupabase();
      if (!supabase) { alert("Supabase não conectado."); return; }

      setDiagnosticRunning(true);
      try {
          // 1. Deleta do Banco de Dados
          const { error } = await supabase.from(tableName).delete().neq('id', '00000000-0000-0000-0000-000000000000'); 
          if (error) throw error;
          
          // 2. Remove do Cache Local
          localStorage.removeItem(`nexus_${tableName}`);

          alert(`${label} limpa com sucesso! O aplicativo será recarregado.`);
          window.location.reload();
      } catch (e: any) {
          alert(`Erro ao limpar tabela: ${e.message}`);
          console.error(e);
      } finally {
          setDiagnosticRunning(false);
      }
  };

  const handleLocalHardReset = () => {
      if (!confirm("Isso apagará TODO o cache local do navegador. Use isso se você deletou dados no banco mas eles continuam aparecendo aqui. Continuar?")) return;
      
      const keysToRemove = [];
      const keysToKeep = ['nexus_supabase_url', 'nexus_supabase_key', 'nexus_db_version', 'sb-'];
      
      for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          if (key && key.startsWith('nexus_')) {
              if (!keysToKeep.some(k => key.startsWith(k))) {
                  keysToRemove.push(key);
              }
          }
      }
      
      keysToRemove.forEach(k => localStorage.removeItem(k));
      window.location.reload();
  };

  const handleCreateProduct = (e: React.FormEvent) => {
      e.preventDefault();
      if (newProduct.name && newProduct.price) {
          addProduct(currentUser, {
              id: `PROD-${Date.now()}`,
              name: newProduct.name,
              description: newProduct.description || '',
              price: Number(newProduct.price),
              sku: newProduct.sku || `SKU-${Date.now()}`,
              category: newProduct.category as any,
              active: true
          });
          setIsProductModalOpen(false);
          setNewProduct({ active: true, category: 'Subscription' });
      }
  };

  const filteredLogs = logs.filter(l => l.action.toLowerCase().includes(logSearch.toLowerCase()) || l.details.toLowerCase().includes(logSearch.toLowerCase()));

  const handleSaveProfile = (e: React.FormEvent) => {
      e.preventDefault();
      updateUser({ name: profileForm.name, email: profileForm.email, phone: profileForm.phone });
      setIsEditingProfile(false);
      alert("Perfil atualizado!");
  };
  
  const toggleEditMode = () => setIsEditingProfile(!isEditingProfile);
  
  const testClientWrite = async () => {
      const supabase = getSupabase();
      if(!supabase) return;
      const testId = `TEST-${Date.now()}`;
      try {
          const { error } = await supabase.from('clients').insert({ id: testId, name: 'TESTE DE CONEXÃO', status: 'Inactive', since: new Date().toISOString() });
          if (error) alert(`ERRO: ${error.message}`);
          else { alert("SUCESSO! Escrita no banco realizada."); await supabase.from('clients').delete().eq('id', testId); }
      } catch (e: any) { alert(`ERRO CRÍTICO: ${e.message}`); }
  }

  // --- SAAS PROVISIONING LOGIC ---
  const generateTenant = (e: React.FormEvent) => {
      e.preventDefault();
      if (!newTenantForm.name) {
          alert("Preencha o nome da empresa.");
          return;
      }

      // Generate UUID (Mock for browser)
      const orgId = crypto.randomUUID ? crypto.randomUUID() : `org-${Date.now()}`;
      const slug = newTenantForm.name.toLowerCase().replace(/ /g, '-').replace(/[^\w-]+/g, '');
      
      const tempPassword = Math.random().toString(36).slice(-8);

      // Script SQL corrigido
      const sqlScript = `
-- 1. CRIAR ORGANIZAÇÃO
-- Cria o registro da empresa (Tenant)
INSERT INTO public.organizations (id, name, slug, subscription_status)
VALUES ('${orgId}', '${newTenantForm.name}', '${slug}', 'active');

-- 2. VINCULAR USUÁRIO ADMIN
-- ATENÇÃO: Substitua 'COLE_O_UID_AQUI' pelo ID real do usuário no Supabase
INSERT INTO public.profiles (id, organization_id, email, full_name, role)
VALUES ('COLE_O_UID_AQUI', '${orgId}', '${newTenantForm.adminEmail}', 'Admin ${newTenantForm.name}', 'admin')
ON CONFLICT (id) DO UPDATE SET organization_id = '${orgId}', role = 'admin';
      `.trim();

      const steps = `
1. No Painel Supabase, vá em **Authentication > Users**.
2. Clique em **Add User** > **Create New User**.
3. Digite o Email: ${newTenantForm.adminEmail}
4. Digite a Senha Provisória: ${tempPassword} (Anote!)
5. Desmarque "Auto Confirm Email" se quiser validar manualmente, ou clique em Create.
6. Copie o **User UID** gerado (ex: d222...).
7. Cole o UID no script SQL ao lado (onde diz COLE_O_UID_AQUI) e execute no SQL Editor.
      `.trim();

      const welcomeMessage = `
Olá! Sua conta no Nexus CRM foi criada com sucesso.

Aqui estão seus dados de acesso:
Empresa: ${newTenantForm.name}
Link: ${window.location.origin}
Login: ${newTenantForm.adminEmail}
Senha Provisória: ${tempPassword}

Ao entrar, você verá um ambiente totalmente limpo e exclusivo para sua empresa.
      `.trim();

      setGeneratedTenantData({ id: orgId, sql: sqlScript, steps, welcomeMessage });
  };

  const generateSchemaSQL = () => {
      return `
-- =================================================================
-- NEXUS CRM: ARQUITETURA MULTI-TENANT (SAAS) - V2 (MIGRATION SAFE)
-- Este script configura o banco para isolar dados por empresa.
-- INCLUI CORREÇÕES PARA BANCOS DE DADOS EXISTENTES.
-- =================================================================

-- 1. Habilitar extensões necessárias
create extension if not exists "uuid-ossp";

-- 2. Tabela de ORGANIZAÇÕES (Tenants)
create table if not exists public.organizations (
  id uuid default uuid_generate_v4() primary key,
  name text not null,
  slug text unique,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  subscription_status text default 'trial',
  stripe_customer_id text
);

-- 3. Tabela de PERFIS
create table if not exists public.profiles (
  id uuid references auth.users on delete cascade primary key,
  organization_id uuid references public.organizations(id),
  email text,
  full_name text,
  role text default 'admin',
  avatar_url text,
  updated_at timestamp with time zone
);

-- 4. Função Auxiliar: Obter ID da Organização
create or replace function public.get_current_org_id()
returns uuid as $$
  select organization_id from public.profiles where id = auth.uid() limit 1;
$$ language sql security definer;

-- =================================================================
-- MIGRAÇÃO DE TABELAS DE NEGÓCIO
-- Usa 'create table if not exists' + 'alter table add column'
-- para garantir que funciona em bancos novos E antigos.
-- =================================================================

-- LEADS
create table if not exists leads (id text primary key);
alter table leads add column if not exists organization_id uuid references public.organizations(id) default public.get_current_org_id();
alter table leads add column if not exists name text;
alter table leads add column if not exists company text;
alter table leads add column if not exists email text;
alter table leads add column if not exists value numeric;
alter table leads add column if not exists status text;
alter table leads add column if not exists "createdAt" text;
alter table leads add column if not exists "lastContact" text;

-- CLIENTS
create table if not exists clients (id text primary key);
alter table clients add column if not exists organization_id uuid references public.organizations(id) default public.get_current_org_id();
alter table clients add column if not exists name text;
alter table clients add column if not exists "contactPerson" text;
alter table clients add column if not exists email text;
alter table clients add column if not exists status text;

-- TICKETS
create table if not exists tickets (id text primary key);
alter table tickets add column if not exists organization_id uuid references public.organizations(id) default public.get_current_org_id();
alter table tickets add column if not exists subject text;
alter table tickets add column if not exists priority text;
alter table tickets add column if not exists status text;

-- INVOICES
create table if not exists invoices (id text primary key);
alter table invoices add column if not exists organization_id uuid references public.organizations(id) default public.get_current_org_id();
alter table invoices add column if not exists customer text;
alter table invoices add column if not exists amount numeric;
alter table invoices add column if not exists status text;

-- ACTIVITIES
create table if not exists activities (id text primary key);
alter table activities add column if not exists organization_id uuid references public.organizations(id) default public.get_current_org_id();
alter table activities add column if not exists title text;
alter table activities add column if not exists type text;

-- ISSUES
create table if not exists issues (id text primary key);
alter table issues add column if not exists organization_id uuid references public.organizations(id) default public.get_current_org_id();
alter table issues add column if not exists title text;
alter table issues add column if not exists status text;
alter table issues add column if not exists notes jsonb;

-- PROPOSALS
create table if not exists proposals (id text primary key);
alter table proposals add column if not exists organization_id uuid references public.organizations(id) default public.get_current_org_id();
alter table proposals add column if not exists title text;
alter table proposals add column if not exists price numeric;

-- PRODUCTS
create table if not exists products (id text primary key);
alter table products add column if not exists organization_id uuid references public.organizations(id) default public.get_current_org_id();
alter table products add column if not exists name text;
alter table products add column if not exists price numeric;

-- CLIENT DOCUMENTS
create table if not exists client_documents (id text primary key);
alter table client_documents add column if not exists organization_id uuid references public.organizations(id) default public.get_current_org_id();
alter table client_documents add column if not exists title text;
alter table client_documents add column if not exists url text;

-- AUDIT LOGS
create table if not exists audit_logs (id text primary key);
alter table audit_logs add column if not exists organization_id uuid references public.organizations(id) default public.get_current_org_id();
alter table audit_logs add column if not exists action text;
alter table audit_logs add column if not exists details text;

-- =================================================================
-- SEGURANÇA RLS (ROW LEVEL SECURITY)
-- Removemos políticas antigas para evitar duplicidade
-- =================================================================

-- Enable RLS
alter table organizations enable row level security;
alter table profiles enable row level security;
alter table leads enable row level security;
alter table clients enable row level security;
alter table tickets enable row level security;
alter table invoices enable row level security;
alter table activities enable row level security;
alter table issues enable row level security;
alter table proposals enable row level security;
alter table products enable row level security;
alter table client_documents enable row level security;
alter table audit_logs enable row level security;

-- Drop policies if exist (to allow re-run)
drop policy if exists "Tenant Isolation Policy" on leads;
drop policy if exists "Tenant Isolation Policy" on clients;
drop policy if exists "Tenant Isolation Policy" on tickets;
drop policy if exists "Tenant Isolation Policy" on invoices;
drop policy if exists "Tenant Isolation Policy" on activities;
drop policy if exists "Tenant Isolation Policy" on issues;
drop policy if exists "Tenant Isolation Policy" on proposals;
drop policy if exists "Tenant Isolation Policy" on products;
drop policy if exists "Tenant Isolation Policy" on client_documents;
drop policy if exists "Tenant Isolation Policy" on audit_logs;
drop policy if exists "User can see own profile" on profiles;
drop policy if exists "User can see own organization" on organizations;

-- Create Policies
create policy "Tenant Isolation Policy" on leads for all using (organization_id = public.get_current_org_id());
create policy "Tenant Isolation Policy" on clients for all using (organization_id = public.get_current_org_id());
create policy "Tenant Isolation Policy" on tickets for all using (organization_id = public.get_current_org_id());
create policy "Tenant Isolation Policy" on invoices for all using (organization_id = public.get_current_org_id());
create policy "Tenant Isolation Policy" on activities for all using (organization_id = public.get_current_org_id());
create policy "Tenant Isolation Policy" on issues for all using (organization_id = public.get_current_org_id());
create policy "Tenant Isolation Policy" on proposals for all using (organization_id = public.get_current_org_id());
create policy "Tenant Isolation Policy" on products for all using (organization_id = public.get_current_org_id());
create policy "Tenant Isolation Policy" on client_documents for all using (organization_id = public.get_current_org_id());
create policy "Tenant Isolation Policy" on audit_logs for all using (organization_id = public.get_current_org_id());

create policy "User can see own profile" on profiles for select using (auth.uid() = id);
create policy "User can see own organization" on organizations for select using (id = public.get_current_org_id());

-- =================================================================
-- AUTOMATIZAÇÃO DE ONBOARDING (TRIGGER)
-- =================================================================

create or replace function public.handle_new_user()
returns trigger as $$
declare
  new_org_id uuid;
begin
  -- 1. Cria uma nova Organização para o usuário (Auto-Serviço)
  insert into public.organizations (name)
  values (COALESCE(new.raw_user_meta_data->>'company_name', 'Minha Empresa'))
  returning id into new_org_id;

  -- 2. Cria o Perfil vinculado
  insert into public.profiles (id, organization_id, email, full_name, role)
  values (new.id, new_org_id, new.email, COALESCE(new.raw_user_meta_data->>'full_name', 'Admin'), 'admin');

  return new;
end;
$$ language plpgsql security definer;

-- Recreate Trigger
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
      `.trim();
  };

  const hasSchemaErrors = diagnosticData?.some(d => d.status === 'error');

  return (
    <div className="p-4 md:p-8 h-screen flex flex-col">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <h1 className="text-2xl md:text-3xl font-bold text-slate-900">Configurações & Governança</h1>
          <div className="flex bg-white rounded-lg border border-slate-200 p-1 w-full md:w-auto overflow-x-auto custom-scrollbar">
              <button onClick={() => setActiveTab('profile')} className={`px-4 py-2 rounded-md font-medium text-sm flex items-center gap-2 whitespace-nowrap ${activeTab === 'profile' ? 'bg-slate-100 text-slate-900' : 'text-slate-500 hover:text-slate-700'}`}><UserCircle size={16}/> Perfil</button>
              <button onClick={() => setActiveTab('products')} className={`px-4 py-2 rounded-md font-medium text-sm flex items-center gap-2 whitespace-nowrap ${activeTab === 'products' ? 'bg-slate-100 text-slate-900' : 'text-slate-500 hover:text-slate-700'}`}><Package size={16}/> Produtos</button>
              <button onClick={() => setActiveTab('permissions')} className={`px-4 py-2 rounded-md font-medium text-sm flex items-center gap-2 whitespace-nowrap ${activeTab === 'permissions' ? 'bg-slate-100 text-slate-900' : 'text-slate-500 hover:text-slate-700'}`}><Lock size={16}/> Permissões</button>
              {/* Oculta aba Gestão SaaS se não for Super Admin */}
              {isSuperAdmin && (
                  <button onClick={() => setActiveTab('saas_admin')} className={`px-4 py-2 rounded-md font-medium text-sm flex items-center gap-2 whitespace-nowrap ${activeTab === 'saas_admin' ? 'bg-indigo-50 text-indigo-700 border border-indigo-100' : 'text-slate-500 hover:text-slate-700'}`}><Building2 size={16}/> Gestão SaaS</button>
              )}
              <button onClick={() => setActiveTab('integrations')} className={`px-4 py-2 rounded-md font-medium text-sm flex items-center gap-2 whitespace-nowrap ${activeTab === 'integrations' ? 'bg-slate-100 text-slate-900' : 'text-slate-500 hover:text-slate-700'}`}><Database size={16}/> Integrações</button>
              <button onClick={() => setActiveTab('audit')} className={`px-4 py-2 rounded-md font-medium text-sm flex items-center gap-2 whitespace-nowrap ${activeTab === 'audit' ? 'bg-slate-100 text-slate-900' : 'text-slate-500 hover:text-slate-700'}`}><Activity size={16}/> Logs</button>
          </div>
      </div>

      {/* --- ABA SAAS ADMIN (PROVISIONING) --- */}
      {/* Proteção Dupla: Só renderiza se for Super Admin */}
      {activeTab === 'saas_admin' && isSuperAdmin && (
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 flex flex-col flex-1 overflow-hidden animate-fade-in">
              <div className="p-6 border-b border-slate-200 bg-indigo-50 flex justify-between items-center">
                  <div>
                      <h3 className="font-bold text-indigo-900 flex items-center gap-2"><Globe size={20} className="text-indigo-600"/> Provisionamento de Empresas</h3>
                      <p className="text-sm text-indigo-700 mt-1">Gere novas contas (Tenants) completamente isoladas.</p>
                  </div>
              </div>
              
              <div className="flex-1 overflow-y-auto p-8">
                  {/* EXPLICAÇÃO VISUAL DO ISOLAMENTO */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10 border-b border-slate-100 pb-10">
                      <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-center">
                          <div className="bg-white w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3 shadow-sm text-blue-600 font-bold border border-blue-100">1</div>
                          <h4 className="font-bold text-slate-800">Uma Instância</h4>
                          <p className="text-xs text-slate-500 mt-2">Todos os clientes compartilham o mesmo banco de dados, reduzindo custos.</p>
                      </div>
                      <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-center relative">
                          <div className="absolute top-1/2 -left-3 transform -translate-y-1/2 hidden md:block text-slate-300">→</div>
                          <div className="bg-indigo-600 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3 shadow-md text-white font-bold">2</div>
                          <h4 className="font-bold text-indigo-900">Muralha RLS</h4>
                          <p className="text-xs text-slate-600 mt-2">O banco aplica filtros invisíveis. Cliente A nunca vê dados do Cliente B.</p>
                      </div>
                      <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-center relative">
                          <div className="absolute top-1/2 -left-3 transform -translate-y-1/2 hidden md:block text-slate-300">→</div>
                          <div className="bg-white w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3 shadow-sm text-green-600 font-bold border border-green-100">3</div>
                          <h4 className="font-bold text-slate-800">Ambiente Limpo</h4>
                          <p className="text-xs text-slate-500 mt-2">O novo usuário loga e vê um painel vazio, pronto para usar.</p>
                      </div>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
                      
                      {/* Formuário de Criação */}
                      <div className="space-y-6">
                          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                              <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><Plus size={18}/> Novo Cliente SaaS</h4>
                              <form onSubmit={generateTenant} className="space-y-4">
                                  <div>
                                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Nome da Empresa</label>
                                      <input 
                                          required 
                                          type="text" 
                                          className="w-full border border-slate-300 rounded-lg p-2.5 outline-none focus:ring-2 focus:ring-indigo-500" 
                                          placeholder="Ex: Consultoria ABC Ltda"
                                          value={newTenantForm.name}
                                          onChange={e => setNewTenantForm({...newTenantForm, name: e.target.value})}
                                      />
                                  </div>
                                  <div>
                                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Email do Administrador (Login)</label>
                                      <input 
                                          required 
                                          type="email" 
                                          className="w-full border border-slate-300 rounded-lg p-2.5 outline-none focus:ring-2 focus:ring-indigo-500" 
                                          placeholder="admin@consultoriaabc.com"
                                          value={newTenantForm.adminEmail}
                                          onChange={e => setNewTenantForm({...newTenantForm, adminEmail: e.target.value})}
                                      />
                                  </div>
                                  <div>
                                      <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Plano Inicial</label>
                                      <select 
                                          className="w-full border border-slate-300 rounded-lg p-2.5 bg-white outline-none focus:ring-2 focus:ring-indigo-500"
                                          value={newTenantForm.plan}
                                          onChange={e => setNewTenantForm({...newTenantForm, plan: e.target.value})}
                                      >
                                          <option value="Trial">Trial (14 dias)</option>
                                          <option value="Standard">Standard</option>
                                          <option value="Enterprise">Enterprise</option>
                                      </select>
                                  </div>
                                  <button 
                                      type="submit" 
                                      className="w-full bg-indigo-600 text-white font-bold py-3 rounded-lg hover:bg-indigo-700 transition flex items-center justify-center gap-2 mt-2"
                                  >
                                      <Key size={18}/> Gerar Acesso
                                  </button>
                              </form>
                          </div>
                      </div>

                      {/* Resultado Gerado */}
                      <div className="space-y-6">
                          {generatedTenantData ? (
                              <div className="animate-fade-in space-y-6">
                                  <div className="bg-green-50 border border-green-200 p-4 rounded-xl">
                                      <h4 className="font-bold text-green-800 flex items-center gap-2"><CheckCircle size={18}/> Acesso Gerado</h4>
                                      <p className="text-sm text-green-700">Siga as instruções abaixo para ativar o cliente no Supabase.</p>
                                  </div>

                                  <div>
                                      <div className="flex justify-between items-center mb-1">
                                          <label className="text-xs font-bold text-slate-500 uppercase">1. Instruções Técnicas</label>
                                      </div>
                                      <div className="bg-white border border-slate-200 p-4 rounded-lg text-sm text-slate-700 whitespace-pre-wrap font-mono text-xs">
                                          {generatedTenantData.steps}
                                      </div>
                                  </div>

                                  <div>
                                      <div className="flex justify-between items-center mb-1">
                                          <label className="text-xs font-bold text-slate-500 uppercase">2. Script SQL (Para ativar isolamento)</label>
                                          <button onClick={() => navigator.clipboard.writeText(generatedTenantData.sql)} className="text-indigo-600 text-xs font-bold hover:underline">Copiar SQL</button>
                                      </div>
                                      <pre className="bg-slate-900 text-green-400 p-4 rounded-lg text-xs font-mono overflow-x-auto whitespace-pre-wrap select-all h-32 custom-scrollbar">
                                          {generatedTenantData.sql}
                                      </pre>
                                  </div>

                                  <div>
                                      <div className="flex justify-between items-center mb-1">
                                          <label className="text-xs font-bold text-slate-500 uppercase">3. Mensagem para o Cliente</label>
                                          <button 
                                            onClick={() => window.open(`https://wa.me/?text=${encodeURIComponent(generatedTenantData.welcomeMessage)}`, '_blank')} 
                                            className="text-green-600 text-xs font-bold hover:underline flex items-center gap-1"
                                          >
                                              <MessageCircle size={14}/> Enviar Whats
                                          </button>
                                      </div>
                                      <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg text-sm text-blue-900 whitespace-pre-wrap relative">
                                          {generatedTenantData.welcomeMessage}
                                          <button onClick={() => navigator.clipboard.writeText(generatedTenantData.welcomeMessage)} className="absolute top-2 right-2 text-blue-400 hover:text-blue-600"><Copy size={16}/></button>
                                      </div>
                                  </div>
                              </div>
                          ) : (
                              <div className="h-full flex flex-col items-center justify-center text-slate-400 border-2 border-dashed border-slate-200 rounded-xl p-8">
                                  <Building2 size={48} className="mb-4 opacity-20"/>
                                  <p className="text-center max-w-xs">Preencha o formulário para gerar as credenciais de um novo cliente.</p>
                              </div>
                          )}
                      </div>
                  </div>
              </div>
          </div>
      )}

      {/* --- ABA PRODUTOS --- */}
      {activeTab === 'products' && (
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 flex flex-col flex-1 overflow-hidden animate-fade-in">
              <div className="p-6 border-b border-slate-200 bg-slate-50 flex justify-between items-center">
                  <div>
                      <h3 className="font-bold text-slate-700 flex items-center gap-2"><Package size={20} className="text-blue-600"/> Catálogo de Produtos & Serviços</h3>
                      <p className="text-sm text-slate-500">Gerencie o portfólio disponível para propostas comerciais.</p>
                  </div>
                  <button onClick={() => setIsProductModalOpen(true)} className="bg-blue-600 text-white px-4 py-2 rounded-lg font-bold hover:bg-blue-700 flex items-center gap-2 shadow-sm">
                      <Plus size={18}/> Novo Item
                  </button>
              </div>
              
              <div className="flex-1 overflow-y-auto p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {products.map(product => (
                          <div key={product.id} className="border border-slate-200 rounded-xl p-4 hover:border-blue-300 hover:shadow-md transition bg-white group relative">
                              <div className="flex justify-between items-start mb-2">
                                  <div className="flex items-center gap-2">
                                      <div className={`p-2 rounded-lg ${product.category === 'Service' ? 'bg-purple-100 text-purple-600' : 'bg-emerald-100 text-emerald-600'}`}>
                                          {product.category === 'Service' ? <UserCog size={20}/> : <ShoppingCart size={20}/>}
                                      </div>
                                      <div>
                                          <h4 className="font-bold text-slate-800">{product.name}</h4>
                                          <p className="text-xs text-slate-400 font-mono">{product.sku}</p>
                                      </div>
                                  </div>
                                  <button onClick={() => removeProduct(currentUser, product.id)} className="text-slate-300 hover:text-red-500"><Trash2 size={18}/></button>
                              </div>
                              <p className="text-sm text-slate-600 mb-4 h-10 line-clamp-2">{product.description}</p>
                              <div className="flex justify-between items-end border-t border-slate-100 pt-3">
                                  <span className="text-xs font-bold bg-slate-100 text-slate-600 px-2 py-1 rounded">{product.category}</span>
                                  <span className="text-lg font-bold text-slate-900">R$ {product.price.toLocaleString()}</span>
                              </div>
                          </div>
                      ))}
                  </div>
              </div>
          </div>
      )}

      {/* --- PRODUCT MODAL --- */}
      {isProductModalOpen && (
          <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
              <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg">
                  <div className="p-6 border-b flex justify-between items-center"><h2 className="font-bold">Adicionar Produto</h2><button onClick={() => setIsProductModalOpen(false)}><X/></button></div>
                  <form onSubmit={handleCreateProduct} className="p-6 space-y-4">
                      <div><label className="text-xs font-bold uppercase text-slate-500">Nome do Item</label><input required type="text" className="w-full border rounded p-2" value={newProduct.name || ''} onChange={e => setNewProduct({...newProduct, name: e.target.value})} /></div>
                      <div className="grid grid-cols-2 gap-4">
                          <div><label className="text-xs font-bold uppercase text-slate-500">SKU</label><input type="text" className="w-full border rounded p-2" value={newProduct.sku || ''} onChange={e => setNewProduct({...newProduct, sku: e.target.value})} /></div>
                          <div><label className="text-xs font-bold uppercase text-slate-500">Preço (R$)</label><input required type="number" className="w-full border rounded p-2" value={newProduct.price || ''} onChange={e => setNewProduct({...newProduct, price: e.target.value})} /></div>
                      </div>
                      <div><label className="text-xs font-bold uppercase text-slate-500">Categoria</label><select className="w-full border rounded p-2" value={newProduct.category} onChange={e => setNewProduct({...newProduct, category: e.target.value as any})}><option value="Subscription">Assinatura</option><option value="Service">Serviço</option><option value="Product">Produto Físico</option></select></div>
                      <div><label className="text-xs font-bold uppercase text-slate-500">Descrição</label><textarea className="w-full border rounded p-2" value={newProduct.description || ''} onChange={e => setNewProduct({...newProduct, description: e.target.value})} /></div>
                      <button type="submit" className="w-full bg-blue-600 text-white font-bold py-2 rounded">Salvar Produto</button>
                  </form>
              </div>
          </div>
      )}

      {/* --- ABA PERFIL --- */}
      {activeTab === 'profile' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 overflow-y-auto">
            {/* Seção de Perfil Atual */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 h-fit relative">
              <div className="flex justify-between items-start mb-6">
                 <SectionTitle title="Meu Perfil" subtitle="Informações da conta ativa" />
                 <div className="flex gap-2">
                     {!isEditingProfile ? (
                         <>
                            <button onClick={toggleEditMode} className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition border border-transparent hover:border-blue-100"><Edit2 size={20} /></button>
                         </>
                     ) : (
                         <button onClick={toggleEditMode} className="p-2 text-slate-400 hover:bg-slate-100 rounded-lg transition"><X size={20} /></button>
                     )}
                 </div>
              </div>
              
              {isEditingProfile ? (
                  <form onSubmit={handleSaveProfile} className="space-y-4 animate-fade-in">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="md:col-span-2"><label className="block text-xs font-bold text-slate-500 uppercase mb-1">Nome Completo</label><input type="text" value={profileForm.name} onChange={e => setProfileForm({...profileForm, name: e.target.value})} className="w-full border border-slate-300 rounded-lg p-2.5 outline-none"/></div>
                          <div><label className="block text-xs font-bold text-slate-500 uppercase mb-1">Email</label><input type="email" value={profileForm.email} onChange={e => setProfileForm({...profileForm, email: e.target.value})} className="w-full border border-slate-300 rounded-lg p-2.5 outline-none"/></div>
                          <div><label className="block text-xs font-bold text-slate-500 uppercase mb-1">Telefone</label><input type="text" value={profileForm.phone} onChange={e => setProfileForm({...profileForm, phone: e.target.value})} className="w-full border border-slate-300 rounded-lg p-2.5 outline-none"/></div>
                      </div>
                      <div className="pt-4 flex justify-end gap-3"><button type="submit" className="px-6 py-2 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 transition flex items-center gap-2"><Save size={18} /> Salvar Alterações</button></div>
                  </form>
              ) : (
                  <div className="animate-fade-in">
                      <div className="flex items-center gap-6 mb-8">
                        <div className="w-20 h-20 bg-slate-100 text-slate-600 rounded-full flex items-center justify-center text-3xl font-bold border-2 border-white shadow-lg">{currentUser.avatar}</div>
                        <div>
                            <h3 className="text-2xl font-bold text-slate-900">{currentUser.name}</h3>
                            <div className="flex items-center gap-2 text-slate-500 mt-1">
                                <span className="bg-blue-100 text-blue-700 text-xs px-2 py-0.5 rounded-full font-bold uppercase tracking-wide border border-blue-200">{currentUser.role}</span>
                                {isSuperAdmin && <span className="bg-purple-100 text-purple-700 text-xs px-2 py-0.5 rounded-full font-bold uppercase tracking-wide border border-purple-200">Plataforma</span>}
                            </div>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="bg-slate-50 p-4 rounded-lg border border-slate-100"><p className="text-xs font-bold text-slate-400 uppercase mb-1 flex items-center gap-2"><Mail size={14}/> Email</p><p className="text-slate-700 font-medium">{currentUser.email || 'Não informado'}</p></div>
                          <div className="bg-slate-50 p-4 rounded-lg border border-slate-100"><p className="text-xs font-bold text-slate-400 uppercase mb-1 flex items-center gap-2"><Phone size={14}/> Telefone</p><p className="text-slate-700 font-medium">{currentUser.phone || 'Não informado'}</p></div>
                      </div>
                  </div>
              )}
            </div>

            {/* Nova Seção: Organização Atual (SaaS Context) */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 h-fit">
                <SectionTitle title="Minha Organização" subtitle="Contexto empresarial ativo (Tenant)" />
                <div className="mt-4 p-4 bg-indigo-50 border border-indigo-100 rounded-xl flex items-start gap-4">
                    <div className="bg-indigo-100 p-3 rounded-full text-indigo-600 shrink-0">
                        <Building2 size={24} />
                    </div>
                    <div>
                        <h4 className="text-lg font-bold text-indigo-900">{currentOrganization?.name || 'Organização Desconhecida'}</h4>
                        <p className="text-xs text-indigo-700 mt-1 mb-2">ID: {currentOrganization?.id}</p>
                        <span className="text-xs bg-white px-2 py-1 rounded border border-indigo-200 text-indigo-600 font-bold uppercase tracking-wider">
                            Plano {currentOrganization?.plan}
                        </span>
                        <span className={`text-xs ml-2 px-2 py-1 rounded border font-bold uppercase tracking-wider
                            ${currentOrganization?.subscription_status === 'active' ? 'bg-green-100 text-green-700 border-green-200' : 'bg-red-100 text-red-700 border-red-200'}
                        `}>
                            {currentOrganization?.subscription_status || 'Trial'}
                        </span>
                    </div>
                </div>

                {/* Seletor de Org apenas para Super Admin para testes ou gestão */}
                {isSuperAdmin && (
                    <div className="mt-6">
                        <p className="text-xs text-slate-500 uppercase font-bold mb-3">Debug: Trocar de Contexto (Simulação Local)</p>
                        <div className="space-y-2">
                            {MOCK_ORGANIZATIONS.map(org => (
                                <button 
                                    key={org.id}
                                    onClick={() => switchOrganization(org.id)}
                                    disabled={currentOrganization?.id === org.id}
                                    className={`w-full flex items-center justify-between p-3 rounded-lg border text-sm transition
                                        ${currentOrganization?.id === org.id 
                                            ? 'bg-slate-100 border-slate-200 text-slate-400 cursor-default' 
                                            : 'bg-white border-slate-200 hover:border-blue-300 hover:bg-blue-50 text-slate-700'}
                                    `}
                                >
                                    <span className="font-medium">{org.name}</span>
                                    {currentOrganization?.id === org.id && <CheckCircle size={16} className="text-green-500"/>}
                                </button>
                            ))}
                        </div>
                    </div>
                )}
            </div>
          </div>
      )}

       {/* --- ABA INTEGRAÇÕES --- */}
      {activeTab === 'integrations' && (
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 flex flex-col flex-1 overflow-hidden animate-fade-in">
              <div className="p-6 border-b border-slate-200 bg-slate-50 flex justify-between items-center">
                  <div><h3 className="font-bold text-slate-700 flex items-center gap-2"><Database size={20} className="text-emerald-600"/> Integração com Supabase</h3><p className="text-sm text-slate-500 mt-1">Configure a conexão com seu banco de dados na nuvem.</p></div>
                  <span className={`text-xs font-bold px-3 py-1 rounded-full border ${connectionStatus === 'success' ? 'bg-green-50 text-green-700 border-green-200' : 'bg-slate-100 text-slate-500 border-slate-200'}`}>{connectionStatus === 'success' ? 'Conectado' : 'Desconectado'}</span>
              </div>
              <div className="p-8 max-w-6xl mx-auto w-full grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div className="space-y-6">
                      <form onSubmit={handleSaveSupabase} className="space-y-4">
                          <div><label className="block text-sm font-bold text-slate-700 mb-1">Supabase URL</label><input type="text" value={supabaseForm.url} onChange={e => setSupabaseForm({...supabaseForm, url: e.target.value})} className="w-full border border-slate-300 rounded-lg p-3 outline-none" placeholder="https://xyz.supabase.co"/></div>
                          <div><label className="block text-sm font-bold text-slate-700 mb-1">Supabase Anon Key</label><input type="password" value={supabaseForm.key} onChange={e => setSupabaseForm({...supabaseForm, key: e.target.value})} className="w-full border border-slate-300 rounded-lg p-3 outline-none" placeholder="eyJ..."/></div>
                          {statusMessage && <div className={`p-3 rounded-lg text-sm ${connectionStatus === 'success' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>{statusMessage}</div>}
                          <button type="submit" disabled={connectionStatus === 'testing'} className="px-6 py-3 bg-emerald-600 text-white font-bold rounded-lg hover:bg-emerald-700 transition w-full">{connectionStatus === 'testing' ? 'Conectando...' : 'Salvar e Conectar'}</button>
                      </form>
                      
                      <div className="grid grid-cols-2 gap-3">
                          <button onClick={testClientWrite} className="w-full py-2 border border-dashed border-slate-300 text-slate-500 text-xs hover:border-slate-400 hover:text-slate-700 transition rounded">Testar Escrita</button>
                          <button onClick={() => setShowSqlModal(true)} className="w-full py-2 bg-slate-900 text-white text-xs font-bold rounded hover:bg-slate-800 transition flex items-center justify-center gap-2"><Code size={14}/> Ver Schema SaaS (Multi-Tenant)</button>
                      </div>
                  </div>
                  
                  <div className="space-y-6">
                      {/* Diagnóstico */}
                      <div className="bg-slate-50 rounded-xl border border-slate-200 p-6 flex flex-col">
                          <div className="flex items-center gap-2 mb-4 border-b border-slate-200 pb-4"><BarChart2 className="text-slate-400"/><div><h3 className="font-bold text-slate-800">Diagnóstico</h3></div></div>
                          {!diagnosticData ? (
                              <div className="flex-1 flex flex-col items-center justify-center py-8 text-center text-slate-500 text-sm">
                                  <p className="mb-4">Compare os dados locais com a nuvem.</p>
                                  <button onClick={runDiagnostic} className="px-4 py-2 bg-white border border-slate-300 rounded-lg font-bold hover:bg-blue-50">Rodar Diagnóstico</button>
                              </div>
                          ) : (
                              <div className="flex-1 overflow-auto">
                                  <table className="w-full text-sm">
                                      <thead>
                                          <tr className="text-slate-400 text-xs uppercase text-left">
                                              <th>Entidade</th><th>Local</th><th>Nuvem</th><th>Status</th>
                                          </tr>
                                      </thead>
                                      <tbody>
                                          {diagnosticData.map(d => (
                                              <tr key={d.name} className="border-b last:border-0 border-slate-200">
                                                  <td className="py-2 font-medium">{d.label}</td>
                                                  <td className="py-2">{d.local}</td>
                                                  <td className="py-2 text-blue-600 font-bold">{d.cloud}</td>
                                                  <td className="py-2 flex gap-2 items-center">
                                                      {d.status === 'error' ? <span className="text-red-500 text-xs">Erro</span> : 
                                                      d.status === 'synced' ? <span className="text-green-500 text-xs flex items-center gap-1"><CheckCircle size={10}/> OK</span> : 
                                                      <span className="text-amber-500 text-xs font-bold">Dif</span>}
                                                      
                                                      {(d.status === 'diff' || d.status === 'error') && !d.status.includes('não existe') && (
                                                          <button 
                                                                onClick={() => { syncLocalToCloud(d.name); setTimeout(runDiagnostic, 1000); }} 
                                                                disabled={isSyncing}
                                                                className="text-blue-600 hover:bg-blue-100 p-1 rounded transition"
                                                                title={`Sincronizar ${d.label}`}
                                                          >
                                                                <Cloud size={14} />
                                                          </button>
                                                      )}
                                                  </td>
                                              </tr>
                                          ))}
                                      </tbody>
                                  </table>
                                  
                                  {hasSchemaErrors && (
                                      <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-xs flex flex-col sm:flex-row items-center justify-between gap-3 animate-pulse">
                                          <div className="flex items-center gap-2">
                                              <AlertCircle size={16} className="shrink-0" />
                                              <span><strong>Atenção:</strong> Tabelas não encontradas no banco.</span>
                                          </div>
                                          <button 
                                              onClick={() => setShowSqlModal(true)} 
                                              className="w-full sm:w-auto px-4 py-2 bg-red-600 text-white font-bold rounded hover:bg-red-700 transition flex items-center justify-center gap-2"
                                          >
                                              <Wrench size={14}/> Configurar DB
                                          </button>
                                      </div>
                                  )}

                                  <div className="mt-4 pt-4 border-t border-slate-200">
                                      <p className="text-xs text-slate-500 mb-2 text-center">Para salvar todos os dados locais no banco:</p>
                                      <button onClick={() => syncLocalToCloud()} disabled={isSyncing || hasSchemaErrors} className="w-full py-2 bg-blue-600 text-white font-bold rounded text-xs hover:bg-blue-700 transition flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed">
                                          {isSyncing ? <RefreshCw className="animate-spin" size={14}/> : <UploadCloud size={14}/>} 
                                          {isSyncing ? 'Sincronizando...' : 'Enviar Tudo para Nuvem'}
                                      </button>
                                  </div>
                              </div>
                          )}
                      </div>

                      {/* ZONA DE PERIGO (LIMPEZA DE DADOS) */}
                      {/* Protegida: Apenas Super Admin vê a limpeza de banco */}
                      {isSuperAdmin && (
                          <div className="bg-white rounded-xl border border-red-200 p-6 flex flex-col shadow-sm">
                              <div className="flex items-center gap-2 mb-4 border-b border-red-100 pb-4">
                                  <AlertTriangle className="text-red-500"/>
                                  <div>
                                      <h3 className="font-bold text-red-700">Zona de Perigo</h3>
                                      <p className="text-xs text-red-500">Ações irreversíveis. Tenha cuidado.</p>
                                  </div>
                              </div>
                              
                              <div className="space-y-4">
                                  <div className="bg-red-50 p-3 rounded-lg border border-red-100">
                                      <p className="text-xs text-red-800 font-medium mb-2">Limpeza de Banco de Dados (Cloud)</p>
                                      <div className="grid grid-cols-2 gap-2">
                                          <button onClick={() => handleClearTable('clients', 'Clientes')} className="px-3 py-2 border border-red-200 text-red-600 rounded text-xs font-bold hover:bg-white transition">Limpar Clientes</button>
                                          <button onClick={() => handleClearTable('leads', 'Leads')} className="px-3 py-2 border border-red-200 text-red-600 rounded text-xs font-bold hover:bg-white transition">Limpar Leads</button>
                                          <button onClick={() => handleClearTable('invoices', 'Faturas')} className="px-3 py-2 border border-red-200 text-red-600 rounded text-xs font-bold hover:bg-white transition">Limpar Financeiro</button>
                                          <button onClick={() => handleClearTable('tickets', 'Tickets')} className="px-3 py-2 border border-red-200 text-red-600 rounded text-xs font-bold hover:bg-white transition">Limpar Tickets</button>
                                      </div>
                                  </div>

                                  <div className="bg-orange-50 p-3 rounded-lg border border-orange-100">
                                      <p className="text-xs text-orange-800 font-medium mb-2">Limpeza Local (Cache do Navegador)</p>
                                      <p className="text-[10px] text-orange-600 mb-2">Use isso se você vê dados antigos mesmo após limpar o banco.</p>
                                      <button onClick={handleLocalHardReset} className="w-full px-3 py-2 bg-orange-100 border border-orange-200 text-orange-700 rounded text-xs font-bold hover:bg-orange-200 transition flex items-center justify-center gap-2">
                                          <Trash size={14}/> Resetar Cache Local
                                      </button>
                                  </div>
                              </div>
                          </div>
                      )}
                  </div>
              </div>
          </div>
      )}

      {/* --- SQL SCHEMA MODAL --- */}
      {showSqlModal && (
          <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-[60] p-4 backdrop-blur-sm animate-fade-in">
              <div className="bg-white rounded-xl shadow-2xl w-full max-w-3xl flex flex-col h-[80vh] overflow-hidden">
                  <div className="p-4 border-b border-slate-200 flex justify-between items-center bg-slate-50">
                      <div>
                          <h3 className="font-bold text-slate-800 flex items-center gap-2"><Database size={18}/> Setup Banco de Dados (SaaS)</h3>
                          <p className="text-xs text-slate-500">Copie este código e execute no Editor SQL do Supabase para ativar o Multi-Tenancy.</p>
                      </div>
                      <button onClick={() => setShowSqlModal(false)} className="p-2 hover:bg-slate-200 rounded-full"><X size={20}/></button>
                  </div>
                  <div className="flex-1 bg-slate-900 overflow-auto p-4 custom-scrollbar">
                      <pre className="text-green-400 font-mono text-xs md:text-sm whitespace-pre-wrap select-all">
                          {generateSchemaSQL()}
                      </pre>
                  </div>
                  <div className="p-4 border-t border-slate-200 flex justify-end gap-3 bg-slate-50">
                      <button onClick={() => { navigator.clipboard.writeText(generateSchemaSQL()); alert("SQL Copiado!"); }} className="px-4 py-2 bg-blue-600 text-white font-bold rounded hover:bg-blue-700 flex items-center gap-2">
                          <Copy size={16}/> Copiar SQL
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* --- ABA PERMISSIONS --- */}
      {activeTab === 'permissions' && (
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 flex flex-col flex-1 overflow-hidden animate-fade-in">
              <div className="p-4 md:p-6 border-b border-slate-200 bg-slate-50 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                   <div>
                      <h3 className="font-bold text-slate-700 flex items-center gap-2">
                          <Shield size={20} className="text-blue-600"/> Controle de Acesso (RBAC)
                      </h3>
                      <p className="text-sm text-slate-500 mt-1">Gerencie as permissões de cada perfil de usuário.</p>
                   </div>
                   <div className="flex gap-4 text-xs text-slate-500 flex-wrap">
                       <span className="flex items-center gap-1"><CheckCircle size={12} className="text-blue-600"/> Permitido</span>
                       <span className="flex items-center gap-1"><X size={12} className="text-slate-300"/> Bloqueado</span>
                   </div>
              </div>

              <div className="p-4 md:p-6 flex flex-col h-full overflow-hidden">
                  {/* Role Tabs - Scrollable on mobile */}
                  <div className="flex space-x-1 bg-slate-100 p-1 rounded-lg mb-6 w-full overflow-x-auto custom-scrollbar pb-2 md:pb-1">
                      {['admin', 'executive', 'sales', 'support', 'dev', 'finance'].map((role) => (
                          <button
                              key={role}
                              onClick={() => setSelectedRoleForPerms(role as Role)}
                              className={`px-4 py-2 rounded-md text-sm font-bold capitalize transition-all whitespace-nowrap
                                  ${selectedRoleForPerms === role 
                                      ? 'bg-white text-blue-600 shadow-sm' 
                                      : 'text-slate-500 hover:text-slate-700'
                                  }`}
                          >
                              {role}
                          </button>
                      ))}
                  </div>

                  {/* Matrix Table - Responsive */}
                  <div className="border border-slate-200 rounded-xl overflow-auto flex-1 custom-scrollbar relative">
                      <table className="w-full text-left text-sm min-w-[600px]">
                          <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-xs sticky top-0 z-10 shadow-sm">
                              <tr>
                                  <th className="p-4 bg-slate-50">Módulo</th>
                                  <th className="p-4 text-center bg-slate-50">Visualizar</th>
                                  <th className="p-4 text-center bg-slate-50">Criar</th>
                                  <th className="p-4 text-center bg-slate-50">Editar</th>
                                  <th className="p-4 text-center bg-slate-50">Excluir</th>
                              </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100">
                              {[
                                  { id: 'dashboard', label: 'Dashboard / Visão Geral' },
                                  { id: 'calendar', label: 'Agenda / Calendário' },
                                  { id: 'commercial', label: 'Comercial (CRM)' },
                                  { id: 'clients', label: 'Carteira de Clientes' },
                                  { id: 'proposals', label: 'Propostas Comerciais' },
                                  { id: 'customer-success', label: 'Sucesso do Cliente (CS)' },
                                  { id: 'retention', label: 'Retenção & Churn' },
                                  { id: 'finance', label: 'Financeiro' },
                                  { id: 'support', label: 'Suporte & Tickets' },
                                  { id: 'dev', label: 'Desenvolvimento (Tech)' },
                                  { id: 'reports', label: 'Relatórios & BI' },
                                  { id: 'settings', label: 'Configurações' },
                              ].map((module) => (
                                  <tr key={module.id} className="hover:bg-slate-50 transition-colors">
                                      <td className="p-4 font-medium text-slate-800 border-r border-slate-50">
                                          {module.label}
                                      </td>
                                      {['view', 'create', 'edit', 'delete'].map((action) => {
                                          const isChecked = permissionMatrix[selectedRoleForPerms]?.[module.id]?.[action as any] || false;
                                          const isLocked = selectedRoleForPerms === 'admin';
                                          
                                          return (
                                              <td key={action} className="p-4 text-center">
                                                  <label className={`relative inline-flex items-center cursor-pointer ${isLocked ? 'opacity-50 cursor-not-allowed' : ''}`}>
                                                      <input 
                                                          type="checkbox" 
                                                          className="sr-only peer"
                                                          checked={isChecked}
                                                          disabled={isLocked}
                                                          onChange={(e) => updatePermission(selectedRoleForPerms, module.id, action as any, e.target.checked)}
                                                      />
                                                      <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                                                  </label>
                                              </td>
                                          );
                                      })}
                                  </tr>
                              ))}
                          </tbody>
                      </table>
                  </div>
                  
                  {selectedRoleForPerms === 'admin' && (
                      <div className="mt-4 p-4 bg-amber-50 border border-amber-100 rounded-lg flex items-start gap-3 animate-fade-in">
                          <ShieldCheck size={20} className="text-amber-600 mt-0.5"/>
                          <div>
                              <h4 className="text-sm font-bold text-amber-800">Perfil de Super Administrador</h4>
                              <p className="text-xs text-amber-700 mt-1">
                                  Para garantir a integridade do sistema, as permissões do grupo <strong>Admin</strong> são imutáveis. 
                                  Este perfil sempre terá acesso total a todos os módulos e funcionalidades.
                              </p>
                          </div>
                      </div>
                  )}
              </div>
          </div>
      )}

      {/* --- ABA AUDIT --- */}
      {activeTab === 'audit' && (
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 flex flex-col flex-1 overflow-hidden"><div className="p-4 border-b border-slate-200 bg-slate-50"><h3 className="font-bold text-slate-700">Logs</h3></div><div className="overflow-auto flex-1 p-4"><table className="w-full text-left text-sm"><thead><tr><th>Data</th><th>Usuário</th><th>Ação</th></tr></thead><tbody>{filteredLogs.map(l => (<tr key={l.id} className="border-b"><td className="p-3">{new Date(l.timestamp).toLocaleString()}</td><td className="p-3">{l.userName}</td><td className="p-3">{l.action}</td></tr>))}</tbody></table></div></div>
      )}
    </div>
  );
};
