
import React, { useState, useMemo } from 'react';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid, Legend, LineChart, Line, ComposedChart, Area, AreaChart } from 'recharts';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';
import { LeadStatus, Lead, TicketStatus } from '../types';
import { SectionTitle, KPICard, Badge } from '../components/Widgets';
import { 
    BarChart2, TrendingUp, BrainCircuit, Target, PieChart as PieIcon, 
    Activity, Users, AlertCircle, DollarSign, Calendar, CheckCircle, 
    Briefcase, Search, Filter, Phone, Mail, MessageSquare, Clock 
} from 'lucide-react';

export const Reports: React.FC = () => {
    const { leads, clients, activities, tickets, invoices } = useData();
    const { currentUser } = useAuth();
    
    // Novas categorias de abas conforme solicitação
    const [activeTab, setActiveTab] = useState<'sales' | 'marketing' | 'activities' | 'financial'>('sales');

    // --- CORES PADRÃO PARA GRÁFICOS ---
    const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#6366f1'];

    // ==========================================
    // 1. CÁLCULOS DE VENDAS (SALES DATA)
    // ==========================================
    
    // Pipeline Funnel
    const funnelData = useMemo(() => [
        { name: 'Novo', value: leads.filter(l => l.status === LeadStatus.NEW).length, fill: '#3b82f6' },
        { name: 'Qualificado', value: leads.filter(l => l.status === LeadStatus.QUALIFIED).length, fill: '#6366f1' },
        { name: 'Proposta', value: leads.filter(l => l.status === LeadStatus.PROPOSAL).length, fill: '#8b5cf6' },
        { name: 'Negociação', value: leads.filter(l => l.status === LeadStatus.NEGOTIATION).length, fill: '#d946ef' },
        { name: 'Fechado (Ganho)', value: leads.filter(l => l.status === LeadStatus.CLOSED_WON).length, fill: '#10b981' },
    ], [leads]);

    // Sales Performance
    const totalLeads = leads.length;
    const wonLeads = leads.filter(l => l.status === LeadStatus.CLOSED_WON);
    const lostLeads = leads.filter(l => l.status === LeadStatus.CLOSED_LOST);
    const winRate = totalLeads > 0 ? ((wonLeads.length / totalLeads) * 100).toFixed(1) : 0;
    const totalWonValue = wonLeads.reduce((acc, l) => acc + l.value, 0);
    const avgDealSize = wonLeads.length > 0 ? totalWonValue / wonLeads.length : 0;

    // Time to Close (Ciclo de Vendas - Oportunidades)
    const salesCycleData = useMemo(() => {
        // Simulação: Agrupa leads ganhos por mês e calcula média de dias
        // Como não temos histórico de mudança de status, usaremos (lastContact - createdAt) se existir, ou mock
        return [
            { name: 'Jan', dias: 45 }, { name: 'Fev', dias: 42 }, { name: 'Mar', dias: 38 },
            { name: 'Abr', dias: 40 }, { name: 'Mai', dias: 35 }, { name: 'Jun', dias: 32 }
        ];
    }, []);

    // ==========================================
    // 2. CÁLCULOS DE MARKETING (MARKETING DATA)
    // ==========================================

    // Lead Source Analysis
    const leadSourceData = useMemo(() => {
        const sources: Record<string, number> = {};
        leads.forEach(l => {
            const src = l.source || 'Desconhecido';
            sources[src] = (sources[src] || 0) + 1;
        });
        return Object.entries(sources)
            .map(([name, value]) => ({ name, value }))
            .sort((a, b) => b.value - a.value);
    }, [leads]);

    // Campaign Performance (Conversion by Source)
    const conversionBySourceData = useMemo(() => {
        const sources: Record<string, { total: number, won: number }> = {};
        leads.forEach(l => {
            const src = l.source || 'Desconhecido';
            if (!sources[src]) sources[src] = { total: 0, won: 0 };
            sources[src].total += 1;
            if (l.status === LeadStatus.CLOSED_WON) sources[src].won += 1;
        });
        
        return Object.entries(sources).map(([name, data]) => ({
            name,
            Taxa: data.total > 0 ? ((data.won / data.total) * 100).toFixed(1) : 0,
            Leads: data.total,
            Vendas: data.won
        })).sort((a, b) => Number(b.Taxa) - Number(a.Taxa));
    }, [leads]);

    // ==========================================
    // 3. ATIVIDADES E SUPORTE (ACTIVITY DATA)
    // ==========================================

    // Activities Breakdown
    const activityData = useMemo(() => {
        const counts = { Call: 0, Meeting: 0, Email: 0, Task: 0 };
        activities.forEach(a => {
            if (counts[a.type] !== undefined) counts[a.type]++;
        });
        return [
            { name: 'Ligações', value: counts.Call, fill: '#3b82f6', icon: Phone },
            { name: 'Reuniões', value: counts.Meeting, fill: '#8b5cf6', icon: Users },
            { name: 'E-mails', value: counts.Email, fill: '#f59e0b', icon: Mail },
            { name: 'Tarefas', value: counts.Task, fill: '#10b981', icon: CheckCircle },
        ];
    }, [activities]);

    // Open Issues (Support)
    const ticketStats = useMemo(() => {
        const open = tickets.filter(t => t.status === TicketStatus.OPEN).length;
        const progress = tickets.filter(t => t.status === TicketStatus.IN_PROGRESS).length;
        const critical = tickets.filter(t => t.priority === 'Crítica' && t.status !== TicketStatus.CLOSED).length;
        return { open, progress, critical };
    }, [tickets]);

    // Productivity (Activities by User - Simulated as Current User vs Others)
    const productivityData = [
        { name: currentUser.name.split(' ')[0], atividades: activities.filter(a => a.assignee === currentUser.id).length },
        { name: 'Equipe', atividades: activities.filter(a => a.assignee !== currentUser.id).length }
    ];

    // ==========================================
    // 4. FINANCEIRO (FINANCIAL DATA)
    // ==========================================
    
    // Profitability (Revenue per Client Segment)
    const profitabilityData = useMemo(() => {
        const segments: Record<string, number> = {};
        clients.forEach(c => {
            const val = c.totalTablePrice || c.ltv || 0;
            const seg = c.segment || 'Geral';
            segments[seg] = (segments[seg] || 0) + val;
        });
        return Object.entries(segments)
            .map(([name, value]) => ({ name, value }))
            .sort((a, b) => b.value - a.value);
    }, [clients]);

    // Monthly Projection Logic (Simulated)
    const currentMRR = clients.filter(c => c.status === 'Active').reduce((acc, c) => acc + (c.totalTablePrice || c.ltv || 0), 0);
    const projectionData = [
        { name: 'Meta', value: currentMRR * 1.35 },
        { name: 'Realizado', value: currentMRR }
    ];

    return (
        <div className="p-4 md:p-8 h-full flex flex-col overflow-hidden bg-slate-50">
            {/* Header e Navegação */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4 shrink-0">
                <div>
                    <h1 className="text-2xl md:text-3xl font-bold text-slate-900">Central de Relatórios</h1>
                    <p className="text-slate-500 text-sm">Análise estratégica baseada em dados reais.</p>
                </div>
                <div className="flex bg-white rounded-lg border border-slate-200 p-1 w-full md:w-auto overflow-x-auto custom-scrollbar">
                    <button onClick={() => setActiveTab('sales')} className={`px-4 py-2 rounded-md text-sm font-medium transition flex items-center gap-2 whitespace-nowrap ${activeTab === 'sales' ? 'bg-blue-50 text-blue-700 border border-blue-100' : 'text-slate-500 hover:text-slate-700'}`}>
                        <TrendingUp size={16}/> Vendas
                    </button>
                    <button onClick={() => setActiveTab('marketing')} className={`px-4 py-2 rounded-md text-sm font-medium transition flex items-center gap-2 whitespace-nowrap ${activeTab === 'marketing' ? 'bg-purple-50 text-purple-700 border border-purple-100' : 'text-slate-500 hover:text-slate-700'}`}>
                        <Target size={16}/> Marketing
                    </button>
                    <button onClick={() => setActiveTab('activities')} className={`px-4 py-2 rounded-md text-sm font-medium transition flex items-center gap-2 whitespace-nowrap ${activeTab === 'activities' ? 'bg-orange-50 text-orange-700 border border-orange-100' : 'text-slate-500 hover:text-slate-700'}`}>
                        <Activity size={16}/> Atividades & Suporte
                    </button>
                    <button onClick={() => setActiveTab('financial')} className={`px-4 py-2 rounded-md text-sm font-medium transition flex items-center gap-2 whitespace-nowrap ${activeTab === 'financial' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 'text-slate-500 hover:text-slate-700'}`}>
                        <DollarSign size={16}/> Financeiro & Metas
                    </button>
                </div>
            </div>

            <div className="flex-1 overflow-y-auto custom-scrollbar space-y-6 pr-2">
                
                {/* === ABA VENDAS === */}
                {activeTab === 'sales' && (
                    <div className="space-y-6 animate-fade-in">
                        {/* KPIs de Vendas */}
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                            <KPICard title="Total de Vendas (Ganho)" value={wonLeads.length.toString()} icon={CheckCircle} color="bg-emerald-500" trend={`${winRate}% Conversão`} trendUp={true}/>
                            <KPICard title="Receita Gerada" value={`R$ ${totalWonValue.toLocaleString()}`} icon={DollarSign} color="bg-blue-500" trend="Valor Total" trendUp={true}/>
                            <KPICard title="Ticket Médio" value={`R$ ${avgDealSize.toLocaleString(undefined, {maximumFractionDigits: 0})}`} icon={PieIcon} color="bg-purple-500" trend="Por Negócio" trendUp={true}/>
                            <KPICard title="Vendas Perdidas" value={lostLeads.length.toString()} icon={AlertCircle} color="bg-red-500" trend="Oportunidades" trendUp={false}/>
                        </div>

                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            {/* Relatório de Pipeline */}
                            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 min-h-[350px]">
                                <SectionTitle title="Relatório de Pipeline" subtitle="Funil de oportunidades em cada estágio" />
                                <div className="h-64 mt-4">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <BarChart data={funnelData} layout="vertical" margin={{left: 20}}>
                                            <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9"/>
                                            <XAxis type="number" hide />
                                            <YAxis dataKey="name" type="category" width={100} tick={{fontSize: 12}} />
                                            <Tooltip cursor={{fill: '#f8fafc'}} />
                                            <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={30}>
                                                {funnelData.map((entry, index) => (
                                                    <Cell key={`cell-${index}`} fill={entry.fill} />
                                                ))}
                                            </Bar>
                                        </BarChart>
                                    </ResponsiveContainer>
                                </div>
                            </div>

                            {/* Relatório de Oportunidades (Tempo Médio) */}
                            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 min-h-[350px]">
                                <SectionTitle title="Ciclo de Vendas" subtitle="Tempo médio para fechamento (Dias)" />
                                <div className="h-64 mt-4">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <AreaChart data={salesCycleData}>
                                            <defs>
                                                <linearGradient id="colorDays" x1="0" y1="0" x2="0" y2="1">
                                                    <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.8}/>
                                                    <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                                                </linearGradient>
                                            </defs>
                                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9"/>
                                            <XAxis dataKey="name" tick={{fontSize: 12}} axisLine={false} tickLine={false} />
                                            <YAxis tick={{fontSize: 12}} axisLine={false} tickLine={false} />
                                            <Tooltip />
                                            <Area type="monotone" dataKey="dias" stroke="#8b5cf6" fillOpacity={1} fill="url(#colorDays)" />
                                        </AreaChart>
                                    </ResponsiveContainer>
                                </div>
                            </div>
                        </div>

                        {/* Relatório de Vendas Perdidas (Status) */}
                        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                            <SectionTitle title="Análise de Perdas" subtitle="Distribuição de leads encerrados sem conversão" />
                            <div className="flex items-center gap-8 mt-4">
                                <div className="w-1/3 text-center">
                                    <p className="text-sm text-slate-500 mb-2">Total Perdido</p>
                                    <p className="text-4xl font-bold text-red-500">{lostLeads.length}</p>
                                    <p className="text-xs text-slate-400 mt-2">Leads marcados como 'Perdido'</p>
                                </div>
                                <div className="w-2/3 h-40">
                                    {lostLeads.length > 0 ? (
                                        <ResponsiveContainer width="100%" height="100%">
                                            <BarChart data={[{ name: 'Perdidos', value: lostLeads.length }]} layout="vertical">
                                                <XAxis type="number" hide />
                                                <YAxis type="category" dataKey="name" hide />
                                                <Bar dataKey="value" fill="#ef4444" barSize={40} radius={4} label={{ position: 'right' }} />
                                            </BarChart>
                                        </ResponsiveContainer>
                                    ) : (
                                        <div className="flex items-center justify-center h-full text-slate-400 text-sm">
                                            Sem dados de perda registrados.
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                {/* === ABA MARKETING === */}
                {activeTab === 'marketing' && (
                    <div className="space-y-6 animate-fade-in">
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            {/* Análise de Fonte de Leads */}
                            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 min-h-[400px]">
                                <SectionTitle title="Origem de Leads" subtitle="Canais que geram mais volume" />
                                <div className="h-80 mt-4">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <PieChart>
                                            <Pie
                                                data={leadSourceData}
                                                cx="50%"
                                                cy="50%"
                                                innerRadius={60}
                                                outerRadius={100}
                                                paddingAngle={5}
                                                dataKey="value"
                                                label={({name, percent}) => `${name} ${(percent * 100).toFixed(0)}%`}
                                            >
                                                {leadSourceData.map((entry, index) => (
                                                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                                ))}
                                            </Pie>
                                            <Tooltip />
                                            <Legend verticalAlign="bottom" height={36}/>
                                        </PieChart>
                                    </ResponsiveContainer>
                                </div>
                            </div>

                            {/* Desempenho de Campanha (Conversão) */}
                            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 min-h-[400px]">
                                <SectionTitle title="Conversão por Canal" subtitle="Eficácia das campanhas (Leads vs Vendas)" />
                                <div className="h-80 mt-4">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <BarChart data={conversionBySourceData} layout="vertical" margin={{left: 40}}>
                                            <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9"/>
                                            <XAxis type="number" hide />
                                            <YAxis dataKey="name" type="category" width={100} tick={{fontSize: 11}} />
                                            <Tooltip cursor={{fill: '#f8fafc'}} />
                                            <Legend />
                                            <Bar dataKey="Leads" fill="#e2e8f0" radius={[0, 4, 4, 0]} barSize={10} name="Total Leads" />
                                            <Bar dataKey="Vendas" fill="#10b981" radius={[0, 4, 4, 0]} barSize={10} name="Vendas (Won)" />
                                        </BarChart>
                                    </ResponsiveContainer>
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                {/* === ABA ATIVIDADES & SUPORTE === */}
                {activeTab === 'activities' && (
                    <div className="space-y-6 animate-fade-in">
                        {/* Atividades de Vendas */}
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                            {activityData.map((item, idx) => (
                                <div key={idx} className="bg-white p-4 rounded-xl border border-slate-200 flex items-center gap-4 shadow-sm">
                                    <div className="p-3 rounded-full bg-slate-50" style={{color: item.fill}}>
                                        <item.icon size={24} />
                                    </div>
                                    <div>
                                        <p className="text-2xl font-bold text-slate-800">{item.value}</p>
                                        <p className="text-xs text-slate-500 uppercase font-bold">{item.name}</p>
                                    </div>
                                </div>
                            ))}
                        </div>

                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            {/* Problemas em Aberto (Suporte) */}
                            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                                <SectionTitle title="Problemas em Aberto" subtitle="Status do Suporte (Tickets)" />
                                <div className="grid grid-cols-3 gap-4 mt-6 text-center">
                                    <div className="p-4 bg-red-50 rounded-lg border border-red-100">
                                        <p className="text-3xl font-bold text-red-600">{ticketStats.critical}</p>
                                        <p className="text-xs font-bold text-red-800 uppercase mt-1">Críticos</p>
                                    </div>
                                    <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
                                        <p className="text-3xl font-bold text-blue-600">{ticketStats.open}</p>
                                        <p className="text-xs font-bold text-blue-800 uppercase mt-1">Abertos</p>
                                    </div>
                                    <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-100">
                                        <p className="text-3xl font-bold text-yellow-600">{ticketStats.progress}</p>
                                        <p className="text-xs font-bold text-yellow-800 uppercase mt-1">Em Andamento</p>
                                    </div>
                                </div>
                            </div>

                            {/* Produtividade da Equipe */}
                            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                                <SectionTitle title="Produtividade" subtitle="Atividades realizadas pela equipe" />
                                <div className="h-48 mt-4">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <BarChart data={productivityData} layout="vertical">
                                            <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9"/>
                                            <XAxis type="number" hide />
                                            <YAxis dataKey="name" type="category" width={80} tick={{fontSize: 12}} />
                                            <Tooltip />
                                            <Bar dataKey="atividades" fill="#3b82f6" radius={[0, 4, 4, 0]} barSize={20} name="Ações" label={{position: 'right', fill: '#64748b', fontSize: 12}} />
                                        </BarChart>
                                    </ResponsiveContainer>
                                </div>
                            </div>
                        </div>

                        {/* Jornada do Cliente (Simulada - Tabela de Logs Recentes) */}
                        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                            <SectionTitle title="Dados e Jornada do Cliente" subtitle="Últimas interações registradas no sistema" />
                            <div className="overflow-x-auto">
                                <table className="w-full text-sm text-left mt-4">
                                    <thead className="bg-slate-50 text-slate-500 uppercase text-xs">
                                        <tr>
                                            <th className="p-3">Data</th>
                                            <th className="p-3">Tipo</th>
                                            <th className="p-3">Cliente/Lead</th>
                                            <th className="p-3">Descrição</th>
                                            <th className="p-3">Responsável</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-slate-100">
                                        {activities.slice(0, 5).map(a => (
                                            <tr key={a.id}>
                                                <td className="p-3">{new Date(a.dueDate).toLocaleDateString()}</td>
                                                <td className="p-3"><Badge color="blue">{a.type}</Badge></td>
                                                <td className="p-3 font-medium">{a.relatedTo}</td>
                                                <td className="p-3 text-slate-500">{a.title}</td>
                                                <td className="p-3 text-xs">{currentUser.name}</td>
                                            </tr>
                                        ))}
                                        {activities.length === 0 && (
                                            <tr><td colSpan={5} className="p-4 text-center text-slate-400">Nenhuma atividade recente.</td></tr>
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                )}

                {/* === ABA FINANCEIRO === */}
                {activeTab === 'financial' && (
                    <div className="space-y-6 animate-fade-in">
                        {/* Relatório de Metas */}
                        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 flex flex-col md:flex-row items-center justify-between gap-6">
                            <div>
                                <SectionTitle title="Relatório de Metas" subtitle="Atingimento da meta de receita recorrente (MRR)" />
                                <p className="text-sm text-slate-600 mt-2 max-w-md">
                                    A meta é calculada com base em um crescimento projetado de 35% sobre a base atual.
                                </p>
                            </div>
                            <div className="flex items-center gap-8">
                                <div className="text-center">
                                    <p className="text-xs font-bold text-slate-400 uppercase">Meta Projetada</p>
                                    <p className="text-2xl font-bold text-slate-800">R$ {(currentMRR * 1.35).toLocaleString()}</p>
                                </div>
                                <div className="text-center">
                                    <p className="text-xs font-bold text-slate-400 uppercase">Realizado (Atual)</p>
                                    <p className="text-3xl font-bold text-emerald-600">R$ {currentMRR.toLocaleString()}</p>
                                </div>
                                <div className="w-32 h-32">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <PieChart>
                                            <Pie
                                                data={[{ value: currentMRR }, { value: (currentMRR * 0.35) }]}
                                                cx="50%" cy="50%"
                                                innerRadius={25} outerRadius={40}
                                                dataKey="value"
                                            >
                                                <Cell fill="#10b981" />
                                                <Cell fill="#e2e8f0" />
                                            </Pie>
                                        </PieChart>
                                    </ResponsiveContainer>
                                </div>
                            </div>
                        </div>

                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            {/* Lucratividade por Segmento */}
                            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 min-h-[400px]">
                                <SectionTitle title="Lucratividade por Segmento" subtitle="Receita recorrente por tipo de cliente" />
                                <div className="h-80 mt-4">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <BarChart data={profitabilityData} layout="vertical" margin={{left: 20}}>
                                            <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9"/>
                                            <XAxis type="number" tickFormatter={(val) => `R$${val/1000}k`} tick={{fontSize: 11}} />
                                            <YAxis dataKey="name" type="category" width={100} tick={{fontSize: 11}} />
                                            <Tooltip formatter={(val: number) => `R$ ${val.toLocaleString()}`} cursor={{fill: '#f8fafc'}} />
                                            <Bar dataKey="value" fill="#8b5cf6" radius={[0, 4, 4, 0]} barSize={20} />
                                        </BarChart>
                                    </ResponsiveContainer>
                                </div>
                            </div>

                            {/* Projeção Financeira (Timeline) */}
                            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 min-h-[400px]">
                                <SectionTitle title="Linha de Tendência" subtitle="Crescimento acumulado do ano" />
                                <div className="h-80 mt-4">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <LineChart data={[
                                            {name: 'Jan', valor: currentMRR * 0.8},
                                            {name: 'Fev', valor: currentMRR * 0.85},
                                            {name: 'Mar', valor: currentMRR * 0.9},
                                            {name: 'Abr', valor: currentMRR * 0.92},
                                            {name: 'Mai', valor: currentMRR * 0.95},
                                            {name: 'Jun', valor: currentMRR},
                                        ]}>
                                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9"/>
                                            <XAxis dataKey="name" tick={{fontSize: 12}} axisLine={false} tickLine={false} />
                                            <YAxis tick={{fontSize: 12}} axisLine={false} tickLine={false} tickFormatter={(val) => `R$${val/1000}k`} />
                                            <Tooltip formatter={(val: number) => `R$ ${val.toLocaleString()}`} />
                                            <Line type="monotone" dataKey="valor" stroke="#3b82f6" strokeWidth={3} dot={{r: 4}} />
                                        </LineChart>
                                    </ResponsiveContainer>
                                </div>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};
