import React, { useState } from 'react';
import { MOCK_TICKETS } from '../constants';
import { Badge } from '../components/Widgets';
import { Ticket, TicketPriority } from '../types';
import { analyzeTicket } from '../services/geminiService';
import { MessageSquare, AlertTriangle, CheckCircle, Clock } from 'lucide-react';

export const Support: React.FC = () => {
    const [analyzing, setAnalyzing] = useState<string | null>(null);
    const [analysisResult, setAnalysisResult] = useState<Record<string, any>>({});

    const handleAnalyze = async (ticket: Ticket) => {
        setAnalyzing(ticket.id);
        const resultJson = await analyzeTicket(ticket);
        try {
            const parsed = JSON.parse(resultJson);
            setAnalysisResult(prev => ({ ...prev, [ticket.id]: parsed }));
        } catch (e) {
            console.error("Failed to parse JSON", e);
        }
        setAnalyzing(null);
    };

    const getPriorityColor = (p: TicketPriority) => {
        switch(p) {
            case TicketPriority.CRITICAL: return 'red';
            case TicketPriority.HIGH: return 'yellow';
            default: return 'gray';
        }
    };

    return (
        <div className="p-8">
            <div className="flex justify-between items-center mb-8">
                <h1 className="text-3xl font-bold text-slate-900">Suporte & Helpdesk</h1>
                <div className="flex gap-2">
                    <span className="bg-white px-3 py-1 rounded-full border text-sm font-medium">Fila: 3</span>
                    <span className="bg-red-50 text-red-700 px-3 py-1 rounded-full border border-red-100 text-sm font-medium">Críticos: 1</span>
                </div>
            </div>

            <div className="space-y-4">
                {MOCK_TICKETS.map(ticket => (
                    <div key={ticket.id} className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                        <div className="p-6 flex flex-col md:flex-row gap-6">
                            {/* Status Icon */}
                            <div className="flex-shrink-0">
                                {ticket.priority === TicketPriority.CRITICAL ? (
                                    <div className="bg-red-100 p-3 rounded-full text-red-600"><AlertTriangle size={24} /></div>
                                ) : (
                                    <div className="bg-blue-100 p-3 rounded-full text-blue-600"><Clock size={24} /></div>
                                )}
                            </div>

                            {/* Content */}
                            <div className="flex-1">
                                <div className="flex justify-between items-start mb-2">
                                    <h3 className="text-lg font-bold text-slate-900">{ticket.subject} <span className="text-slate-400 font-normal ml-2">#{ticket.id}</span></h3>
                                    <Badge color={getPriorityColor(ticket.priority)}>{ticket.priority}</Badge>
                                </div>
                                <p className="text-slate-600 mb-3">{ticket.description}</p>
                                <div className="flex items-center gap-4 text-sm text-slate-500">
                                    <span className="flex items-center gap-1"><MessageSquare size={14}/> {ticket.channel}</span>
                                    <span>{ticket.customer}</span>
                                    <span>{new Date(ticket.created_at).toLocaleDateString()}</span>
                                </div>
                            </div>

                            {/* AI Action Area */}
                            <div className="md:w-72 bg-slate-50 rounded-lg p-4 border border-slate-100 flex flex-col justify-center">
                                {!analysisResult[ticket.id] ? (
                                    <button 
                                        onClick={() => handleAnalyze(ticket)}
                                        disabled={analyzing === ticket.id}
                                        className="w-full bg-white border border-indigo-200 text-indigo-700 hover:bg-indigo-50 font-medium py-2 px-4 rounded-lg transition flex items-center justify-center gap-2"
                                    >
                                        {analyzing === ticket.id ? <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-indigo-700"></div> : "✨ Analisar com IA"}
                                    </button>
                                ) : (
                                    <div className="text-sm space-y-2">
                                        <div className="flex items-center justify-between">
                                            <span className="font-bold text-slate-700">Resumo IA</span>
                                            <span className={`text-xs px-2 py-0.5 rounded-full ${analysisResult[ticket.id].sentiment === 'Negativo' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}>
                                                {analysisResult[ticket.id].sentiment}
                                            </span>
                                        </div>
                                        <p className="text-slate-600 text-xs italic">"{analysisResult[ticket.id].suggestedAction}"</p>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};