
import { Lead, Ticket, Issue, Invoice, LeadStatus, TicketPriority, TicketStatus, User, InvoiceStatus, Client, Activity, AuditLog, Proposal, Product, ClientDocument, Organization } from './types';

// Helper for dynamic dates
const daysAgo = (days: number) => {
    const date = new Date();
    date.setDate(date.getDate() - days);
    return date.toISOString();
};

// --- ORGANIZAÇÕES (SAAS MULTI-TENANT MOCK) ---
export const MOCK_ORGANIZATIONS: Organization[] = [
    { id: 'org-1', name: 'Minha Empresa', slug: 'minha-empresa', plan: 'Standard' },
];

// --- USUÁRIOS DO SISTEMA ---
// Mantidos apenas o admin padrão para fallback caso auth falhe, mas idealmente virá do Supabase
export const MOCK_USERS: User[] = [
  { id: 'u1', name: 'Admin', role: 'admin', avatar: 'AD', email: 'admin@nexus.com', organizationId: 'org-1' },
];

// --- DADOS DE NEGÓCIO (ZERADOS PARA PRODUÇÃO/SAAS) ---
// O sistema deve carregar do Supabase ou iniciar vazio.

export const MOCK_CLIENTS: Client[] = [];
export const MOCK_LEADS: Lead[] = [];
export const MOCK_TICKETS: Ticket[] = [];
export const MOCK_ISSUES: Issue[] = [];
export const MOCK_INVOICES: Invoice[] = [];
export const MOCK_ACTIVITIES: Activity[] = [];
export const MOCK_LOGS: AuditLog[] = [];
export const MOCK_PROPOSALS: Proposal[] = [];
export const MOCK_PRODUCTS: Product[] = [];
export const MOCK_DOCUMENTS: ClientDocument[] = [];

// --- DADOS PARA GRÁFICOS (INICIAIS ZERADOS) ---
export const REVENUE_DATA = [
  { name: 'Jan', mrr: 0, arr: 0 },
  { name: 'Fev', mrr: 0, arr: 0 },
  { name: 'Mar', mrr: 0, arr: 0 },
  { name: 'Abr', mrr: 0, arr: 0 },
  { name: 'Mai', mrr: 0, arr: 0 },
  { name: 'Jun', mrr: 0, arr: 0 },
];

export const PIPELINE_DATA = [
  { name: 'Novo', value: 0 },
  { name: 'Qualificado', value: 0 },
  { name: 'Proposta', value: 0 },
  { name: 'Negociação', value: 0 },
  { name: 'Fechado', value: 0 },
];
