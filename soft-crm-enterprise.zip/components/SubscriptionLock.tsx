
import React from 'react';
import { Lock, CreditCard, HelpCircle, LogOut } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface SubscriptionLockProps {
    status: string;
}

export const SubscriptionLock: React.FC<SubscriptionLockProps> = ({ status }) => {
    const { logout, currentOrganization } = useAuth();

    const getMessage = () => {
        switch (status) {
            case 'past_due': return 'O pagamento da sua última fatura falhou ou está atrasado.';
            case 'canceled': return 'Sua assinatura foi cancelada.';
            case 'inactive': return 'Esta conta está inativa.';
            default: return 'Acesso suspenso temporariamente.';
        }
    };

    return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-slate-900 p-4">
            <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden text-center">
                <div className="bg-red-500 p-6 flex justify-center">
                    <div className="bg-white p-4 rounded-full shadow-lg">
                        <Lock size={40} className="text-red-500" />
                    </div>
                </div>
                
                <div className="p-8 space-y-4">
                    <h1 className="text-2xl font-bold text-slate-800">Acesso Bloqueado</h1>
                    
                    <div className="bg-red-50 text-red-700 p-4 rounded-lg border border-red-100 text-sm font-medium">
                        {getMessage()}
                    </div>

                    <p className="text-slate-600 text-sm leading-relaxed">
                        Para continuar acessando o Nexus CRM e gerenciando os dados de <strong>{currentOrganization?.name}</strong>, é necessário regularizar sua assinatura.
                    </p>

                    <div className="pt-4 space-y-3">
                        <button 
                            onClick={() => window.open('https://billing.stripe.com/p/login/test', '_blank')}
                            className="w-full bg-slate-900 text-white font-bold py-3 rounded-lg hover:bg-slate-800 transition flex items-center justify-center gap-2 shadow-lg"
                        >
                            <CreditCard size={18} /> Regularizar Pagamento
                        </button>
                        
                        <button 
                            className="w-full bg-white border border-slate-200 text-slate-600 font-bold py-3 rounded-lg hover:bg-slate-50 transition flex items-center justify-center gap-2"
                            onClick={() => window.open('mailto:suporte@softcase.com.br', '_blank')}
                        >
                            <HelpCircle size={18} /> Falar com Suporte
                        </button>
                    </div>
                </div>

                <div className="bg-slate-50 p-4 border-t border-slate-100">
                    <button onClick={logout} className="text-sm text-slate-500 hover:text-red-600 font-medium flex items-center justify-center gap-1 mx-auto">
                        <LogOut size={14} /> Sair da conta
                    </button>
                </div>
            </div>
        </div>
    );
};
