import React from 'react';
import { LucideIcon, Info } from 'lucide-react';

interface KPICardProps {
  title: string;
  value: string;
  trend?: string;
  trendUp?: boolean;
  icon: LucideIcon;
  color: string;
  tooltip?: string; // Nova propriedade opcional
}

export const KPICard: React.FC<KPICardProps> = ({ title, value, trend, trendUp, icon: Icon, color, tooltip }) => {
  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 relative group/card hover:shadow-md transition-all duration-200">
      <div className="flex justify-between items-start">
        <div>
          <div className="flex items-center gap-1.5 mb-2">
            <p className="text-sm font-medium text-slate-500">{title}</p>
            {tooltip && (
                <div className="relative group/tooltip">
                    <Info size={14} className="text-slate-400 cursor-help hover:text-blue-500 transition-colors" />
                    {/* Tooltip Popup */}
                    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 hidden group-hover/tooltip:block w-48 p-2.5 bg-slate-800 text-white text-xs rounded-lg shadow-xl z-50 pointer-events-none animate-fade-in">
                        {tooltip}
                        {/* Arrow */}
                        <div className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-slate-800"></div>
                    </div>
                </div>
            )}
          </div>
          <h3 className="text-2xl font-bold text-slate-900">{value}</h3>
        </div>
        <div className={`p-2 rounded-lg ${color}`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
      </div>
      {trend && (
        <div className="mt-4 flex items-center text-sm">
          <span className={`font-medium ${trendUp ? 'text-green-600' : 'text-red-600'}`}>
            {trendUp ? '+' : ''}{trend}
          </span>
          <span className="text-slate-400 ml-2">vs. mês anterior</span>
        </div>
      )}
    </div>
  );
};

export const SectionTitle: React.FC<{ title: string; subtitle?: string }> = ({ title, subtitle }) => (
  <div className="mb-6">
    <h2 className="text-xl font-bold text-slate-900">{title}</h2>
    {subtitle && <p className="text-sm text-slate-500">{subtitle}</p>}
  </div>
);

export const Badge: React.FC<{ children: React.ReactNode; color?: 'blue' | 'green' | 'red' | 'yellow' | 'gray' }> = ({ children, color = 'gray' }) => {
  const styles = {
    blue: 'bg-blue-100 text-blue-800',
    green: 'bg-emerald-100 text-emerald-800',
    red: 'bg-red-100 text-red-800',
    yellow: 'bg-amber-100 text-amber-800',
    gray: 'bg-slate-100 text-slate-800',
  };
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${styles[color]}`}>
      {children}
    </span>
  );
};