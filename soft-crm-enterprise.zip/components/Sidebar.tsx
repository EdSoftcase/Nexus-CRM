
import React from 'react';
import { LayoutDashboard, Users, LifeBuoy, Code, DollarSign, PieChart, Settings, LogOut, Briefcase, X, HeartPulse, FileText, ShieldAlert, RefreshCw, CheckCircle, Wifi, WifiOff, Lock, Database, Calendar as CalendarIcon } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { getSupabaseConfig } from '../services/supabaseClient';

interface SidebarProps {
  activeModule: string;
  onChangeModule: (module: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

const navItems = [
  { id: 'dashboard', label: 'Visão Geral', icon: LayoutDashboard },
  { id: 'calendar', label: 'Agenda', icon: CalendarIcon }, // New Module
  { id: 'commercial', label: 'Comercial', icon: Users },
  { id: 'proposals', label: 'Propostas', icon: FileText },
  { id: 'clients', label: 'Carteira de Clientes', icon: Briefcase },
  { id: 'customer-success', label: 'Sucesso do Cliente', icon: HeartPulse },
  { id: 'retention', label: 'Retenção', icon: ShieldAlert },
  { id: 'finance', label: 'Financeiro', icon: DollarSign }, 
  { id: 'support', label: 'Suporte', icon: LifeBuoy },
  { id: 'dev', label: 'Desenvolvimento', icon: Code },
  { id: 'reports', label: 'Relatórios', icon: PieChart },
];

export const Sidebar: React.FC<SidebarProps> = ({ activeModule, onChangeModule, isOpen, onClose }) => {
  const { currentUser, hasPermission, logout } = useAuth();
  const { isSyncing, refreshData, lastSyncTime } = useData();

  // Verificar se existem credenciais salvas
  const { url } = getSupabaseConfig();
  const hasCredentials = !!url;

  const handleNavigation = (moduleId: string) => {
      onChangeModule(moduleId);
      onClose(); // Close sidebar on mobile when item clicked
  };

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 md:hidden backdrop-blur-sm"
          onClick={onClose}
        />
      )}

      {/* Sidebar Container */}
      <div className={`
        fixed inset-y-0 left-0 z-50 w-64 bg-slate-900 text-white flex flex-col h-[100dvh] shadow-2xl transition-transform duration-300 ease-in-out
        md:relative md:translate-x-0
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="p-6 flex justify-between items-center shrink-0">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center shadow-lg shadow-blue-500/30">
              <span className="font-bold text-lg">N</span>
            </div>
            <span className="text-xl font-bold tracking-tight">Nexus CRM</span>
          </div>
          {/* Close Button for Mobile */}
          <button onClick={onClose} className="md:hidden text-slate-400 hover:text-white">
            <X size={24} />
          </button>
        </div>

        <div className="px-6 mb-2 shrink-0">
           <div className="flex items-center gap-3 px-3 py-2 bg-slate-800 rounded-lg border border-slate-700">
              <div className="w-8 h-8 rounded-full bg-slate-600 flex items-center justify-center text-xs font-bold shrink-0">
                  {currentUser.avatar}
              </div>
              <div className="overflow-hidden">
                  <p className="text-sm font-medium truncate">{currentUser.name}</p>
                  <p className="text-[10px] text-slate-400 uppercase tracking-wider">{currentUser.role}</p>
              </div>
          </div>
        </div>

        <nav className="flex-1 px-4 space-y-1 mt-2 overflow-y-auto custom-scrollbar">
          {navItems.map((item) => {
            if (item.id !== 'dashboard' && item.id !== 'calendar' && !hasPermission(item.id)) return null;
            
            const Icon = item.icon;
            const isActive = activeModule === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavigation(item.id)}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                  isActive 
                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/50 translate-x-1' 
                    : 'text-slate-400 hover:bg-slate-800 hover:text-white hover:translate-x-1'
                }`}
              >
                <Icon size={20} />
                <span className="font-medium">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-800 space-y-2 shrink-0">
           {/* SYNC STATUS WIDGET */}
           <div className={`rounded-lg p-3 mb-2 border ${hasCredentials ? 'bg-slate-800/50 border-slate-700' : 'bg-red-900/20 border-red-800/50'}`}>
              <div className="flex justify-between items-center mb-1">
                  <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider flex items-center gap-1">
                      <Database size={10} /> Cloud Sync
                  </span>
                  {isSyncing ? (
                      <span className="text-[10px] text-blue-400 flex items-center gap-1"><RefreshCw size={10} className="animate-spin"/> Sync...</span>
                  ) : hasCredentials ? (
                       <span className="text-[10px] text-emerald-400 flex items-center gap-1"><Lock size={8}/> Conectado</span>
                  ) : (
                      <span className="text-[10px] text-slate-500 flex items-center gap-1"><WifiOff size={10}/> Local</span>
                  )}
              </div>
              
              <div className="flex justify-between items-center mt-2">
                 <p className="text-[10px] text-slate-400 truncate max-w-[120px]">
                    {hasCredentials ? (lastSyncTime ? `Atualizado: ${lastSyncTime.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}` : 'Pronto') : 'Sem credenciais'}
                 </p>
                 <button 
                    onClick={() => refreshData()}
                    disabled={isSyncing}
                    className="p-1.5 bg-slate-700 hover:bg-blue-600 text-white rounded transition disabled:opacity-50"
                    title="Forçar Sincronização"
                 >
                    <RefreshCw size={12} className={isSyncing ? 'animate-spin' : ''}/>
                 </button>
              </div>
           </div>

          <button 
            onClick={() => handleNavigation('settings')}
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
              activeModule === 'settings' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Settings size={20} />
            <span className="font-medium">Configurações</span>
          </button>
          
          <button 
              type="button"
              onClick={logout}
              className="w-full flex items-center space-x-3 px-4 py-3 text-red-400 hover:text-red-300 hover:bg-red-900/20 rounded-lg transition-colors"
          >
              <LogOut size={20} />
              <span className="font-medium">Sair</span>
          </button>
        </div>
      </div>
    </>
  );
};
